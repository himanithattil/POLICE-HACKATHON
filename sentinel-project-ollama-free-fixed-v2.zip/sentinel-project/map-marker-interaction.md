# Draggable Officer Interaction Verification

On `/routes`, the browser exposed the officer control as `Drag officer marker to place a person on the map`. Activating the marker placed the officer on the operational fallback map, changed the legend to include `Officer route`, and changed the officer-assistance panel to `ROUTE GUIDANCE READY` with destination `Suvidha park` and a `Clear location` action.

The route remained `EXACT ROUTE · 3 VERIFIED EVENTS · 5 CAMERAS VISIBLE`, and the browser did not require authentication.
