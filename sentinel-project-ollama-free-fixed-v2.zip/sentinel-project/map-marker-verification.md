# Map Visibility and Marker Verification

The `/routes` browser page now exposes an `Operational camera map` instead of only isolated dots. The rendered content includes `AHMEDABAD`, `JUNAGADH`, and `RAJKOT` place labels, a visible map surface with roads and landmass shapes, an exact route line, five camera controls with coordinate titles, and a `Retry live map` control.

The browser also exposes an accessible button labeled `Drag officer marker to place a person on the map` with the visible label `OFFICER · DRAG`. The map note states: `Exact coordinates · route highlighted · drag the officer marker to place a person`. The default plate route remains `EXACT ROUTE · 3 VERIFIED EVENTS · 5 CAMERAS VISIBLE`.
