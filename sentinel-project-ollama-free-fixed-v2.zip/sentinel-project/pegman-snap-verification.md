# Pegman Verified-Point Snap Verification

A browser pointer drag dropped Pegman onto the route map. The interaction opened the Street View panel and returned:

- `found: true`
- `panelVisible: true`
- `snappedTitle: Street View near Suvidha park`
- `verifiedCameraName: Suvidha park`
- `exactPointLink: true`
- `unavailableState: true` in the current preview because the live Maps provider is unavailable

The drop therefore resolves to the nearest verified route camera rather than leaving the Street View target at an arbitrary unverified coordinate. The exact-point Google Street View link remains available when the live in-app panorama cannot load.
