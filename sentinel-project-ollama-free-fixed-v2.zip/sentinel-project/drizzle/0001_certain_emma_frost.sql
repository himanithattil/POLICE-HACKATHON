CREATE TABLE `cctv_alerts` (
	`id` varchar(32) NOT NULL,
	`subject` varchar(128) NOT NULL,
	`subject_type` enum('vehicle','person') NOT NULL,
	`category` varchar(128) NOT NULL,
	`priority` enum('high','medium','low') NOT NULL,
	`status` enum('new','acknowledged','resolved') NOT NULL,
	`camera_id` varchar(32) NOT NULL,
	`event_time` varchar(24) NOT NULL,
	`confidence_basis_points` int NOT NULL,
	`case_reference` varchar(48) NOT NULL,
	`summary` text NOT NULL,
	CONSTRAINT `cctv_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cctv_cameras` (
	`id` varchar(32) NOT NULL,
	`name` varchar(128) NOT NULL,
	`district` varchar(80) NOT NULL,
	`department` varchar(128) NOT NULL,
	`status` enum('online','degraded','maintenance','offline') NOT NULL,
	`source` varchar(32) NOT NULL,
	`map_x` int NOT NULL,
	`map_y` int NOT NULL,
	`latitude` double NOT NULL DEFAULT 0,
	`longitude` double NOT NULL DEFAULT 0,
	`coordinate_source` varchar(160) NOT NULL DEFAULT 'Unverified source label',
	`coordinate_accuracy_meters` int NOT NULL DEFAULT 0,
	`coordinate_verified_at` timestamp,
	`coordinate_verified_by` varchar(128),
	`last_heartbeat` varchar(24) NOT NULL,
	`activity` varchar(128) NOT NULL,
	`throughput` varchar(64) NOT NULL,
	CONSTRAINT `cctv_cameras_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cctv_share_links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`token_hash` varchar(64) NOT NULL,
	`label` varchar(120) NOT NULL DEFAULT 'Read-only command view',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`expires_at` timestamp NOT NULL,
	`revoked_at` timestamp,
	`last_accessed_at` timestamp,
	CONSTRAINT `cctv_share_links_id` PRIMARY KEY(`id`),
	CONSTRAINT `cctv_share_links_token_hash_unique` UNIQUE(`token_hash`)
);
--> statement-breakpoint
CREATE TABLE `cctv_sightings` (
	`id` varchar(32) NOT NULL,
	`subject` varchar(128) NOT NULL,
	`subject_type` enum('vehicle','person') NOT NULL,
	`camera_id` varchar(32) NOT NULL,
	`event_time` varchar(24) NOT NULL,
	`confidence_basis_points` int NOT NULL,
	`event` varchar(128) NOT NULL,
	`sequence` int NOT NULL,
	CONSTRAINT `cctv_sightings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cctv_verification_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`record_type` enum('alert','watchlist_case') NOT NULL,
	`record_id` varchar(32) NOT NULL,
	`action` enum('verify','reject','request_more_evidence') NOT NULL,
	`analyst_id` varchar(128) NOT NULL,
	`reason` text NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cctv_verification_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cctv_watchlist_cases` (
	`id` varchar(32) NOT NULL,
	`subject` varchar(128) NOT NULL,
	`subject_type` enum('vehicle','person') NOT NULL,
	`category` varchar(128) NOT NULL,
	`priority` enum('high','medium','low') NOT NULL,
	`status` enum('active','resolved') NOT NULL,
	`case_reference` varchar(48) NOT NULL,
	`owner` varchar(128) NOT NULL,
	`last_update` varchar(32) NOT NULL,
	`notes` text NOT NULL,
	`resolution_outcome` enum('vehicle_found','person_found','case_solved'),
	`resolution_evidence_type` enum('cross_camera','field_confirmation','official_case_record'),
	`resolution_evidence_reference` varchar(160),
	`resolution_evidence_summary` text,
	`resolved_by` varchar(128),
	`resolved_at` timestamp,
	CONSTRAINT `cctv_watchlist_cases_id` PRIMARY KEY(`id`)
);
