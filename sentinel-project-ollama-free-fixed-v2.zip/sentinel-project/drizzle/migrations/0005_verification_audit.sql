CREATE TABLE `cctv_verification_logs` (
  `id` int AUTO_INCREMENT NOT NULL,
  `record_type` enum('alert','watchlist_case') NOT NULL,
  `record_id` varchar(32) NOT NULL,
  `action` enum('verify','reject','request_more_evidence') NOT NULL,
  `analyst_id` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `cctv_verification_logs_id` PRIMARY KEY(`id`)
);

CREATE INDEX `cctv_verification_logs_record_idx` ON `cctv_verification_logs` (`record_type`,`record_id`);
