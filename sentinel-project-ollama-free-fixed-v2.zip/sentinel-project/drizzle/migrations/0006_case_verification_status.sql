ALTER TABLE `cctv_alerts` ADD COLUMN `verification_status` enum('pending','verified','rejected','more_evidence') NOT NULL DEFAULT 'pending';
ALTER TABLE `cctv_watchlist_cases` ADD COLUMN `verification_status` enum('pending','verified','rejected','more_evidence') NOT NULL DEFAULT 'pending';
