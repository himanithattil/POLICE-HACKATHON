import { double, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const cctvCameras = mysqlTable("cctv_cameras", {
  id: varchar("id", { length: 32 }).primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  district: varchar("district", { length: 80 }).notNull(),
  department: varchar("department", { length: 128 }).notNull(),
  status: mysqlEnum("status", ["online", "degraded", "maintenance", "offline"]).notNull(),
  source: varchar("source", { length: 32 }).notNull(),
  x: int("map_x").notNull(),
  y: int("map_y").notNull(),
  latitude: double("latitude").notNull().default(0),
  longitude: double("longitude").notNull().default(0),
  coordinateSource: varchar("coordinate_source", { length: 160 }).notNull().default("Unverified source label"),
  coordinateAccuracyMeters: int("coordinate_accuracy_meters").notNull().default(0),
  coordinateVerifiedAt: timestamp("coordinate_verified_at"),
  coordinateVerifiedBy: varchar("coordinate_verified_by", { length: 128 }),
  lastHeartbeat: varchar("last_heartbeat", { length: 24 }).notNull(),
  activity: varchar("activity", { length: 128 }).notNull(),
  throughput: varchar("throughput", { length: 64 }).notNull(),
});

export const cctvAlerts = mysqlTable("cctv_alerts", {
  id: varchar("id", { length: 32 }).primaryKey(),
  subject: varchar("subject", { length: 128 }).notNull(),
  subjectType: mysqlEnum("subject_type", ["vehicle", "person"]).notNull(),
  category: varchar("category", { length: 128 }).notNull(),
  priority: mysqlEnum("priority", ["high", "medium", "low"]).notNull(),
  status: mysqlEnum("status", ["new", "acknowledged", "resolved"]).notNull(),
  verificationStatus: mysqlEnum("verification_status", ["pending", "verified", "rejected", "more_evidence"]).notNull().default("pending"),
  cameraId: varchar("camera_id", { length: 32 }).notNull(),
  timestamp: varchar("event_time", { length: 24 }).notNull(),
  confidence: int("confidence_basis_points").notNull(),
  caseReference: varchar("case_reference", { length: 48 }).notNull(),
  summary: text("summary").notNull(),
});

export const cctvWatchlistCases = mysqlTable("cctv_watchlist_cases", {
  id: varchar("id", { length: 32 }).primaryKey(),
  subject: varchar("subject", { length: 128 }).notNull(),
  subjectType: mysqlEnum("subject_type", ["vehicle", "person"]).notNull(),
  category: varchar("category", { length: 128 }).notNull(),
  priority: mysqlEnum("priority", ["high", "medium", "low"]).notNull(),
  status: mysqlEnum("status", ["active", "resolved"]).notNull(),
  verificationStatus: mysqlEnum("verification_status", ["pending", "verified", "rejected", "more_evidence"]).notNull().default("pending"),
  caseReference: varchar("case_reference", { length: 48 }).notNull(),
  owner: varchar("owner", { length: 128 }).notNull(),
  lastUpdate: varchar("last_update", { length: 32 }).notNull(),
  notes: text("notes").notNull(),
  resolutionOutcome: mysqlEnum("resolution_outcome", ["vehicle_found", "person_found", "case_solved"]),
  resolutionEvidenceType: mysqlEnum("resolution_evidence_type", ["cross_camera", "field_confirmation", "official_case_record"]),
  resolutionEvidenceReference: varchar("resolution_evidence_reference", { length: 160 }),
  resolutionEvidenceSummary: text("resolution_evidence_summary"),
  resolvedBy: varchar("resolved_by", { length: 128 }),
  resolvedAt: timestamp("resolved_at"),
});

export const cctvVerificationLogs = mysqlTable("cctv_verification_logs", {
  id: int("id").autoincrement().primaryKey(),
  recordType: mysqlEnum("record_type", ["alert", "watchlist_case"]).notNull(),
  recordId: varchar("record_id", { length: 32 }).notNull(),
  action: mysqlEnum("action", ["verify", "reject", "request_more_evidence"]).notNull(),
  analystId: varchar("analyst_id", { length: 128 }).notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const cctvSightings = mysqlTable("cctv_sightings", {
  id: varchar("id", { length: 32 }).primaryKey(),
  subject: varchar("subject", { length: 128 }).notNull(),
  subjectType: mysqlEnum("subject_type", ["vehicle", "person"]).notNull(),
  cameraId: varchar("camera_id", { length: 32 }).notNull(),
  timestamp: varchar("event_time", { length: 24 }).notNull(),
  confidence: int("confidence_basis_points").notNull(),
  event: varchar("event", { length: 128 }).notNull(),
  sequence: int("sequence").notNull(),
});

export const cctvShareLinks = mysqlTable("cctv_share_links", {
  id: int("id").autoincrement().primaryKey(),
  tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
  label: varchar("label", { length: 120 }).notNull().default("Read-only command view"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  revokedAt: timestamp("revoked_at"),
  lastAccessedAt: timestamp("last_accessed_at"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
