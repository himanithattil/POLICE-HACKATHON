# Pegman Street View Verification

The route map exposes an accessible yellow control labeled `Drag Pegman onto the map to open Street View` with the visible text `STREET VIEW / Drag onto map`.

A browser pointer drag from the Pegman control onto the map was simulated. The result confirmed `found: true`, `panelVisible: true`, and `externalLinkVisible: true`. Because the preview’s live Google Maps provider is unavailable, the panel correctly showed `Live Street View unavailable` rather than fabricating imagery, and it offered an exact-coordinate link to open the selected point in Google Maps Street View. When the live provider is available with Street View coverage, the same component resolves the nearest public panorama into the in-app panorama container.
