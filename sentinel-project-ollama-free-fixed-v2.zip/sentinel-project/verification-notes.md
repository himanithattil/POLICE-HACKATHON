# Contest Demo Verification Notes

## Browser verification completed

The public root page opens with a single **Enter judge demo** action and explicitly states that no account, password, Manus login, or external authentication is required. No sign-in button is present on the entry page.

Clicking the judge action navigates directly to `/operations?demo=1&judge=1`. The command shell renders a **Judge bypass / Demo** navigation state and a **Judge observer / No login required** footer. The browser did not redirect to Manus OAuth.

The Operations page loads the persisted sandbox records, shows 30 registered cameras, and reports `5/30 SOURCES HAVE VERIFIED GPS` rather than hiding the available locations.

The Person Routes page shows person-only records and `GPS verified` labels without replacing the person identity with a license-plate value.

The Vehicle Routes page resets correctly to `GJ01QX4821` after navigation. It reports `EXACT ROUTE · 3 VERIFIED EVENTS · 5 CAMERAS VISIBLE`, shows `GJ01QX4821 movement trail`, and lists CN Vidhyalaya, Delight, and Suvidha park with GPS-verified source locations and ±25 m accuracy. No login prompt appears.

When Google Maps is unavailable in the preview, the application renders the static verified-camera coordinate overlay instead of an empty error panel. Route cameras are highlighted and the live-map retry action remains available.

## Automated verification

`pnpm check` passes. `pnpm test` passes with 10 test files and 29 tests, including the regression test proving all three default plate-route events have non-zero exact demo coordinates.
