import { z } from "zod";

export const resolutionInputSchema = z.object({
  outcome: z.enum(["vehicle_found", "person_found", "case_solved"]),
  evidenceType: z.enum(["cross_camera", "field_confirmation", "official_case_record"]),
  evidenceReference: z.string().trim().min(4, "Provide an evidence or record reference.").max(160),
  evidenceSummary: z.string().trim().min(20, "Describe the evidence in at least 20 characters.").max(2000),
});

export type ResolutionInput = z.infer<typeof resolutionInputSchema>;
export type ResolutionSubjectType = "vehicle" | "person";

export function isResolutionOutcomeValid(subjectType: ResolutionSubjectType, outcome: ResolutionInput["outcome"]) {
  return outcome === "case_solved" || (subjectType === "vehicle" && outcome === "vehicle_found") || (subjectType === "person" && outcome === "person_found");
}

export function getResolutionOutcomeLabel(outcome: ResolutionInput["outcome"]) {
  return outcome === "vehicle_found" ? "Vehicle found" : outcome === "person_found" ? "Person found" : "Case solved";
}

export function getResolutionEvidenceLabel(evidenceType: ResolutionInput["evidenceType"]) {
  return evidenceType === "cross_camera" ? "Cross-camera evidence" : evidenceType === "field_confirmation" ? "Field confirmation" : "Official case record";
}
