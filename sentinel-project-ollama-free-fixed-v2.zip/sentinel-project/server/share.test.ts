import { describe, expect, it } from "vitest";
import { hashShareToken, inspectShareLink, isShareTokenShapeValid } from "./share";

describe("app-native share access", () => {
  it("accepts only the fixed opaque token shape", () => {
    expect(isShareTokenShapeValid("a".repeat(48))).toBe(true);
    expect(isShareTokenShapeValid("a".repeat(47))).toBe(false);
    expect(isShareTokenShapeValid("z".repeat(48))).toBe(false);
  });

  it("hashes tokens deterministically and fails closed for malformed links", async () => {
    expect(hashShareToken("a".repeat(48))).toHaveLength(64);
    expect(hashShareToken("a".repeat(48))).toBe(hashShareToken("a".repeat(48)));
    expect(await inspectShareLink("not-a-share-token")).toEqual({ valid: false, reason: "invalid" });
  });
});
