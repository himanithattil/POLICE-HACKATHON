import { eq, inArray } from "drizzle-orm";
import { getDb } from "./db";
import { cctvAlerts, cctvCameras, cctvSightings, cctvVerificationLogs, cctvWatchlistCases } from "../drizzle/schema";
import { intakeRecordId, isVerifiedCoordinateIntake, type CameraIntake, type WatchlistIntake } from "./intake";
import { isResolutionOutcomeValid, type ResolutionInput } from "./resolution";
import { normalizeDetectionResult, type DetectionResult } from "./detection";

const cameraSeed = [
  { id: "SENTINEL-1", name: "Chiman bhai Bridge", district: "01 Chiman bhai Bridge", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 1 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-2", name: "Janpath", district: "02 Janpath", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 2 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-3", name: "O.N.G.C. Office", district: "03 O.N.G.C. Office", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 3 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-4", name: "Paldi Circle", district: "04 Paldi Circle", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 4 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-5", name: "Visat teen Rasta", district: "05 Visat teen Rasta", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 5 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-6", name: "Timbavadi gate-Junagadh", district: "06 Timbavadi gate-Junagadh", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · HEVC", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 25 fps · 1923 kbps", throughput: "Published feed" },
  { id: "SENTINEL-7", name: "Hero showroom-Gir Somnath", district: "07 hero-showroom-gir-somnath", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 7 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-8", name: "Majewadi gate-Junagadh", district: "08 majewadi-gate-junagadh", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 8 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-9", name: "New bypass near by circle-Junagadh", district: "09 new-bypass-near-by-circle-junagadh-2", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 9 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-10", name: "Char chowk road-Junagadh", district: "10 char-chowk-road-2-junagadh", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 10 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-11", name: "Dolatpara-Junagadh", district: "11 dolatpara-junagadh", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 11 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-12", name: "Tri Mandir Adalaj Tollnaka", district: "12 Tri Mandir Adalaj Tollnaka", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 12 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-13", name: "CN Vidhyalaya", district: "13 CN Vidhyalaya", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 12.5 fps · 902 kbps", throughput: "Published feed" },
  { id: "SENTINEL-14", name: "Delight", district: "14 Delight", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 12.5 fps · 980 kbps", throughput: "Published feed" },
  { id: "SENTINEL-15", name: "Suvidha park", district: "15 Suvidha park", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 12.5 fps · 690 kbps", throughput: "Published feed" },
  { id: "SENTINEL-16", name: "Visat P2", district: "16 Visat P2", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 12.5 fps · 961 kbps", throughput: "Published feed" },
  { id: "SENTINEL-17", name: "Rajkot Bus Port CCTV", district: "17 Rajkot Bus Port CCTV", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · HEVC", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 24.98 fps · 671 kbps", throughput: "Published feed" },
  { id: "SENTINEL-18", name: "Rajkot CCTV", district: "18 Rajkot CCTV", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 18 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-19", name: "Khaparia Gram Panchayat", district: "19 KHAPARIA GRAM PANCHAYAT, GANDEVI, NAVSARI", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 19 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-20", name: "Mohanpura", district: "20 Mohanpura", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 20 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-21", name: "Patan Dethali Char Rasta", district: "23 Patan Dethali Char Rasta", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 21 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-22", name: "BK Mervada tran Rasta", district: "28 BK Mervada tran Rasta", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · HEVC", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1920×1080 · 25 fps · 2091 kbps", throughput: "Published feed" },
  { id: "SENTINEL-23", name: "Kheram", district: "30 kheram", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1280×720 · 25 fps · 4001 kbps", throughput: "Published feed" },
  { id: "SENTINEL-24", name: "Dehgam", district: "33 dehgam", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 24 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-25", name: "Dhanori", district: "34 dhanori", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 25 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-26", name: "Tankal", district: "35 TANKAL", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · HEVC", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "2560×1440 · 13.35 fps · 2411 kbps", throughput: "Published feed" },
  { id: "SENTINEL-27", name: "Bilimora", district: "36 bilimora", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1280×960 · 24.86 fps · 1112 kbps", throughput: "Published feed" },
  { id: "SENTINEL-28", name: "Bilimora", district: "37 bilimora", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 28 · metadata pending", throughput: "Published feed" },
  { id: "SENTINEL-29", name: "Bilimora", district: "38 bilimora", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP · H.264", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "1280×960 · 24.78 fps · 907 kbps", throughput: "Published feed" },
  { id: "SENTINEL-30", name: "Gandhidham Rambaugh P2", district: "Gandhidham Rambaugh p2", department: "Gujarat Police Sentinel Sandbox", status: "online" as const, source: "RTSP", x: 0, y: 0, latitude: 0, longitude: 0, lastHeartbeat: "Catalogue live", activity: "Sentinel camera 30 · metadata pending", throughput: "Published feed" },
];

const verifiedDemoCoordinates: Record<string, { latitude: number; longitude: number }> = {
  "SENTINEL-6": { latitude: 21.5222, longitude: 70.4579 },
  "SENTINEL-13": { latitude: 23.0304, longitude: 72.5591 },
  "SENTINEL-14": { latitude: 23.0388, longitude: 72.5536 },
  "SENTINEL-15": { latitude: 23.0187, longitude: 72.5482 },
  "SENTINEL-17": { latitude: 22.3072, longitude: 70.8028 },
};

const alertSeed = [
  { id: "ALT-2041", subject: "GJ01QX4821", subjectType: "vehicle" as const, category: "Stolen vehicle", priority: "high" as const, status: "new" as const, verificationStatus: "pending" as const, cameraId: "SENTINEL-15", timestamp: "08:41", confidence: 987, caseReference: "GJ-CASE-48", summary: "Verified sandbox event at Suvidha park; correlated with an active recovery case." },
  { id: "ALT-2040", subject: "R. Shah", subjectType: "person" as const, category: "Missing person", priority: "high" as const, status: "new" as const, verificationStatus: "pending" as const, cameraId: "SENTINEL-14", timestamp: "08:34", confidence: 921, caseReference: "GJ-PER-19", summary: "Reference match cleared analyst confidence threshold in the Sentinel evaluation dataset." },
  { id: "ALT-2039", subject: "GJ05KR9013", subjectType: "vehicle" as const, category: "Blacklisted vehicle", priority: "medium" as const, status: "acknowledged" as const, verificationStatus: "pending" as const, cameraId: "SENTINEL-6", timestamp: "08:18", confidence: 964, caseReference: "GJ-CASE-41", summary: "Detection retained after cross-camera verification in the published sandbox set." },
  { id: "ALT-2037", subject: "M. Iyer", subjectType: "person" as const, category: "Person of interest", priority: "medium" as const, status: "acknowledged" as const, verificationStatus: "pending" as const, cameraId: "SENTINEL-17", timestamp: "07:52", confidence: 898, caseReference: "GJ-PER-12", summary: "Movement pattern matches a supervised case workflow; escalation is not currently required." },
  { id: "ALT-2032", subject: "GJ03NL6610", subjectType: "vehicle" as const, category: "Wanted vehicle", priority: "low" as const, status: "resolved" as const, verificationStatus: "verified" as const, cameraId: "SENTINEL-13", timestamp: "07:21", confidence: 942, caseReference: "GJ-CASE-36", summary: "Field team confirmed a clerical update; case retained as read-only history." },
];

const caseSeed = [
  { id: "CASE-48", subject: "GJ01QX4821", subjectType: "vehicle" as const, category: "Stolen vehicle", priority: "high" as const, status: "active" as const, verificationStatus: "pending" as const, caseReference: "GJ-CASE-48", owner: "Recovery Desk", lastUpdate: "08:41", notes: "Three verified ANPR events within the current review window." },
  { id: "PER-19", subject: "R. Shah", subjectType: "person" as const, category: "Missing person", priority: "high" as const, status: "active" as const, verificationStatus: "pending" as const, caseReference: "GJ-PER-19", owner: "Person Intelligence", lastUpdate: "08:34", notes: "Reference enrollment available; analyst verification required before dissemination." },
  { id: "CASE-41", subject: "GJ05KR9013", subjectType: "vehicle" as const, category: "Blacklisted vehicle", priority: "medium" as const, status: "active" as const, verificationStatus: "pending" as const, caseReference: "GJ-CASE-41", owner: "Vadodara Desk", lastUpdate: "08:18", notes: "Route intelligence identifies a southbound pattern across two sources." },
  { id: "PER-12", subject: "M. Iyer", subjectType: "person" as const, category: "Person of interest", priority: "medium" as const, status: "active" as const, verificationStatus: "pending" as const, caseReference: "GJ-PER-12", owner: "Surat Desk", lastUpdate: "07:52", notes: "Acknowledged by duty officer; retained for scheduled follow-up." },
  { id: "CASE-36", subject: "GJ03NL6610", subjectType: "vehicle" as const, category: "Wanted vehicle", priority: "low" as const, status: "resolved" as const, verificationStatus: "verified" as const, caseReference: "GJ-CASE-36", owner: "Vadodara Desk", lastUpdate: "07:21", notes: "Resolution recorded after field verification; evidence remains available." },
];

const sightingSeed = [
  { id: "VT-01", subject: "GJ01QX4821", subjectType: "vehicle" as const, cameraId: "SENTINEL-13", timestamp: "08:07", confidence: 971, event: "Verified plate read", sequence: 1 },
  { id: "VT-02", subject: "GJ01QX4821", subjectType: "vehicle" as const, cameraId: "SENTINEL-14", timestamp: "08:23", confidence: 983, event: "Correlated sighting", sequence: 2 },
  { id: "VT-03", subject: "GJ01QX4821", subjectType: "vehicle" as const, cameraId: "SENTINEL-15", timestamp: "08:41", confidence: 987, event: "Priority alert created", sequence: 3 },
  { id: "PT-01", subject: "R. Shah", subjectType: "person" as const, cameraId: "SENTINEL-13", timestamp: "08:17", confidence: 876, event: "Candidate match", sequence: 1 },
  { id: "PT-02", subject: "R. Shah", subjectType: "person" as const, cameraId: "SENTINEL-14", timestamp: "08:34", confidence: 921, event: "Analyst-verified match", sequence: 2 },
  { id: "PT-03", subject: "R. Shah", subjectType: "person" as const, cameraId: "SENTINEL-15", timestamp: "08:46", confidence: 908, event: "Route confidence refreshed", sequence: 3 },
  { id: "VT-04", subject: "GJ05KR9013", subjectType: "vehicle" as const, cameraId: "SENTINEL-6", timestamp: "07:46", confidence: 946, event: "Verified plate read", sequence: 1 },
  { id: "VT-05", subject: "GJ05KR9013", subjectType: "vehicle" as const, cameraId: "SENTINEL-17", timestamp: "08:18", confidence: 964, event: "Alert acknowledged", sequence: 2 },
];

type SandboxVerificationLog = { id: string; recordType: "alert" | "watchlist_case"; recordId: string; action: "verify" | "reject" | "request_more_evidence"; analystId: string; reason: string; createdAt: Date };
const sandboxVerificationLogs: SandboxVerificationLog[] = [];
let sandboxIntakeSequence = 0;

/**
 * Sandbox (no-database) write path.
 *
 * getOperationOverview() already fell back to the static seed arrays for
 * *reads* when DATABASE_URL isn't set — but every mutation below used to
 * hard-`throw "Operational data service is unavailable."` in that case,
 * which meant nothing beyond read-only viewing worked without provisioning
 * a real MySQL database first. For a hackathon demo (or anyone trying this
 * out locally) that's a needless hard requirement, so every mutation now has
 * an in-memory equivalent that mutates these same seed arrays in place. It's
 * not durable across a server restart, but it makes the whole product usable
 * with zero external services — persistence is only a `DATABASE_URL` away
 * when you actually want it.
 */
function isUsingSandbox(db: unknown): db is null {
  return db === null;
}

export async function ensureOperationData() {
  const db = await getDb();
  if (!db) throw new Error("Operational data service is unavailable.");
  const existingCameras = await db.select({ id: cctvCameras.id, latitude: cctvCameras.latitude, longitude: cctvCameras.longitude }).from(cctvCameras);
  const legacyCameraIds = existingCameras.filter((camera) => camera.id.startsWith("GJ-")).map((camera) => camera.id);
  if (legacyCameraIds.length) await db.delete(cctvCameras).where(inArray(cctvCameras.id, legacyCameraIds));
  const currentCameraIds = new Set(existingCameras.map((camera) => camera.id));
  const missingSentinelCameras = cameraSeed.filter((camera) => !currentCameraIds.has(camera.id));
  if (missingSentinelCameras.length) await db.insert(cctvCameras).values(missingSentinelCameras);
  const coordinateBackfills = cameraSeed.map((camera) => {
    const coordinates = verifiedDemoCoordinates[camera.id];
    const existing = existingCameras.find((item) => item.id === camera.id);
    if (!coordinates || (existing && existing.latitude !== 0 && existing.longitude !== 0)) return null;
    return { id: camera.id, ...coordinates };
  }).filter((item): item is { id: string; latitude: number; longitude: number } => item !== null);
  if (coordinateBackfills.length && typeof db.update === "function") {
    await Promise.all(coordinateBackfills.map(({ id, latitude, longitude }) => db.update(cctvCameras).set({ latitude, longitude, coordinateSource: "Hackathon demo registry coordinate", coordinateAccuracyMeters: 25, activity: "Verified demo coordinate · route-ready" }).where(eq(cctvCameras.id, id))));
  }

  const existingAlerts = await db.select({ id: cctvAlerts.id }).from(cctvAlerts).limit(1);
  if (!existingAlerts.length) {
    await db.insert(cctvAlerts).values(alertSeed);
    await db.insert(cctvWatchlistCases).values(caseSeed);
    await db.insert(cctvSightings).values(sightingSeed);
  } else if (legacyCameraIds.length) {
    await Promise.all(alertSeed.map((alert) => db.update(cctvAlerts).set({ cameraId: alert.cameraId, summary: alert.summary }).where(eq(cctvAlerts.id, alert.id))));
    await Promise.all(sightingSeed.map((sighting) => db.update(cctvSightings).set({ cameraId: sighting.cameraId }).where(eq(cctvSightings.id, sighting.id))));
  }
}

export function getSandboxOperationOverview() {
  const cameras = cameraSeed.map((camera) => ({ ...camera, ...(verifiedDemoCoordinates[camera.id] ?? {}) }));
  return { cameras, alerts: alertSeed, watchlistCases: caseSeed, routePoints: sightingSeed, verificationLogs: sandboxVerificationLogs };
}

export async function getOperationOverview() {
  const availableDb = await getDb();
  if (!availableDb) return getSandboxOperationOverview();
  await ensureOperationData();
  const db = await getDb();
  if (!db) return getSandboxOperationOverview();
  const [cameras, alerts, watchlistCases, routePoints, verificationLogs] = await Promise.all([
    db.select().from(cctvCameras),
    db.select().from(cctvAlerts),
    db.select().from(cctvWatchlistCases),
    db.select().from(cctvSightings),
    db.select().from(cctvVerificationLogs),
  ]);
  return { cameras, alerts, watchlistCases, routePoints, verificationLogs };
}

export async function logVerification(recordType: "alert" | "watchlist_case", recordId: string, action: "verify" | "reject" | "request_more_evidence", analystId: string, reason: string, allowSandboxWrite = false) {
  if (reason.trim().length < 4) throw new Error("Add a short reason so the verification decision is auditable.");
  const db = await getDb();
  if (isUsingSandbox(db)) {
    if (!allowSandboxWrite) throw new Error("Operational data service is unavailable. Enable Judge Demo mode or configure DATABASE_URL.");
    const table = recordType === "alert" ? alertSeed : caseSeed;
    const existing = (table as Array<{ id: string }>).find((item) => item.id === recordId);
    if (!existing) throw new Error("Verification target was not found.");
    const createdAt = new Date();
    const verificationStatus = action === "verify" ? "verified" : action === "reject" ? "rejected" : "more_evidence";
    (existing as { verificationStatus?: string }).verificationStatus = verificationStatus;
    sandboxVerificationLogs.push({ id: `VLOG-${sandboxVerificationLogs.length + 1}`, recordType, recordId, action, analystId: analystId.trim() || "Authorised analyst", reason: reason.trim(), createdAt });
    return { success: true, recordType, recordId, action, verificationStatus, createdAt } as const;
  }
  await ensureOperationData();
  const table = recordType === "alert" ? cctvAlerts : cctvWatchlistCases;
  const existing = await db.select({ id: table.id }).from(table).where(eq(table.id, recordId)).limit(1);
  if (!existing[0]) throw new Error("Verification target was not found.");
  const createdAt = new Date();
  await db.insert(cctvVerificationLogs).values({ recordType, recordId, action, analystId: analystId.trim() || "Authorised analyst", reason: reason.trim(), createdAt });
  const verificationStatus = action === "verify" ? "verified" : action === "reject" ? "rejected" : "more_evidence";
  await db.update(table).set({ verificationStatus }).where(eq(table.id, recordId));
  return { success: true, recordType, recordId, action, verificationStatus, createdAt } as const;
}

export async function acknowledgeAlert(id: string) {
  const db = await getDb();
  if (isUsingSandbox(db)) {
    const alert = (alertSeed as Array<{ id: string; status: string }>).find((item) => item.id === id);
    if (!alert) throw new Error("Alert not found.");
    alert.status = "acknowledged";
    return { success: true } as const;
  }
  await ensureOperationData();
  await db.update(cctvAlerts).set({ status: "acknowledged" }).where(eq(cctvAlerts.id, id));
  return { success: true } as const;
}

export async function resolveWatchlistCase(id: string, resolution: ResolutionInput, operator: string, allowSandboxWrite = false) {
  const db = await getDb();
  if (isUsingSandbox(db)) {
    if (!allowSandboxWrite) throw new Error("Operational data service is unavailable. Configure DATABASE_URL for persistent case resolution.");
    const item = (caseSeed as Array<Record<string, unknown>>).find((record) => record.id === id);
    if (!item) throw new Error("Case not found.");
    if (item.status === "resolved") throw new Error("This case is already resolved and retained as read-only history.");
    if (!isResolutionOutcomeValid(item.subjectType as "vehicle" | "person", resolution.outcome)) throw new Error(`Resolution outcome does not match the ${item.subjectType} case subject type.`);
    const resolvedAt = new Date();
    item.status = "resolved";
    item.lastUpdate = "Resolved just now";
    item.resolutionOutcome = resolution.outcome;
    item.resolutionEvidenceType = resolution.evidenceType;
    item.resolutionEvidenceReference = resolution.evidenceReference;
    item.resolutionEvidenceSummary = resolution.evidenceSummary;
    item.resolvedBy = operator;
    item.resolvedAt = resolvedAt;
    (alertSeed as Array<Record<string, unknown>>).filter((alert) => alert.caseReference === item.caseReference).forEach((alert) => { alert.status = "resolved"; });
    return { success: true, caseReference: item.caseReference as string, outcome: resolution.outcome, resolvedAt } as const;
  }
  await ensureOperationData();
  const selected = await db.select().from(cctvWatchlistCases).where(eq(cctvWatchlistCases.id, id)).limit(1);
  const item = selected[0];
  if (!item) throw new Error("Case not found.");
  if (item.status === "resolved") throw new Error("This case is already resolved and retained as read-only history.");
  if (!isResolutionOutcomeValid(item.subjectType, resolution.outcome)) throw new Error(`Resolution outcome does not match the ${item.subjectType} case subject type.`);
  const resolvedAt = new Date();
  await db.update(cctvWatchlistCases).set({ status: "resolved", lastUpdate: "Resolved just now", resolutionOutcome: resolution.outcome, resolutionEvidenceType: resolution.evidenceType, resolutionEvidenceReference: resolution.evidenceReference, resolutionEvidenceSummary: resolution.evidenceSummary, resolvedBy: operator, resolvedAt }).where(eq(cctvWatchlistCases.id, id));
  await db.update(cctvAlerts).set({ status: "resolved" }).where(eq(cctvAlerts.caseReference, item.caseReference));
  return { success: true, caseReference: item.caseReference, outcome: resolution.outcome, resolvedAt } as const;
}

export async function createDetectionAlert(cameraId: string, detection: DetectionResult, operator: string) {
  const db = await getDb();

  const camera = isUsingSandbox(db)
    ? (cameraSeed.find((item) => item.id === cameraId) as { id: string; name: string } | undefined)
    : (await (async () => { await ensureOperationData(); const rows = await db.select().from(cctvCameras).where(eq(cctvCameras.id, cameraId)).limit(1); return rows[0]; })());
  if (!camera) throw new Error("Unknown camera source. Select a registered source before committing a detection.");

  const safeDetection = normalizeDetectionResult(detection);
  const activeCases: Array<{ subject: string; subjectType: "vehicle" | "person"; caseReference: string; category: string }> = isUsingSandbox(db)
    ? caseSeed.filter((item) => item.status === "active")
    : await db.select().from(cctvWatchlistCases).where(eq(cctvWatchlistCases.status, "active"));
  const normalizedPlate = safeDetection.suspectedPlate;
  const matchedCase = normalizedPlate
    ? activeCases.find((item) => item.subjectType === "vehicle" && item.subject.trim().toUpperCase() === normalizedPlate)
    : undefined;
  const hasPerson = safeDetection.objects.some((object) => /person|pedestrian|human|face/i.test(object.type));
  const hasVehicle = safeDetection.objects.some((object) => /vehicle|car|sedan|suv|truck|bus|motorcycle|motorbike|bike|van|auto|plate/i.test(object.type));

  const priority: "high" | "medium" | "low" = matchedCase ? "high" : safeDetection.anomalyDetected ? "medium" : "low";
  const subjectType: "vehicle" | "person" = matchedCase?.subjectType ?? (hasPerson && !hasVehicle ? "person" : normalizedPlate ? "vehicle" : hasPerson ? "person" : "vehicle");
  const subject = subjectType === "person" ? "Person detected" : matchedCase?.subject ?? normalizedPlate ?? "Unidentified vehicle";
  const category = matchedCase?.category ?? (safeDetection.anomalyDetected ? "AI-flagged anomaly" : subjectType === "person" ? "AI person event" : "AI vehicle event");
  const caseReference = matchedCase?.caseReference ?? "PENDING-REVIEW";
  const confidenceUnit = matchedCase
    ? safeDetection.plateConfidence ?? 0.9
    : safeDetection.anomalyDetected
    ? safeDetection.objects[0]?.confidence ?? 0.6
    : safeDetection.objects[0]?.confidence ?? 0.5;
  const confidenceBasisPoints = Math.round(Math.min(Math.max(confidenceUnit, 0), 1) * 1000);

  const id = `AI-${Date.now().toString(36).toUpperCase()}`;
  const now = new Date();
  const timestamp = `${String(now.getUTCHours()).padStart(2, "0")}:${String(now.getUTCMinutes()).padStart(2, "0")}`;
  const summary = `Live AI triage on ${camera.name}: ${safeDetection.sceneSummary}${
    safeDetection.anomalyDetected && safeDetection.anomalyDescription ? ` Anomaly noted: ${safeDetection.anomalyDescription}.` : ""
  }${safeDetection.plateStatus !== "readable" ? ` Plate status: ${safeDetection.plateStatus.replace("_", " ")}.` : ""}${matchedCase ? ` Matched active watchlist case ${matchedCase.caseReference}.` : ""} Committed by ${operator}; requires analyst verification before any operational action.`;

  const newAlert = { id, subject, subjectType, category, priority, status: "new" as const, cameraId, timestamp, confidence: confidenceBasisPoints, caseReference, summary };

  // A detection is only traceable in Route Intelligence once it has a
  // sighting row — the AI-detection pipeline used to only ever write an
  // alert, so a live-detected plate could never actually show up on the
  // route/timeline view even after a successful commit. Every commit with an
  // identifiable subject now also appends a sighting.
  const traceableSubject = subjectType === "vehicle" ? normalizedPlate ?? subject : subject;
  const shouldTrace = subjectType === "vehicle" ? Boolean(normalizedPlate) : true;

  if (isUsingSandbox(db)) {
    (alertSeed as Array<typeof newAlert>).unshift(newAlert);
    if (shouldTrace) {
      const existingForSubject = sightingSeed.filter((point) => point.subject === traceableSubject);
      sightingSeed.push({ id: `AI-SIGHT-${sightingSeed.length + 1}`, subject: traceableSubject, subjectType, cameraId, timestamp, confidence: confidenceBasisPoints, event: "Live AI detection", sequence: existingForSubject.length + 1 });
    }
    return { id, matchedCaseReference: matchedCase?.caseReference ?? null, priority } as const;
  }

  await db.insert(cctvAlerts).values(newAlert);
  if (shouldTrace) {
    const existingForSubject = await db.select({ id: cctvSightings.id }).from(cctvSightings).where(eq(cctvSightings.subject, traceableSubject));
    await db.insert(cctvSightings).values({ id: `AI-SIGHT-${id}`, subject: traceableSubject, subjectType, cameraId, timestamp, confidence: confidenceBasisPoints, event: "Live AI detection", sequence: existingForSubject.length + 1 });
  }

  return { id, matchedCaseReference: matchedCase?.caseReference ?? null, priority } as const;
}

export async function createIntakeCameras(records: CameraIntake[], operator: string, allowSandboxWrite = false) {
  const db = await getDb();
  const uniqueIds = new Set(records.map((record) => record.id));
  if (uniqueIds.size !== records.length) throw new Error("CSV contains duplicate camera IDs. Correct the file and try again.");
  const now = new Date();
  const buildRow = (record: CameraIntake) => {
    const verified = isVerifiedCoordinateIntake(record);
    return {
      id: record.id,
      name: record.name,
      district: record.district,
      department: record.department,
      status: record.status,
      source: record.source,
      x: 0,
      y: 0,
      latitude: verified ? record.latitude! : 0,
      longitude: verified ? record.longitude! : 0,
      coordinateSource: verified ? record.coordinateSource! : "Unverified intake label",
      coordinateAccuracyMeters: verified ? record.coordinateAccuracyMeters! : 0,
      coordinateVerifiedAt: verified ? now : null,
      coordinateVerifiedBy: verified ? operator : null,
      lastHeartbeat: "Intake pending",
      activity: verified ? "Authorised intake · verified coordinate supplied" : "Authorised intake · coordinate verification pending",
      throughput: "Connection not assessed",
    };
  };

  if (isUsingSandbox(db)) {
    if (!allowSandboxWrite) throw new Error("Operational data service is unavailable. Configure DATABASE_URL for persistent imports.");
    const existing = records.filter((record) => cameraSeed.some((camera) => camera.id === record.id));
    if (existing.length) throw new Error(`Camera ID already exists: ${existing.map((record) => record.id).join(", ")}. Existing records are never overwritten by intake.`);
    (cameraSeed as Array<ReturnType<typeof buildRow>>).push(...records.map(buildRow));
    return { created: records.length, ids: records.map((record) => record.id) };
  }

  await ensureOperationData();
  const existing = records.length ? await db.select({ id: cctvCameras.id }).from(cctvCameras).where(inArray(cctvCameras.id, records.map((record) => record.id))) : [];
  if (existing.length) throw new Error(`Camera ID already exists: ${existing.map((camera) => camera.id).join(", ")}. Existing records are never overwritten by intake.`);
  await db.insert(cctvCameras).values(records.map(buildRow));
  return { created: records.length, ids: records.map((record) => record.id) };
}

export async function createIntakeWatchlistRecords(records: WatchlistIntake[], operator: string, allowSandboxWrite = false) {
  const db = await getDb();
  const references = new Set(records.map((record) => record.caseReference));
  if (references.size !== records.length) throw new Error("CSV contains duplicate case references. Correct the file and try again.");
  const buildRow = (record: WatchlistIntake) => ({ id: intakeRecordId("CASE"), subject: record.subject, subjectType: record.subjectType, category: record.category, priority: record.priority, status: "active" as const, verificationStatus: "pending" as const, caseReference: record.caseReference, owner: operator, lastUpdate: "Intake just now", notes: `Authority reference: ${record.authorityReference}\n${record.notes}` });

  if (isUsingSandbox(db)) {
    if (!allowSandboxWrite) throw new Error("Operational data service is unavailable. Configure DATABASE_URL for persistent imports.");
    const existing = records.filter((record) => caseSeed.some((item) => item.caseReference === record.caseReference));
    if (existing.length) throw new Error(`Case reference already exists: ${existing.map((record) => record.caseReference).join(", ")}. Existing cases are never overwritten by intake.`);
    (caseSeed as Array<ReturnType<typeof buildRow>>).push(...records.map(buildRow));
    return { created: records.length, references: records.map((record) => record.caseReference) };
  }

  await ensureOperationData();
  const existing = records.length ? await db.select({ caseReference: cctvWatchlistCases.caseReference }).from(cctvWatchlistCases).where(inArray(cctvWatchlistCases.caseReference, records.map((record) => record.caseReference))) : [];
  if (existing.length) throw new Error(`Case reference already exists: ${existing.map((record) => record.caseReference).join(", ")}. Existing cases are never overwritten by intake.`);
  const created = records.map(buildRow);
  if (created.length) await db.insert(cctvWatchlistCases).values(created);
  return { created: records.length, references: records.map((record) => record.caseReference) };
}
