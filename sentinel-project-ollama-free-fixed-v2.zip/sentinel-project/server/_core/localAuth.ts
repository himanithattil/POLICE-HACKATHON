import { timingSafeEqual, createHash } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import { COOKIE_NAME } from "@shared/const";
import type { User } from "../../drizzle/schema";

/**
 * Self-contained operator authentication.
 *
 * The original template authenticated every request against Manus's hosted
 * OAuth server (see ./sdk.ts / ./oauth.ts). That only works while the app is
 * running inside Manus's platform — anywhere else (a laptop, a judge's
 * machine, a normal Node host) the exchange call has nothing to talk to, so
 * every "protected"/"admin" tRPC call silently 401s even though the UI looks
 * like it should work.
 *
 * This module replaces that with a single admin passphrase, checked locally
 * and never sent anywhere. It is enough for a single-operator command
 * console / hackathon demo; swap it for a real IdP before any multi-user
 * production deployment.
 */

const ADMIN_KEY = process.env.SENTINEL_ADMIN_KEY ?? "dev-admin-key";
// Falls back to a fixed dev secret so the app works with zero .env setup.
// Set JWT_SECRET yourself for anything beyond local development/demo use.
const SESSION_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET && process.env.JWT_SECRET.length > 0
    ? process.env.JWT_SECRET
    : "sentinel-dev-session-secret-change-me",
);

const SESSION_TTL_SECONDS = 60 * 60 * 12; // 12 hours

export function safeEqual(a: string, b: string): boolean {
  const ha = createHash("sha256").update(a).digest();
  const hb = createHash("sha256").update(b).digest();
  return timingSafeEqual(ha, hb);
}

export function checkAdminKey(candidate: string): boolean {
  return safeEqual(candidate, ADMIN_KEY);
}

export async function issueSessionToken(): Promise<string> {
  return new SignJWT({ role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
    .sign(SESSION_SECRET);
}

export async function verifySessionToken(token: string): Promise<boolean> {
  try {
    const { payload } = await jwtVerify(token, SESSION_SECRET);
    return payload.role === "admin";
  } catch {
    return false;
  }
}

/** Synthetic admin user handed to tRPC context when the session cookie is valid. */
export function localAdminUser(): User {
  const now = new Date();
  return {
    id: 0,
    openId: "local-admin",
    name: "Console Operator",
    email: null,
    loginMethod: "local-admin-key",
    role: "admin",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  } as User;
}

export { COOKIE_NAME };
