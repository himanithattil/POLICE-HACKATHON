import { ENV } from "./env";

export type Role = "system" | "user" | "assistant" | "tool" | "function";

export type TextContent = {
  type: "text";
  text: string;
};

export type ImageContent = {
  type: "image_url";
  image_url: {
    url: string;
    detail?: "auto" | "low" | "high";
  };
};

export type FileContent = {
  type: "file_url";
  file_url: {
    url: string;
    mime_type?: "audio/mpeg" | "audio/wav" | "application/pdf" | "audio/mp4" | "video/mp4" ;
  };
};

export type MessageContent = string | TextContent | ImageContent | FileContent;

export type Message = {
  role: Role;
  content: MessageContent | MessageContent[];
  name?: string;
  tool_call_id?: string;
};

export type Tool = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  };
};

export type ToolChoicePrimitive = "none" | "auto" | "required";
export type ToolChoiceByName = { name: string };
export type ToolChoiceExplicit = {
  type: "function";
  function: {
    name: string;
  };
};

export type ToolChoice =
  | ToolChoicePrimitive
  | ToolChoiceByName
  | ToolChoiceExplicit;

export type InvokeParams = {
  messages: Message[];
  tools?: Tool[];
  toolChoice?: ToolChoice;
  tool_choice?: ToolChoice;
  maxTokens?: number;
  max_tokens?: number;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
  model?: string;
  thinking?: Record<string, unknown>;
  reasoning?: Record<string, unknown>;
};

export type ToolCall = {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
};

export type InvokeResult = {
  id: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: Role;
      content: string | Array<TextContent | ImageContent | FileContent>;
      tool_calls?: ToolCall[];
    };
    finish_reason: string | null;
  }>;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
};

export type JsonSchema = {
  name: string;
  schema: Record<string, unknown>;
  strict?: boolean;
};

export type OutputSchema = JsonSchema;

export type ResponseFormat =
  | { type: "text" }
  | { type: "json_object" }
  | { type: "json_schema"; json_schema: JsonSchema };

const ensureArray = (
  value: MessageContent | MessageContent[]
): MessageContent[] => (Array.isArray(value) ? value : [value]);

const normalizeContentPart = (
  part: MessageContent
): TextContent | ImageContent | FileContent => {
  if (typeof part === "string") {
    return { type: "text", text: part };
  }

  if (part.type === "text") {
    return part;
  }

  if (part.type === "image_url") {
    return part;
  }

  if (part.type === "file_url") {
    return part;
  }

  throw new Error("Unsupported message content part");
};

const normalizeMessage = (message: Message) => {
  const { role, name, tool_call_id } = message;

  if (role === "tool" || role === "function") {
    const content = ensureArray(message.content)
      .map(part => (typeof part === "string" ? part : JSON.stringify(part)))
      .join("\n");

    return {
      role,
      name,
      tool_call_id,
      content,
    };
  }

  const contentParts = ensureArray(message.content).map(normalizeContentPart);

  // If there's only text content, collapse to a single string for compatibility
  if (contentParts.length === 1 && contentParts[0].type === "text") {
    return {
      role,
      name,
      content: contentParts[0].text,
    };
  }

  return {
    role,
    name,
    content: contentParts,
  };
};

const normalizeToolChoice = (
  toolChoice: ToolChoice | undefined,
  tools: Tool[] | undefined
): "none" | "auto" | ToolChoiceExplicit | undefined => {
  if (!toolChoice) return undefined;

  if (toolChoice === "none" || toolChoice === "auto") {
    return toolChoice;
  }

  if (toolChoice === "required") {
    if (!tools || tools.length === 0) {
      throw new Error(
        "tool_choice 'required' was provided but no tools were configured"
      );
    }

    if (tools.length > 1) {
      throw new Error(
        "tool_choice 'required' needs a single tool or specify the tool name explicitly"
      );
    }

    return {
      type: "function",
      function: { name: tools[0].function.name },
    };
  }

  if ("name" in toolChoice) {
    return {
      type: "function",
      function: { name: toolChoice.name },
    };
  }

  return toolChoice;
};

/**
 * Provider resolution.
 *
 * The original template only spoke to Manus's hosted "Forge" relay
 * (ENV.forgeApiUrl/forgeApiKey), which is unreachable outside Manus's own
 * platform — every live-detection call would fail there. This resolves to
 * whichever real provider key is actually available, in this priority order:
 *   1. OPENAI_API_KEY   → OpenAI's Chat Completions API directly (this
 *                          module was already written in that exact wire
 *                          format, so it's closest to a drop-in swap).
 *   2. ANTHROPIC_API_KEY → Claude's Messages API, via a small translation
 *                          layer (see invokeViaAnthropic below).
 *   3. Manus Forge creds → kept for anyone still running inside Manus.
 */
type Provider = "ollama" | "openai" | "anthropic" | "forge";

const DEFAULT_OLLAMA_MODEL = ENV.ollamaModel || "qwen2.5:3b";
const DEFAULT_OPENAI_MODEL = "gpt-4o-mini";
const DEFAULT_ANTHROPIC_MODEL = "claude-3-5-sonnet-20241022";

function resolveProvider(): Provider {
  // Ollama is the default so Sentinel remains fully usable without paid API credits.
  // Set OLLAMA_ENABLED=false to disable it explicitly.
  if ((process.env.OLLAMA_ENABLED ?? "true").toLowerCase() !== "false") return "ollama";
  if (ENV.openaiApiKey.trim()) return "openai";
  if (ENV.anthropicApiKey.trim()) return "anthropic";
  if (ENV.forgeApiKey) return "forge";
  throw new Error("No AI provider is configured. Enable Ollama or configure OPENAI_API_KEY / ANTHROPIC_API_KEY in .env.");
}

const resolveOllamaUrl = (path: string) => `${ENV.ollamaBaseUrl.replace(/\/$/, "")}${path}`;

type OllamaMessage = { role: string; content: string; images?: string[]; name?: string; tool_call_id?: string };

async function imageUrlToOllamaBase64(url: string): Promise<string> {
  const trimmed = url.trim();
  const match = trimmed.match(/^data:image\/[^;]+;base64,(.+)$/s);
  if (match) return match[1];

  if (/^https?:\/\//i.test(trimmed)) {
    const response = await fetch(trimmed);
    if (!response.ok) throw new Error(`Unable to fetch image for Ollama: ${response.status} ${response.statusText}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    let binary = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return Buffer.from(binary, "binary").toString("base64");
  }

  throw new Error("Ollama vision requires an image data URL or an http(s) image URL.");
}

async function normalizeOllamaMessages(messages: Message[]): Promise<{ messages: OllamaMessage[]; hasImages: boolean }> {
  const result: OllamaMessage[] = [];
  let hasImages = false;

  for (const message of messages) {
    if (message.role === "tool" || message.role === "function") {
      const content = ensureArray(message.content)
        .map(part => (typeof part === "string" ? part : JSON.stringify(part)))
        .join("\n");
      result.push({ role: message.role, content, name: message.name, tool_call_id: message.tool_call_id });
      continue;
    }

    const parts = ensureArray(message.content);
    const textParts: string[] = [];
    const images: string[] = [];

    for (const part of parts) {
      if (typeof part === "string") {
        textParts.push(part);
      } else if (part.type === "text") {
        textParts.push(part.text);
      } else if (part.type === "image_url") {
        images.push(await imageUrlToOllamaBase64(part.image_url.url));
        hasImages = true;
      } else if (part.type === "file_url") {
        throw new Error("Ollama does not support file_url content in this request. Convert the file to text or an image first.");
      }
    }

    result.push({
      role: message.role,
      content: textParts.join("\n"),
      ...(images.length ? { images } : {}),
      name: message.name,
      tool_call_id: message.tool_call_id,
    });
  }

  return { messages: result, hasImages };
}

async function invokeViaOllama(params: InvokeParams): Promise<InvokeResult> {
  const { messages, outputSchema, output_schema, maxTokens, max_tokens, model } = params;
  const schema = outputSchema ?? output_schema;
  const normalizedResult = await normalizeOllamaMessages(messages);
  const selectedModel = model ?? (normalizedResult.hasImages ? ENV.ollamaVisionModel : DEFAULT_OLLAMA_MODEL);
  const body: Record<string, unknown> = {
    model: selectedModel,
    messages: normalizedResult.messages,
    stream: false,
    // Vision prompts can be large (system instructions + evidence + image).
    // Ollama defaults to a 4096-token context, which is too small for CCTV analysis.
    // Give the local model a larger context while keeping generation bounded.
    options: {
      num_ctx: 8192,
      ...(typeof (max_tokens ?? maxTokens) === "number" ? { num_predict: max_tokens ?? maxTokens } : {}),
    },
  };
  if (schema) {
    body.format = schema.schema;
  }
  if (!body.options) delete body.options;

  const response = await fetchWithBackoff(resolveOllamaUrl("/api/chat"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Ollama invoke failed: ${response.status} ${response.statusText} – ${errorText}`);
  }
  const data = await response.json() as {
    model: string;
    message?: { role: string; content?: string };
    prompt_eval_count?: number;
    eval_count?: number;
  };
  const content = data.message?.content ?? "";
  return {
    id: `ollama-${Date.now()}`,
    created: Math.floor(Date.now() / 1000),
    model: data.model,
    choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
    usage: data.prompt_eval_count !== undefined || data.eval_count !== undefined
      ? { prompt_tokens: data.prompt_eval_count ?? 0, completion_tokens: data.eval_count ?? 0, total_tokens: (data.prompt_eval_count ?? 0) + (data.eval_count ?? 0) }
      : undefined,
  };
}

const resolveApiUrl = () =>
  ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
    ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
    : "https://forge.manus.im/v1/chat/completions";

const assertApiKey = (provider: Provider = resolveProvider()) => {
  if (provider === "ollama") return "";
  const key = provider === "openai" ? ENV.openaiApiKey : provider === "anthropic" ? ENV.anthropicApiKey : ENV.forgeApiKey;
  if (!key.trim()) {
    throw new Error(`${provider.toUpperCase()} API key is not configured. Check .env beside package.json and restart pnpm dev.`);
  }
  return key.trim();
};

const normalizeResponseFormat = ({
  responseFormat,
  response_format,
  outputSchema,
  output_schema,
}: {
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
}):
  | { type: "json_schema"; json_schema: JsonSchema }
  | { type: "text" }
  | { type: "json_object" }
  | undefined => {
  const explicitFormat = responseFormat || response_format;
  if (explicitFormat) {
    if (
      explicitFormat.type === "json_schema" &&
      !explicitFormat.json_schema?.schema
    ) {
      throw new Error(
        "responseFormat json_schema requires a defined schema object"
      );
    }
    return explicitFormat;
  }

  const schema = outputSchema || output_schema;
  if (!schema) return undefined;

  if (!schema.name || !schema.schema) {
    throw new Error("outputSchema requires both name and schema");
  }

  return {
    type: "json_schema",
    json_schema: {
      name: schema.name,
      schema: schema.schema,
      ...(typeof schema.strict === "boolean" ? { strict: schema.strict } : {}),
    },
  };
};

const RETRY_MAX_RETRIES = 4;
const RETRY_BASE_DELAY_MS = 500;
const RETRY_MAX_DELAY_MS = 30_000;

type FetchInit = NonNullable<Parameters<typeof fetch>[1]>;

const sleep = (ms: number) =>
  new Promise<void>(resolve => setTimeout(resolve, ms));

const parseRetryAfter = (value: string | null): number | undefined => {
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000);
  const at = Date.parse(value);
  return Number.isNaN(at) ? undefined : Math.max(0, at - Date.now());
};

// Equal-jitter exponential backoff. The cap/2 floor guarantees a minimum
// delay so a misbehaving caller loop slows down instead of hammering the
// upstream while it keeps returning errors.
const computeBackoffDelay = (
  attempt: number,
  retryAfterMs?: number
): number => {
  const cap = Math.min(RETRY_BASE_DELAY_MS * 2 ** attempt, RETRY_MAX_DELAY_MS);
  const jittered = cap / 2 + Math.random() * (cap / 2);
  return Math.min(Math.max(jittered, retryAfterMs ?? 0), RETRY_MAX_DELAY_MS);
};

// Retries non-2xx responses and network errors with exponential backoff, then
// returns the final Response so callers keep their existing error handling.
const fetchWithBackoff = async (
  url: string,
  init: FetchInit
): Promise<Response> => {
  let lastError: unknown;

  for (let attempt = 0; attempt <= RETRY_MAX_RETRIES; attempt++) {
    try {
      const response = await fetch(url, init);
      if (response.ok || attempt === RETRY_MAX_RETRIES) {
        return response;
      }

      const retryAfterMs = parseRetryAfter(
        response.headers.get("retry-after")
      );
      try {
        await response.body?.cancel();
      } catch {
        // Body already settled; nothing to clean up.
      }
      console.warn(
        `LLM request retry ${attempt + 1}/${RETRY_MAX_RETRIES} after status ${response.status}`
      );
      await sleep(computeBackoffDelay(attempt, retryAfterMs));
    } catch (error) {
      lastError = error;
      if (attempt === RETRY_MAX_RETRIES) throw error;
      console.warn(
        `LLM request retry ${attempt + 1}/${RETRY_MAX_RETRIES} after network error`
      );
      await sleep(computeBackoffDelay(attempt));
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new Error("LLM request failed after exhausting retries");
};

// --- Anthropic (Claude) translation layer -----------------------------
//
// Anthropic's Messages API differs from the OpenAI shape this module speaks
// natively: the system prompt is a top-level field (not a message), images
// use a distinct content-block shape, and structured JSON output is best
// obtained by forcing a single tool call rather than a response_format
// field. This function translates one InvokeParams call round-trip and
// hands back a result in the same InvokeResult shape callers already expect,
// so nothing outside this file needs to know which provider ran.
async function invokeViaAnthropic(params: InvokeParams): Promise<InvokeResult> {
  const apiKey = assertApiKey("anthropic");
  const { messages, outputSchema, output_schema, maxTokens, max_tokens, model } = params;
  const schema = outputSchema ?? output_schema;

  let systemPrompt = "";
  const anthropicMessages: Array<{ role: "user" | "assistant"; content: unknown[] }> = [];

  for (const message of messages) {
    if (message.role === "system") {
      const parts = ensureArray(message.content);
      systemPrompt += parts.map((part) => (typeof part === "string" ? part : part.type === "text" ? part.text : "")).join("\n");
      continue;
    }
    if (message.role !== "user" && message.role !== "assistant") continue; // tool/function turns aren't used by this app's callers
    const parts = ensureArray(message.content).map((part) => {
      if (typeof part === "string") return { type: "text", text: part };
      if (part.type === "text") return { type: "text", text: part.text };
      if (part.type === "image_url") {
        const url = part.image_url.url;
        if (url.startsWith("data:")) {
          const match = /^data:([^;]+);base64,([\s\S]*)$/.exec(url);
          if (match) return { type: "image", source: { type: "base64", media_type: match[1], data: match[2] } };
        }
        return { type: "image", source: { type: "url", url } };
      }
      return { type: "text", text: "" };
    });
    anthropicMessages.push({ role: message.role, content: parts });
  }

  const body: Record<string, unknown> = {
    model: model ?? DEFAULT_ANTHROPIC_MODEL,
    max_tokens: max_tokens ?? maxTokens ?? 1024,
    system: systemPrompt || undefined,
    messages: anthropicMessages,
  };

  // Force a single tool call shaped like the requested JSON schema so we get
  // reliable structured output without relying on prompt-only JSON coaxing.
  if (schema) {
    body.tools = [{ name: schema.name, description: "Return the requested structured result.", input_schema: schema.schema }];
    body.tool_choice = { type: "tool", name: schema.name };
  }

  const response = await fetchWithBackoff("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic request failed: ${response.status} ${response.statusText} – ${errorText}`);
  }

  const data = (await response.json()) as {
    id: string;
    model: string;
    content: Array<{ type: string; text?: string; input?: unknown }>;
    usage?: { input_tokens: number; output_tokens: number };
  };

  const toolUse = data.content.find((block) => block.type === "tool_use");
  const text = toolUse ? JSON.stringify(toolUse.input) : data.content.map((block) => block.text ?? "").join("");

  return {
    id: data.id,
    created: Math.floor(Date.now() / 1000),
    model: data.model,
    choices: [{ index: 0, message: { role: "assistant", content: text }, finish_reason: "stop" }],
    usage: data.usage
      ? { prompt_tokens: data.usage.input_tokens, completion_tokens: data.usage.output_tokens, total_tokens: data.usage.input_tokens + data.usage.output_tokens }
      : undefined,
  };
}

/**
 * Prints, once at boot, which AI provider (if any) live detection will use.
 * This exists so a missing/misnamed key shows up immediately in the server
 * log instead of only surfacing later as a "Run AI detection" failure.
 */
export function logConfiguredProviders(): void {
  const openai = ENV.openaiApiKey.trim();
  const anthropic = ENV.anthropicApiKey.trim();
  const ollamaEnabled = (process.env.OLLAMA_ENABLED ?? "true").toLowerCase() !== "false";
  console.log(`[llm] .env working directory: ${process.cwd()}`);
  console.log(`[llm] OLLAMA: ${ollamaEnabled ? `enabled (${ENV.ollamaBaseUrl}, model=${ENV.ollamaModel})` : "disabled"}`);
  console.log(`[llm] OPENAI_API_KEY: ${openai ? `detected (${openai.slice(0, 7)}…${openai.slice(-4)})` : "missing"}`);
  console.log(`[llm] ANTHROPIC_API_KEY: ${anthropic ? `detected (${anthropic.slice(0, 7)}…${anthropic.slice(-4)})` : "missing"}`);
  try {
    const provider = resolveProvider();
    console.log(`[llm] Live detection provider: ${provider.toUpperCase()} (ready).`);
  } catch {
    console.log("[llm] Live detection provider: NONE. Enable Ollama or configure OPENAI_API_KEY / ANTHROPIC_API_KEY in .env beside package.json.");
  }
}

export async function invokeLLM(params: InvokeParams): Promise<InvokeResult> {
  const provider = resolveProvider();

  if (provider === "ollama") {
    return invokeViaOllama(params);
  }

  if (provider === "anthropic") {
    return invokeViaAnthropic(params);
  }

  const {
    messages,
    tools,
    toolChoice,
    tool_choice,
    outputSchema,
    output_schema,
    responseFormat,
    response_format,
    model,
    thinking,
    reasoning,
    maxTokens,
    max_tokens,
  } = params;

  const payload: Record<string, unknown> = {
    messages: messages.map(normalizeMessage),
  };

  payload.model = model ?? (provider === "openai" ? DEFAULT_OPENAI_MODEL : undefined);
  if (!payload.model) delete payload.model;

  if (tools && tools.length > 0) {
    payload.tools = tools;
  }

  const normalizedToolChoice = normalizeToolChoice(
    toolChoice || tool_choice,
    tools
  );
  if (normalizedToolChoice) {
    payload.tool_choice = normalizedToolChoice;
  }

  const resolvedMaxTokens = max_tokens ?? maxTokens;
  if (typeof resolvedMaxTokens === "number") {
    payload.max_tokens = resolvedMaxTokens;
  }

  if (thinking) {
    payload.thinking = thinking;
  }
  if (reasoning) {
    payload.reasoning = reasoning;
  }

  const normalizedResponseFormat = normalizeResponseFormat({
    responseFormat,
    response_format,
    outputSchema,
    output_schema,
  });

  if (normalizedResponseFormat) {
    payload.response_format = normalizedResponseFormat;
  }

  const url = provider === "openai" ? "https://api.openai.com/v1/chat/completions" : resolveApiUrl();
  const key = assertApiKey(provider);

  const response = await fetchWithBackoff(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `LLM invoke failed: ${response.status} ${response.statusText} – ${errorText}`
    );
  }

  return (await response.json()) as InvokeResult;
}

export type ModelInfo = {
  id: string;
  object: string;
  created: number;
  owned_by: string;
};

export type ModelsResponse = {
  object: string;
  data: ModelInfo[];
};

export async function listLLMModels(): Promise<ModelsResponse> {
  const provider = resolveProvider();
  if (provider === "ollama") {
    const response = await fetchWithBackoff(resolveOllamaUrl("/api/tags"), {
      headers: { "content-type": "application/json" },
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`List Ollama models failed: ${response.status} ${response.statusText} – ${errorText}`);
    }
    const data = await response.json() as { models?: Array<{ name: string; modified_at?: string }> };
    return {
      object: "list",
      data: (data.models ?? []).map((m) => ({
        id: m.name,
        object: "model",
        created: m.modified_at ? Math.floor(new Date(m.modified_at).getTime() / 1000) : 0,
        owned_by: "ollama",
      })),
    };
  }
  assertApiKey(provider);
  const url = provider === "openai"
    ? "https://api.openai.com/v1/models"
    : ENV.forgeApiUrl && ENV.forgeApiUrl.trim().length > 0
      ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/models`
      : "https://forge.manus.im/v1/models";
  const key = provider === "openai" ? ENV.openaiApiKey : ENV.forgeApiKey;
  const response = await fetchWithBackoff(url, { headers: { authorization: `Bearer ${key}` } });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`List LLM models failed: ${response.status} ${response.statusText} – ${errorText}`);
  }
  return (await response.json()) as ModelsResponse;
}
