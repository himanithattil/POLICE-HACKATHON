import type { Express, Request, Response } from "express";
import { getSessionCookieOptions } from "./cookies";
import { checkAdminKey, issueSessionToken, COOKIE_NAME } from "./localAuth";

export function registerLocalAuthRoutes(app: Express) {
  // Real key-gated login — useful if you deploy this beyond a hackathon demo
  // and want SENTINEL_ADMIN_KEY to actually act as a secret.
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    const key = typeof req.body?.key === "string" ? req.body.key : "";
    if (!key || !checkAdminKey(key)) {
      res.status(401).json({ error: "invalid_key", message: "Administrator key required" });
      return;
    }
    const token = await issueSessionToken();
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: 12 * 60 * 60 * 1000 });
    res.json({ success: true });
  });

  // Frictionless demo login — matches the EntryGate's "no account, password,
  // or external authentication is required" promise for judges. Every
  // `startLogin()` call site in the client hits this. Remove this route (and
  // point startLogin at /api/auth/login with a real prompt) before any
  // deployment where the operator role needs to be an actual secret.
  app.post("/api/auth/demo-login", async (req: Request, res: Response) => {
    const token = await issueSessionToken();
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: 12 * 60 * 60 * 1000 });
    res.json({ success: true });
  });
}
