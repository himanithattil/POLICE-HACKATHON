import { describe, expect, it } from "vitest";
import { resolutionInputSchema, isResolutionOutcomeValid } from "./resolution";

describe("case resolution evidence", () => {
  it("requires a reference and a meaningful evidence summary", () => {
    expect(resolutionInputSchema.safeParse({ outcome: "vehicle_found", evidenceType: "cross_camera", evidenceReference: "PKT-2041", evidenceSummary: "Three chronological camera sightings match the vehicle and were reviewed by the analyst." }).success).toBe(true);
    expect(resolutionInputSchema.safeParse({ outcome: "vehicle_found", evidenceType: "cross_camera", evidenceReference: "", evidenceSummary: "Short" }).success).toBe(false);
  });

  it("only permits found outcomes for the matching subject type", () => {
    expect(isResolutionOutcomeValid("vehicle", "vehicle_found")).toBe(true);
    expect(isResolutionOutcomeValid("vehicle", "person_found")).toBe(false);
    expect(isResolutionOutcomeValid("person", "person_found")).toBe(true);
    expect(isResolutionOutcomeValid("person", "case_solved")).toBe(true);
  });
});
