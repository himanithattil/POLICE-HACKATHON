import { describe, expect, it, vi } from "vitest";

const values = vi.fn().mockResolvedValue(undefined);
const insert = vi.fn(() => ({ values }));

function queryChain<T>(rows: T[]) {
  const chain: any = {
    where: vi.fn(() => chain),
    limit: vi.fn(() => Promise.resolve(rows)),
    then: (resolve: (value: T[]) => unknown, reject?: (reason: unknown) => unknown) => Promise.resolve(rows).then(resolve, reject),
  };
  return chain;
}

const select = vi.fn(() => ({
  from: vi.fn(() => queryChain([{ id: "ALT-2041" }])),
}));

vi.mock("./db", () => ({
  getDb: vi.fn(async () => ({ select, insert })),
}));

import { logVerification } from "./operations";

describe("verification audit persistence", () => {
  it("writes analyst, reason, action, and timestamp fields for an alert decision", async () => {
    const result = await logVerification("alert", "ALT-2041", "verify", "analyst-7", "Confirmed by cross-camera review");

    expect(result).toMatchObject({ success: true, action: "verify", recordId: "ALT-2041", recordType: "alert" });
    expect(result.createdAt).toBeInstanceOf(Date);
    expect(insert).toHaveBeenCalled();
    expect(values).toHaveBeenLastCalledWith(expect.objectContaining({
      recordType: "alert",
      recordId: "ALT-2041",
      action: "verify",
      analystId: "analyst-7",
      reason: "Confirmed by cross-camera review",
      createdAt: expect.any(Date),
    }));
  });
});
