import { z } from "zod";

const gujaratLatitude = z.number().min(20.0, "Latitude must fall within the Gujarat review boundary.").max(24.9, "Latitude must fall within the Gujarat review boundary.");
const gujaratLongitude = z.number().min(68.0, "Longitude must fall within the Gujarat review boundary.").max(74.9, "Longitude must fall within the Gujarat review boundary.");

export const cameraIntakeSchema = z.object({
  id: z.string().trim().toUpperCase().regex(/^[A-Z0-9][A-Z0-9_-]{2,31}$/, "Use a 3–32 character camera ID containing letters, numbers, underscores, or dashes."),
  name: z.string().trim().min(2).max(128),
  district: z.string().trim().min(2).max(80),
  department: z.string().trim().min(2).max(128),
  source: z.string().trim().min(2).max(32),
  status: z.enum(["online", "degraded", "maintenance", "offline"]),
  latitude: gujaratLatitude.optional(),
  longitude: gujaratLongitude.optional(),
  coordinateSource: z.string().trim().min(3).max(160).optional(),
  coordinateAccuracyMeters: z.number().int().min(1).max(10_000).optional(),
}).superRefine((value, context) => {
  const hasLatitude = value.latitude !== undefined;
  const hasLongitude = value.longitude !== undefined;
  if (hasLatitude !== hasLongitude) context.addIssue({ code: "custom", message: "Provide both latitude and longitude, or leave both blank for a label-only source.", path: [hasLatitude ? "longitude" : "latitude"] });
  if (hasLatitude && !value.coordinateSource) context.addIssue({ code: "custom", message: "Verified coordinates require a documented coordinate source.", path: ["coordinateSource"] });
  if (hasLatitude && !value.coordinateAccuracyMeters) context.addIssue({ code: "custom", message: "Verified coordinates require an accuracy estimate in metres.", path: ["coordinateAccuracyMeters"] });
});

export const watchlistIntakeSchema = z.object({
  subject: z.string().trim().min(2).max(128),
  subjectType: z.enum(["vehicle", "person"]),
  category: z.string().trim().min(2).max(128),
  priority: z.enum(["high", "medium", "low"]),
  caseReference: z.string().trim().toUpperCase().min(3).max(48),
  authorityReference: z.string().trim().min(3).max(96),
  notes: z.string().trim().min(4).max(2000),
});

export type CameraIntake = z.infer<typeof cameraIntakeSchema>;
export type WatchlistIntake = z.infer<typeof watchlistIntakeSchema>;

export function isVerifiedCoordinateIntake(input: CameraIntake) {
  return input.latitude !== undefined && input.longitude !== undefined;
}

export function intakeRecordId(prefix: "CAM" | "CASE") {
  return `INTAKE-${prefix}-${crypto.randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
}
