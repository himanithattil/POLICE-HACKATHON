import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { cameraIntakeSchema, isVerifiedCoordinateIntake, watchlistIntakeSchema } from "./intake";
import { appRouter } from "./routers";

describe("operational data intake contracts", () => {
  it("accepts an authorised camera record with documented Gujarat GPS provenance", () => {
    const record = cameraIntakeSchema.parse({ id: "CITY-CAM-101", name: "Riverfront Gate", district: "Ahmedabad", department: "Traffic Police", source: "ONVIF", status: "online", latitude: 23.031, longitude: 72.58, coordinateSource: "Municipal GIS export 2026-08", coordinateAccuracyMeters: 5 });
    expect(isVerifiedCoordinateIntake(record)).toBe(true);
  });

  it("rejects partial or undocumented GPS values while allowing label-only sources", () => {
    expect(cameraIntakeSchema.safeParse({ id: "CITY-CAM-102", name: "Label only", district: "Ahmedabad", department: "Traffic Police", source: "ONVIF", status: "offline" }).success).toBe(true);
    expect(cameraIntakeSchema.safeParse({ id: "CITY-CAM-103", name: "Partial point", district: "Ahmedabad", department: "Traffic Police", source: "ONVIF", status: "online", latitude: 23.031 }).success).toBe(false);
    expect(cameraIntakeSchema.safeParse({ id: "CITY-CAM-104", name: "No provenance", district: "Ahmedabad", department: "Traffic Police", source: "ONVIF", status: "online", latitude: 23.031, longitude: 72.58 }).success).toBe(false);
  });

  it("requires an authority reference for vehicle and person watchlist intake", () => {
    expect(watchlistIntakeSchema.safeParse({ subject: "GJ01AB1234", subjectType: "vehicle", category: "Stolen vehicle", priority: "high", caseReference: "GJ-CASE-100", authorityReference: "FIR-2026-100", notes: "Authorised intake for analyst review." }).success).toBe(true);
    expect(watchlistIntakeSchema.safeParse({ subject: "J. Doe", subjectType: "person", category: "Missing person", priority: "high", caseReference: "GJ-PER-100", authorityReference: "", notes: "Needs authority reference." }).success).toBe(false);
  });

  it("blocks a non-administrator before an operational record can be persisted", async () => {
    const caller = appRouter.createCaller({
      user: { id: 99, openId: "standard-user", name: "Standard User", email: "user@example.com", loginMethod: "manus", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });
    await expect(caller.operations.intake.cameras({ records: [{ id: "CITY-CAM-105", name: "Unauthorised source", district: "Ahmedabad", department: "Traffic Police", source: "ONVIF", status: "online" }] })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
