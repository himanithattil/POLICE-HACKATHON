import { createHash, randomBytes } from "node:crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import { cctvShareLinks } from "../drizzle/schema";
import { getDb } from "./db";

const fallbackLinks = new Map<string, { label: string; expiresAt: number; revoked: boolean }>();
const DEFAULT_TTL_HOURS = 24;

export function hashShareToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function isShareTokenShapeValid(token: string) {
  return /^[a-f0-9]{48}$/.test(token);
}

export async function createShareLink(label = "Read-only command view", ttlHours = DEFAULT_TTL_HOURS) {
  const safeLabel = label.trim().slice(0, 120) || "Read-only command view";
  const safeTtl = Math.min(Math.max(Math.round(ttlHours), 1), 168);
  const token = randomBytes(24).toString("hex");
  const expiresAt = new Date(Date.now() + safeTtl * 60 * 60 * 1000);
  const db = await getDb();
  if (db) {
    await db.insert(cctvShareLinks).values({ tokenHash: hashShareToken(token), label: safeLabel, expiresAt });
  } else {
    fallbackLinks.set(hashShareToken(token), { label: safeLabel, expiresAt: expiresAt.getTime(), revoked: false });
  }
  return { token, label: safeLabel, expiresAt } as const;
}

export async function inspectShareLink(token: string) {
  if (!isShareTokenShapeValid(token)) return { valid: false as const, reason: "invalid" as const };
  const tokenHash = hashShareToken(token);
  const db = await getDb();
  if (!db) {
    const link = fallbackLinks.get(tokenHash);
    if (!link || link.revoked || link.expiresAt <= Date.now()) return { valid: false as const, reason: link?.revoked ? "revoked" as const : "expired" as const };
    return { valid: true as const, label: link.label, expiresAt: new Date(link.expiresAt) };
  }
  const rows = await db.select({ id: cctvShareLinks.id, label: cctvShareLinks.label, expiresAt: cctvShareLinks.expiresAt }).from(cctvShareLinks).where(and(eq(cctvShareLinks.tokenHash, tokenHash), isNull(cctvShareLinks.revokedAt), gt(cctvShareLinks.expiresAt, new Date()))).limit(1);
  const link = rows[0];
  if (!link) return { valid: false as const, reason: "expired" as const };
  await db.update(cctvShareLinks).set({ lastAccessedAt: new Date() }).where(eq(cctvShareLinks.id, link.id));
  return { valid: true as const, label: link.label, expiresAt: link.expiresAt };
}

export async function revokeShareLink(token: string) {
  const tokenHash = hashShareToken(token);
  const db = await getDb();
  if (db) await db.update(cctvShareLinks).set({ revokedAt: new Date() }).where(eq(cctvShareLinks.tokenHash, tokenHash));
  const fallback = fallbackLinks.get(tokenHash);
  if (fallback) fallback.revoked = true;
  return { success: true as const };
}
