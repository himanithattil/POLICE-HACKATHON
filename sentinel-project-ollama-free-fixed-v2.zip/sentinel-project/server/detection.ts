import { z } from "zod";
import { invokeLLM } from "./_core/llm";

export const plateStatusSchema = z.enum(["readable", "unreadable", "not_present", "ambiguous"]);
export type PlateStatus = z.infer<typeof plateStatusSchema>;

export const detectionRequestSchema = z.object({
  cameraId: z.string().trim().min(1).max(64),
  imageUrl: z.string().trim().min(1).max(4_000_000),
  context: z.string().trim().max(500).optional(),
});
export type DetectionRequest = z.infer<typeof detectionRequestSchema>;

export const detectionResultSchema = z.object({
  sceneSummary: z.string().min(1).max(600),
  objects: z.array(z.object({ type: z.string().min(1).max(80), description: z.string().min(1).max(240), confidence: z.number().min(0).max(1) })).max(12),
  suspectedPlate: z.string().trim().max(16).nullable(),
  plateConfidence: z.number().min(0).max(1).nullable(),
  plateStatus: plateStatusSchema,
  anomalyDetected: z.boolean(),
  anomalyDescription: z.string().max(300).nullable(),
  riskLevel: z.enum(["low", "medium", "high"]),
});
export type DetectionResult = z.infer<typeof detectionResultSchema>;

const DETECTION_JSON_SCHEMA = {
  name: "cctv_frame_detection",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    required: ["sceneSummary", "objects", "suspectedPlate", "plateConfidence", "plateStatus", "anomalyDetected", "anomalyDescription", "riskLevel"],
    properties: {
      sceneSummary: { type: "string", description: "One or two sentence factual description of the visible scene." },
      objects: {
        type: "array",
        maxItems: 12,
        items: {
          type: "object",
          additionalProperties: false,
          required: ["type", "description", "confidence"],
          properties: { type: { type: "string", description: "e.g. person, car, motorcycle, bus, truck, bicycle" }, description: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 } },
        },
      },
      suspectedPlate: { type: ["string", "null"], description: "Only a clearly legible vehicle plate. Null if not legible or absent." },
      plateConfidence: { type: ["number", "null"], minimum: 0, maximum: 1 },
      plateStatus: { type: "string", enum: ["readable", "unreadable", "not_present", "ambiguous"], description: "Use readable only when the full plate is clearly legible; otherwise use unreadable, ambiguous, or not_present." },
      anomalyDetected: { type: "boolean", description: "True only for a visually evident unusual event (crowd surge, altercation, abandoned object, collision, intrusion)." },
      anomalyDescription: { type: ["string", "null"] },
      riskLevel: { type: "string", enum: ["low", "medium", "high"] },
    },
  },
} as const;

const SYSTEM_PROMPT = `You are an assistive CCTV frame-triage model inside a police command-center prototype. You describe only what is visually evident in the single supplied frame.
Rules:
- Never invent or guess a licence plate, identity, or event that is not clearly visible.
- Set plateStatus to readable only when the complete plate is clearly legible and plateConfidence is at least 0.70.
- If a plate is partially obscured, blurred, ambiguous, or represented by words such as unknown/unidentified, set suspectedPlate to null, plateConfidence to null, and plateStatus to unreadable or ambiguous.
- If no vehicle plate is visible, set suspectedPlate to null, plateConfidence to null, and plateStatus to not_present.
- A person observation is a person event, never a plate event. Do not copy a plate field into a person subject.
- anomalyDetected must be true only for a clearly visible unusual event, not routine traffic or pedestrian activity.
- This output supports human analyst triage only. It is never a positive identification and must not be presented as one.
- Respond strictly in the required JSON schema with no extra commentary.`;

const UNKNOWN_PLATE_VALUES = new Set(["unknown", "unidentified", "unreadable", "not readable", "not legible", "no plate", "no license plate", "none", "null", "n/a", "na", "-", "—", "unidentified vehicle", "unidentified subject", "plate unreadable", "plate unconfirmed"]);

export function normalizeDetectionResult(result: DetectionResult): DetectionResult {
  const rawPlate = result.suspectedPlate?.trim() ?? "";
  const compact = rawPlate.toLowerCase().replace(/[^a-z0-9]/g, "");
  const normalizedText = rawPlate.toLowerCase().replace(/\s+/g, " ");
  let status: PlateStatus;
  let value: string | null = null;
  let confidence: number | null = null;
  if (!rawPlate) status = "not_present";
  else if (UNKNOWN_PLATE_VALUES.has(normalizedText) || compact.length < 3) status = "unreadable";
  else if (result.plateConfidence == null || result.plateConfidence < 0.7) status = "ambiguous";
  else { status = "readable"; value = compact.toUpperCase(); confidence = result.plateConfidence; }
  return { ...result, suspectedPlate: value, plateConfidence: confidence, plateStatus: status };
}

export async function analyzeFrame(input: DetectionRequest): Promise<DetectionResult> {
  const result = await invokeLLM({
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: [{ type: "text", text: `Camera source: ${input.cameraId}. ${input.context ? `Analyst context: ${input.context}` : "Analyse this frame for the command-center triage queue."}` }, { type: "image_url", image_url: { url: input.imageUrl, detail: "high" } }] },
    ],
    outputSchema: DETECTION_JSON_SCHEMA,
    maxTokens: 700,
  });
  const message = result.choices[0]?.message?.content;
  const text = typeof message === "string" ? message : Array.isArray(message) ? message.map((part) => (part.type === "text" ? part.text : "")).join("") : "";
  if (!text.trim()) throw new Error("The detection model returned an empty response.");
  let parsedJson: unknown;
  try { parsedJson = JSON.parse(text); } catch { throw new Error("The detection model did not return structured JSON output."); }
  const parsed = detectionResultSchema.safeParse(parsedJson);
  if (!parsed.success) throw new Error("The detection model output failed schema validation.");
  return normalizeDetectionResult(parsed.data);
}
