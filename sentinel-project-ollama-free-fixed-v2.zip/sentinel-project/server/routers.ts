import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { cameraIntakeSchema, watchlistIntakeSchema } from "./intake";
import { resolutionInputSchema } from "./resolution";
import { acknowledgeAlert, createDetectionAlert, createIntakeCameras, createIntakeWatchlistRecords, getOperationOverview, logVerification, resolveWatchlistCase } from "./operations";
import { analyzeFrame, detectionRequestSchema, detectionResultSchema } from "./detection";
import { createShareLink, inspectShareLink, revokeShareLink } from "./share";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  operations: router({
    overview: publicProcedure.query(() => getOperationOverview()),
    alerts: router({
      acknowledge: publicProcedure.input(z.object({ id: z.string().min(1) })).mutation(({ input }) => acknowledgeAlert(input.id)),
      verify: publicProcedure.input(z.object({ recordType: z.enum(["alert", "watchlist_case"]), recordId: z.string().min(1), action: z.enum(["verify", "reject", "request_more_evidence"]), reason: z.string().min(4), demo: z.boolean().optional() })).mutation(async ({ input, ctx }) => { if (!ctx.user && !input.demo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in before recording a verification decision." }); return logVerification(input.recordType, input.recordId, input.action, ctx.user?.name ?? "Judge Demo Analyst", input.reason, Boolean(input.demo)); }),
    }),
    cases: router({
      verify: publicProcedure.input(z.object({ recordType: z.literal("watchlist_case"), recordId: z.string().min(1), action: z.enum(["verify", "reject", "request_more_evidence"]), reason: z.string().min(4), demo: z.boolean().optional() })).mutation(async ({ input, ctx }) => { if (!ctx.user && !input.demo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in before recording a verification decision." }); return logVerification(input.recordType, input.recordId, input.action, ctx.user?.name ?? "Judge Demo Analyst", input.reason, Boolean(input.demo)); }),
      resolve: publicProcedure.input(z.object({ id: z.string().min(1), demo: z.boolean().optional() }).merge(resolutionInputSchema)).mutation(async ({ input, ctx }) => { if (!ctx.user && !input.demo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Administrator access is required to resolve a case." }); return resolveWatchlistCase(input.id, input, ctx.user?.name ?? "Judge Demo Operator", Boolean(input.demo)); }),
    }),
    intake: router({
      cameras: publicProcedure.input(z.object({ records: z.array(cameraIntakeSchema).min(1).max(100), demo: z.boolean().optional() })).mutation(async ({ input, ctx }) => { if (!ctx.user && !input.demo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in as the project administrator before importing cameras." }); return createIntakeCameras(input.records, ctx.user?.name ?? "Judge Demo Operator", Boolean(input.demo)); }),
      watchlist: publicProcedure.input(z.object({ records: z.array(watchlistIntakeSchema).min(1).max(100), demo: z.boolean().optional() })).mutation(async ({ input, ctx }) => { if (!ctx.user && !input.demo) throw new TRPCError({ code: "UNAUTHORIZED", message: "Sign in as the project administrator before importing cases." }); return createIntakeWatchlistRecords(input.records, ctx.user?.name ?? "Judge Demo Operator", Boolean(input.demo)); }),
    }),
  }),
  share: router({
    create: publicProcedure.input(z.object({ label: z.string().trim().max(120).optional(), ttlHours: z.number().int().min(1).max(168).optional() })).mutation(({ input }) => createShareLink(input.label, input.ttlHours)),
    inspect: publicProcedure.input(z.object({ token: z.string().min(1) })).query(({ input }) => inspectShareLink(input.token)),
    revoke: protectedProcedure.input(z.object({ token: z.string().min(1) })).mutation(({ input }) => revokeShareLink(input.token)),
  }),
  detection: router({
    // Public on purpose: this is the live-AI proof judges click without signing in.
    // Analysis never writes to the operational ledger by itself.
    analyze: publicProcedure.input(detectionRequestSchema).mutation(({ input }) => analyzeFrame(input)),
    // Committing an analysed frame into the alert ledger remains an authorised, audited action.
    commit: adminProcedure
      .input(z.object({ cameraId: z.string().min(1), result: detectionResultSchema }))
      .mutation(({ input, ctx }) => createDetectionAlert(input.cameraId, input.result, ctx.user.name ?? "Authorised analyst")),
  }),
});

export type AppRouter = typeof appRouter;
