import { describe, expect, it } from "vitest";
import { detectionRequestSchema, detectionResultSchema, normalizeDetectionResult } from "./detection";

describe("live detection contracts", () => {
  it("requires a camera and an image reference to submit a frame", () => {
    expect(detectionRequestSchema.safeParse({ cameraId: "SENTINEL-13", imageUrl: "https://example.com/frame.jpg" }).success).toBe(true);
    expect(detectionRequestSchema.safeParse({ cameraId: "", imageUrl: "https://example.com/frame.jpg" }).success).toBe(false);
    expect(detectionRequestSchema.safeParse({ cameraId: "SENTINEL-13", imageUrl: "" }).success).toBe(false);
  });

  it("accepts a well-formed model result and rejects out-of-range confidence", () => {
    const valid = {
      sceneSummary: "A single sedan is stopped at a signal; no pedestrians in frame.",
      objects: [{ type: "car", description: "Silver sedan facing north", confidence: 0.92 }],
      suspectedPlate: "GJ01AB1234",
      plateConfidence: 0.81,
      plateStatus: "readable",
      anomalyDetected: false,
      anomalyDescription: null,
      riskLevel: "low",
    };
    expect(detectionResultSchema.safeParse(valid).success).toBe(true);

    const badConfidence = { ...valid, objects: [{ ...valid.objects[0], confidence: 1.4 }] };
    expect(detectionResultSchema.safeParse(badConfidence).success).toBe(false);

    const badRisk = { ...valid, riskLevel: "extreme" };
    expect(detectionResultSchema.safeParse(badRisk).success).toBe(false);
  });

  it("allows a null plate and null anomaly description when nothing legible is seen", () => {
    const result = {
      sceneSummary: "Empty street, no vehicles or pedestrians clearly visible.",
      objects: [],
      suspectedPlate: null,
      plateConfidence: null,
      plateStatus: "not_present",
      anomalyDetected: false,
      anomalyDescription: null,
      riskLevel: "low",
    };
    expect(detectionResultSchema.safeParse(result).success).toBe(true);
  });

  it("rejects unknown and low-confidence plate values before they can become matches", () => {
    const base = { sceneSummary: "A vehicle is visible.", objects: [{ type: "car", description: "Vehicle", confidence: 0.9 }], suspectedPlate: "unknown", plateConfidence: 0.99, plateStatus: "readable" as const, anomalyDetected: false, anomalyDescription: null, riskLevel: "low" as const };
    expect(normalizeDetectionResult(base)).toMatchObject({ suspectedPlate: null, plateConfidence: null, plateStatus: "unreadable" });
    expect(normalizeDetectionResult({ ...base, suspectedPlate: "GJ01AB1234", plateConfidence: 0.6 })).toMatchObject({ suspectedPlate: null, plateConfidence: null, plateStatus: "ambiguous" });
  });
});
