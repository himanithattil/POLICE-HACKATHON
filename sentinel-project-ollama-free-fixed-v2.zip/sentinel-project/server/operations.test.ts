import { describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  getDb: vi.fn(async () => null),
}));

import { getOperationOverview } from "./operations";

describe("operations overview sandbox fallback", () => {
  it("returns deterministic demo records when the operational database is unavailable", async () => {
    const overview = await getOperationOverview();

    expect(overview.cameras.length).toBeGreaterThan(0);
    expect(overview.alerts.length).toBeGreaterThan(0);
    expect(overview.watchlistCases.length).toBeGreaterThan(0);
    expect(overview.routePoints.length).toBeGreaterThan(0);
    expect(overview.verificationLogs).toEqual([]);
    expect(overview.cameras.every((camera) => camera.department.includes("Sandbox"))).toBe(true);
  });

  it("exposes exact demo coordinates for the default plate route", async () => {
    const overview = await getOperationOverview();
    const cameraById = new Map(overview.cameras.map((camera) => [camera.id, camera]));
    const plateRoute = overview.routePoints.filter((point) => point.subject === "GJ01QX4821");

    expect(plateRoute).toHaveLength(3);
    expect(plateRoute.every((point) => {
      const camera = cameraById.get(point.cameraId);
      return Boolean(camera && camera.latitude !== 0 && camera.longitude !== 0);
    })).toBe(true);
  });
});
