import { AlertTriangle, Camera, CheckCircle2, Image as ImageIcon, KeyRound, Link2, Radar, ScanEye, ShieldAlert, Sparkles, XCircle } from "lucide-react";
import { ChangeEvent, useMemo, useState } from "react";
import { PageHeading, SectionTitle, DataState } from "@/components/CommandPrimitives";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { isJudgeDemo } from "@/lib/demo";
import { getPlateDisplay, type CameraRecord } from "@/lib/operations";

type DetectionResult = {
  sceneSummary: string;
  objects: { type: string; description: string; confidence: number }[];
  suspectedPlate: string | null;
  plateConfidence: number | null;
  plateStatus: "readable" | "unreadable" | "not_present" | "ambiguous";
  anomalyDetected: boolean;
  anomalyDescription: string | null;
  riskLevel: "low" | "medium" | "high";
};

type Outcome = { tone: "success" | "error" | "info"; text: string } | null;

const MAX_IMAGE_BYTES = 4_500_000;

export default function LiveDetection() {
  const { user, isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const overview = trpc.operations.overview.useQuery();
  const [mode, setMode] = useState<"upload" | "url">("upload");
  const [imageDataUrl, setImageDataUrl] = useState("");
  const [imageUrlInput, setImageUrlInput] = useState("");
  const [fileName, setFileName] = useState("");
  const [cameraId, setCameraId] = useState("");
  const [context, setContext] = useState("");
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [outcome, setOutcome] = useState<Outcome>(null);
  const [committedAlertId, setCommittedAlertId] = useState<string | null>(null);

  const isAdmin = user?.role === "admin";
  const judgeDemo = isJudgeDemo();
  const demoMode = judgeDemo || !isAuthenticated;

  const cameras = (overview.data?.cameras ?? []) as CameraRecord[];
  const activeImage = mode === "upload" ? imageDataUrl : imageUrlInput.trim();

  const analyzeMutation = trpc.detection.analyze.useMutation({
    onSuccess: (data) => {
      setResult(data as DetectionResult);
      setCommittedAlertId(null);
      setOutcome({ tone: "success", text: "Live model inference complete. Review the structured output before any commit." });
    },
    onError: (error) => setOutcome({ tone: "error", text: error.message }),
  });

  const commitMutation = trpc.detection.commit.useMutation({
    onSuccess: async (data) => {
      await utils.operations.overview.invalidate();
      setCommittedAlertId(data.id);
      setOutcome({
        tone: "success",
        text: data.matchedCaseReference
          ? `Alert ${data.id} created and matched to active case ${data.matchedCaseReference}.`
          : `Alert ${data.id} created and queued for analyst review.`,
      });
    },
    onError: (error) => setOutcome({ tone: "error", text: error.message }),
  });

  const selectedCamera = useMemo(() => cameras.find((camera) => camera.id === cameraId), [cameras, cameraId]);

  function loadFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_IMAGE_BYTES) {
      setOutcome({ tone: "error", text: "Image must be 4.5 MB or smaller for a live triage request." });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setImageDataUrl(String(reader.result ?? ""));
      setFileName(file.name);
      setResult(null);
      setOutcome(null);
    };
    reader.readAsDataURL(file);
  }

  function runDetection() {
    setOutcome(null);
    setResult(null);
    setCommittedAlertId(null);
    if (!cameraId) {
      setOutcome({ tone: "error", text: "Select the camera source this frame came from." });
      return;
    }
    if (!activeImage) {
      setOutcome({ tone: "error", text: mode === "upload" ? "Choose a frame image to analyse." : "Paste an image URL to analyse." });
      return;
    }
    analyzeMutation.mutate({ cameraId, imageUrl: activeImage, context: context.trim() || undefined });
  }

  function commitDetection() {
    if (!result || !cameraId) return;
    if (demoMode) {
      setOutcome({ tone: "info", text: "Demo preview only — sign in as administrator to commit this detection to the live alert ledger." });
      return;
    }
    if (!isAdmin) {
      setOutcome({ tone: "error", text: "Only project administrators can commit a detection to the operational ledger." });
      return;
    }
    commitMutation.mutate({ cameraId, result });
  }

  return (
    <div className="page-stack intake-page">
      <PageHeading
        eyebrow="LIVE-AI TRIAGE / DETECT STAGE"
        title={
          <>
            Real inference,<br />
            <span>not a placeholder.</span>
          </>
        }
        description="Submit a single CCTV-style frame to the live vision model. The model returns a structured, schema-validated triage read — object list, plate legibility, and anomaly flag — before any human or operational action."
        actions={
          <div className={`intake-access ${isAdmin ? "intake-access-authorised" : ""}`}>
            <KeyRound size={16} />
            <div>
              <strong>{demoMode ? "HACKATHON DEMO MODE" : isAdmin ? "ADMINISTRATOR READY" : "CONTROLLED ACCESS"}</strong>
              <span>{loading ? "Checking session…" : demoMode ? "Inference runs live · commit disabled" : isAdmin ? "Inference and commit available" : "Sign-in required to commit"}</span>
            </div>
            {!loading && demoMode ? <span className="intake-demo-pill">SAFE PREVIEW</span> : null}
          </div>
        }
      />

      {demoMode ? (
        <div className="intake-demo-banner">
          <Sparkles size={16} />
          <div>
            <strong>Anyone can run a real detection here — no sign-in required</strong>
            <span>The model call is live. Only writing the result into the alert ledger is administrator-protected; no plate is treated as a match unless it is clearly readable.</span>
          </div>
        </div>
      ) : null}

      <section className="intake-governance">
        <div>
          <ScanEye size={18} />
          <strong>Single-frame triage only</strong>
          <span>This analyses one still frame at a time. It is not a live-stream connection and does not store the image.</span>
        </div>
        <div>
          <ShieldAlert size={18} />
          <strong>Never a positive ID</strong>
          <span>Unreadable, absent, and ambiguous plates remain explicitly classified and never become valid matches. Analyst verification is always required.</span>
        </div>
        <div>
          <Radar size={18} />
          <strong>Watchlist cross-check</strong>
          <span>A committed detection is automatically checked against active vehicle watchlist cases before an alert priority is assigned.</span>
        </div>
      </section>

      {outcome ? (
        <div className={`intake-outcome intake-outcome-${outcome.tone}`}>
          {outcome.tone === "success" ? <CheckCircle2 size={17} /> : outcome.tone === "error" ? <XCircle size={17} /> : <KeyRound size={17} />}
          <span>{outcome.text}</span>
          {!isAuthenticated && outcome.tone === "info" ? <button onClick={() => startLogin()}>Sign in</button> : null}
        </div>
      ) : null}

      <section className="intake-layout">
        <article className="command-panel intake-form-panel">
          <SectionTitle eyebrow="FRAME INPUT" title="Submit a frame for live analysis" />
          <div className="intake-switcher" style={{ padding: "0 21px 15px" }}>
            <div role="tablist" aria-label="Choose image source">
              <button className={mode === "upload" ? "intake-tab intake-tab-active" : "intake-tab"} onClick={() => { setMode("upload"); setResult(null); setOutcome(null); }}>
                <ImageIcon size={15} />Upload frame
              </button>
              <button className={mode === "url" ? "intake-tab intake-tab-active" : "intake-tab"} onClick={() => { setMode("url"); setResult(null); setOutcome(null); }}>
                <Link2 size={15} />Image URL
              </button>
            </div>
          </div>
          <div className="intake-form" style={{ padding: "0 21px 21px" }}>
            <div className="intake-form-grid">
              <label className="intake-form-wide">
                Camera source
                <select required value={cameraId} onChange={(event) => setCameraId(event.target.value)}>
                  <option value="">Select a registered camera…</option>
                  {cameras.map((camera) => (
                    <option key={camera.id} value={camera.id}>
                      {camera.id} · {camera.name}
                    </option>
                  ))}
                </select>
              </label>
              {mode === "upload" ? (
                <label className="csv-dropzone intake-form-wide" style={{ minHeight: 120 }}>
                  <Camera size={22} />
                  <strong>{fileName || "Choose a frame image (JPG/PNG)"}</strong>
                  <span>Single frame · up to 4.5 MB · analysed in this request only</span>
                  <input type="file" accept="image/png,image/jpeg,image/webp" onChange={loadFile} />
                </label>
              ) : (
                <label className="intake-form-wide">
                  Image URL
                  <input value={imageUrlInput} onChange={(event) => { setImageUrlInput(event.target.value); setResult(null); }} placeholder="https://…/frame.jpg" />
                </label>
              )}
              <label className="intake-form-wide">
                Analyst context <small>optional</small>
                <textarea value={context} onChange={(event) => setContext(event.target.value)} rows={2} placeholder="e.g. Checking for vehicle GJ01QX4821, or leave blank for general triage." />
              </label>
            </div>
            {mode === "upload" && imageDataUrl ? (
              <div style={{ marginTop: 14 }}>
                <img src={imageDataUrl} alt="Selected frame preview" style={{ maxWidth: "100%", maxHeight: 220, border: "1px solid rgba(255,255,255,.12)" }} />
              </div>
            ) : null}
            <button className="intake-submit" style={{ marginTop: 16 }} disabled={analyzeMutation.isPending} onClick={runDetection}>
              <ScanEye size={16} />
              {analyzeMutation.isPending ? "Running live inference…" : "Run AI detection"}
            </button>
          </div>
        </article>

        <aside className="command-panel intake-guardrail">
          <SectionTitle eyebrow="WHAT HAPPENS" title="Detect → analyst review → commit" />
          <ol>
            <li><b>01</b><span>The frame is sent to the live vision model with a strict, schema-enforced response — no free-text guessing.</span></li>
            <li><b>02</b><span>Results appear here for human review: objects seen, plate legibility, anomaly flag, risk level.</span></li>
            <li><b>03</b><span>An administrator can commit the result, which auto-checks it against the active vehicle watchlist and writes a new alert.</span></li>
            <li><b>04</b><span>Committed alerts appear immediately in Operations and Case Intelligence, prefixed <code>AI-</code>.</span></li>
          </ol>
          <p><ShieldAlert size={15} />This is a triage aid, not an identification system. No image is stored by this workspace.</p>
        </aside>
      </section>

      {analyzeMutation.isPending ? <DataState mode="loading" title="Calling the live vision model" detail="Analysing the submitted frame with schema-enforced output." /> : null}

      {result ? (
        <section className="command-panel judge-proof-panel">
          <SectionTitle eyebrow="MODEL OUTPUT / LIVE RESULT" title="Structured triage read" />
          <p className="panel-intro">{result.sceneSummary}</p>
          <div className="proof-stat-grid">
            <div>
              <b>{result.objects.length}</b>
              <span>objects detected</span>
            </div>
            <div>
              <b>{getPlateDisplay(result.suspectedPlate, result.plateConfidence).label}</b>
              <span>{result.plateStatus === "readable" ? `OCR candidate · ${((result.plateConfidence ?? 0) * 100).toFixed(0)}% confidence` : result.plateStatus === "not_present" ? "No plate visible in source frame" : result.plateStatus === "ambiguous" ? "OCR rejected · confidence below safe threshold" : "OCR rejected · source is not legible"}</span>
            </div>
            <div>
              <span>{result.anomalyDetected ? "YES" : "No"}</span>
              <span>anomaly flagged</span>
            </div>
            <div>
              <b style={{ textTransform: "uppercase" }}>{result.riskLevel}</b>
              <span>model risk level</span>
            </div>
          </div>

          {result.objects.length ? (
            <div className="source-profile-list">
              {result.objects.map((object, index) => (
                <div key={`${object.type}-${index}`} className="source-profile">
                  <div className="source-profile-icon"><ScanEye size={16} /></div>
                  <div>
                    <strong>{object.type}</strong>
                    <span>{object.description}</span>
                  </div>
                  <b>
                    {(object.confidence * 100).toFixed(0)}%<small>confidence</small>
                  </b>
                </div>
              ))}
            </div>
          ) : null}

          {result.anomalyDetected ? (
            <div className="proof-disclosure">
              <AlertTriangle size={14} />
              <span>{result.anomalyDescription ?? "Anomaly flagged without further detail."} Analyst validation of source footage is required before any case or response action.</span>
            </div>
          ) : null}

          <div className="evidence-packet-controls">
            <div style={{ color: "rgba(190,218,247,.7)", fontSize: 10 }}>
              {selectedCamera ? `Camera: ${selectedCamera.id} · ${selectedCamera.name}` : "Camera context unavailable"}
            </div>
            <button
              onClick={commitDetection}
              disabled={commitMutation.isPending || Boolean(committedAlertId)}
              className={committedAlertId ? "packet-button packet-button-staged" : "packet-button"}
            >
              {committedAlertId ? (
                <>
                  <CheckCircle2 size={15} />Committed as {committedAlertId}
                </>
              ) : commitMutation.isPending ? (
                "Committing…"
              ) : demoMode ? (
                "Preview only — sign in to commit"
              ) : (
                "Commit to alert ledger"
              )}
            </button>
          </div>
        </section>
      ) : null}
    </div>
  );
}
