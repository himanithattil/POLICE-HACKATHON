import { CheckCircle2, Filter, RadioTower, Search, ShieldAlert, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { CommandMap } from "@/components/CommandMap";
import { DataState, MetricCard, PageHeading, SectionTitle, StatusBadge } from "@/components/CommandPrimitives";
import { getCameraTelemetry, getDashboardMetrics, type AlertRecord, type CameraRecord, type CameraStatus } from "@/lib/operations";
import { trpc } from "@/lib/trpc";

const filters: Array<CameraStatus | "all"> = ["all", "online", "degraded", "maintenance", "offline"];

export default function CameraRegistry() {
  const [filter, setFilter] = useState<CameraStatus | "all">("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState("SENTINEL-1");
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });

  if (overview.isLoading) return <DataState mode="loading" title="Loading the camera registry" detail="Synchronising coverage, health, and source metadata." />;
  if (overview.error || !overview.data) return <DataState mode="error" title="Camera registry is unavailable" detail="Verify the operational data connection and try again." />;

  const cameras = overview.data.cameras as CameraRecord[];
  const alerts = overview.data.alerts.map((item) => ({ ...item, confidence: item.confidence / 10 })) as AlertRecord[];
  const metrics = getDashboardMetrics(cameras, alerts);
  const healthCounts = { online: cameras.filter((camera) => camera.status === "online").length, degraded: cameras.filter((camera) => camera.status === "degraded").length, offline: cameras.filter((camera) => camera.status === "offline").length };
  const visible = cameras.filter((camera) => (filter === "all" || camera.status === filter) && `${camera.name} ${camera.id} ${camera.district}`.toLowerCase().includes(search.toLowerCase()));
  const selectedCamera = cameras.find((item) => item.id === selected) ?? cameras[0];
  const selectedTelemetry = selectedCamera ? getCameraTelemetry(selectedCamera) : null;

  return <div className="page-stack">
    <PageHeading eyebrow="REGISTRY / SENTINEL SANDBOX" title={<>Camera source<br /><span>of truth.</span></>} description="Browse the uploaded Sentinel catalogue, inspect live-status and stream metadata, and identify sources awaiting independent coordinate verification." actions={<div className="registry-heading-status"><CheckCircle2 size={17} /><div><strong>{metrics.onlineCameras} / {metrics.totalCameras} published</strong><span>Archive-sourced feed registry</span></div></div>} />
    <section className="metrics-grid registry-metrics"><MetricCard label="REGISTERED / SANDBOX" value={metrics.totalCameras} detail="Supplied catalogue only" icon={RadioTower} /><MetricCard label="ONLINE" value={healthCounts.online} detail="Derived from cctvCameras.status" icon={CheckCircle2} tone="green" /><MetricCard label="DEGRADED / OFFLINE" value={`${healthCounts.degraded} / ${healthCounts.offline}`} detail="Derived status counts" icon={ShieldAlert} tone="amber" /><MetricCard label="ARCHITECTURE TARGET" value="80,000+" detail="DEMO / ARCHITECTURE TARGET · not live access" icon={RadioTower} /></section>
    <section className="registry-grid"><article className="command-panel registry-list-panel"><SectionTitle eyebrow="ACTIVE REGISTRY" title="Operational camera catalogue" /><div className="registry-tools"><div className="registry-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search camera, district, or ID" /></div><div className="filter-row"><Filter size={14} />{filters.map((value) => <button key={value} onClick={() => setFilter(value)} className={filter === value ? "filter-active" : ""}>{value}</button>)}</div></div><div className="registry-table-wrap"><table className="registry-table"><thead><tr><th>CAMERA</th><th>AREA / OWNER</th><th>SOURCE</th><th>HEALTH</th><th>RECENT ACTIVITY</th></tr></thead><tbody>{visible.map((camera) => <tr key={camera.id} className={selectedCamera?.id === camera.id ? "registry-selected" : ""}><td><button className="registry-source-select" onClick={() => setSelected(camera.id)} aria-label={`Select ${camera.name}`}><strong>{camera.name}</strong><span>{camera.id}</span></button></td><td><strong>{camera.district}</strong><span>{camera.department}</span></td><td><span className="source-badge">{camera.source}</span></td><td><StatusBadge status={camera.status} /></td><td><strong>{camera.activity}</strong><span>{camera.lastHeartbeat} · {camera.throughput}</span></td></tr>)}</tbody></table>{visible.length === 0 ? <div className="empty-state"><SlidersHorizontal size={24} /><strong>No sources match this filter</strong><span>Try a different camera status or search term.</span></div> : null}</div></article><aside className="command-panel registry-map-panel"><SectionTitle eyebrow="COVERAGE / SELECTED SOURCE" title="Operational map" /><CommandMap cameras={cameras} activeCameraId={selectedCamera?.id} onCameraSelect={setSelected} compact /><div className="registry-selection">{selectedCamera ? <><p className="eyebrow">{selectedCamera.id} · {selectedCamera.source} · SANDBOX</p><h3>{selectedCamera.name}</h3><div><span>{selectedCamera.district}</span><StatusBadge status={selectedCamera.status} /></div><p>{selectedCamera.department} · Last heartbeat {selectedTelemetry?.heartbeat}</p><div className="camera-health-detail"><span>FPS <b>{selectedTelemetry?.fps}</b></span><span>Latency <b>{selectedTelemetry?.latency}</b></span><span>Feed access <b>Sandbox source only</b></span></div><small>DEMO / ARCHITECTURE TARGETS are not claims of Gujarat Police live-feed access.</small></> : null}</div></aside></section>
  </div>;
}
