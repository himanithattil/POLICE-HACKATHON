import { Activity, BellRing, Camera, Check, ChevronDown, ChevronRight, CircleDotDashed, RadioTower, Search, ShieldCheck, XCircle } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { CommandMap } from "@/components/CommandMap";
import { DataState, MetricCard, PageHeading, PriorityBadge, SectionTitle, StatusBadge } from "@/components/CommandPrimitives";
import { getAlertRiskBreakdown, getCamera, getDashboardMetrics, getPersonDisplay, getPlateDisplay, getRoute, type AlertRecord, type CameraRecord, type RoutePoint } from "@/lib/operations";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { isJudgeDemo } from "@/lib/demo";
import { getSharedToken } from "@/lib/share";

const workflow = ["Detect", "Verify", "Correlate", "Trace", "Respond"];

type VerificationAction = "verify" | "reject" | "request_more_evidence";

export default function Operations() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });
  const sharedToken = getSharedToken();
  const sharedAccess = trpc.share.inspect.useQuery({ token: sharedToken ?? "" }, { enabled: Boolean(sharedToken), retry: false, refetchInterval: 60_000 });
  const utils = trpc.useUtils();
  const acknowledgeMutation = trpc.operations.alerts.acknowledge.useMutation({ onSuccess: () => utils.operations.overview.invalidate() });
  const verificationMutation = trpc.operations.alerts.verify.useMutation({ onSuccess: () => utils.operations.overview.invalidate() });
  const [activeCameraId, setActiveCameraId] = useState("SENTINEL-1");
  const [query, setQuery] = useState("");
  const [expandedAlert, setExpandedAlert] = useState<string | null>(null);
  const [feedback, setFeedback] = useState("");
  const [officerLocation, setOfficerLocation] = useState<google.maps.LatLngLiteral | null>(null);

  if (overview.isLoading) return <DataState mode="loading" title="Synchronising the command center" detail="Loading the persisted registry, alert ledger, and route evidence." />;
  if (overview.error || !overview.data) return <DataState mode="error" title="Operational data is unavailable" detail="Verify the database connection and reload the command center." />;

  const cameras = overview.data.cameras as CameraRecord[];
  const alerts = overview.data.alerts.map((item) => ({ ...item, confidence: item.confidence / 10 })) as AlertRecord[];
  const routePoints = overview.data.routePoints.map((item) => ({ ...item, confidence: item.confidence / 10 })) as RoutePoint[];
  const metrics = getDashboardMetrics(cameras, alerts);
  const visibleAlerts = alerts.filter((alert) => alert.status !== "resolved");
  const selectedCamera = getCamera(activeCameraId, cameras) ?? cameras[0];
  const sharedSession = Boolean(sharedToken && sharedAccess.data?.valid);
  const judgeDemo = isJudgeDemo();
  const demoMode = judgeDemo || sharedSession;

  function runTrace() {
    const normalized = query.trim().toLowerCase();
    const personMatch = routePoints.some((point) => point.subjectType === "person" && point.subject.toLowerCase().includes(normalized));
    const vehicleMatch = routePoints.some((point) => point.subjectType === "vehicle" && point.subject.toLowerCase().includes(normalized));
    navigate(personMatch || (!vehicleMatch && /person|pedestrian|human/.test(normalized)) ? "/person-routes" : "/routes");
  }

  function verifyAlert(alert: AlertRecord, action: VerificationAction) {
    const reason = window.prompt(`${action === "verify" ? "Verification" : action === "reject" ? "Rejection" : "Evidence request"} reason for ${alert.id}:`, "Analyst reviewed alert context and source evidence.");
    if (!reason) return;
    if (sharedSession) { setFeedback("This is a read-only shared view."); return; }
    verificationMutation.mutate({ recordType: "alert", recordId: alert.id, action, reason, demo: judgeDemo }, { onSuccess: () => setFeedback(`${alert.id}: ${action.replaceAll("_", " ")} saved with analyst identity and UTC timestamp.`), onError: (error) => setFeedback(error.message) });
  }

  return <div className="page-stack">
    <PageHeading eyebrow="UNIFIED CCTV CONTROL PLANE" title={<>Detection intelligence,<br /><span>mapped to action.</span></>} description="A focused operator workspace for validating network health, prioritising verified events, and tracing movement through the connected camera registry." actions={<div className="trace-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && runTrace()} placeholder="Search plate or person" /><button onClick={runTrace}>Trace <ChevronRight size={15} /></button></div>} />
    <section className="workflow-ribbon command-panel"><div><p className="eyebrow"><span className="live-pulse" />PERSISTED TRAINING SCENARIO</p><h2>From detection to actionable intelligence in one operator workflow.</h2></div><div className="workflow-steps">{workflow.map((step, index) => <div key={step} className={index === workflow.length - 1 ? "workflow-step workflow-step-last" : "workflow-step"}><span>{String(index + 1).padStart(2, "0")}</span>{step}</div>)}</div></section>
    <section className="metrics-grid"><MetricCard label="REGISTERED CAMERAS" value={metrics.totalCameras} detail="Registry source of truth" icon={Camera} /><MetricCard label="NETWORK HEALTH" value={`${metrics.sourceHealth}%`} detail={`${metrics.onlineCameras} sources reporting online`} icon={RadioTower} tone="green" /><MetricCard label="UNACKNOWLEDGED" value={metrics.openAlerts} detail="Priority queue awaiting action" icon={BellRing} tone="amber" /><MetricCard label="VERIFIED EVENTS" value={metrics.verifiedEvents} detail="Derived sandbox window" icon={Activity} /></section>
    {feedback ? <div className="intake-outcome intake-outcome-info"><ShieldCheck size={15} /><span>{feedback}</span></div> : null}
    <section className="dashboard-grid"><article className="command-panel map-panel"><SectionTitle eyebrow="GEO / OPERATIONAL STATUS" title="Sentinel sandbox source coverage" action="Open registry" onAction={() => navigate("/registry")} /><CommandMap cameras={cameras} alerts={visibleAlerts} activeCameraId={selectedCamera?.id} onCameraSelect={setActiveCameraId} officerLocation={officerLocation} onOfficerLocationChange={(location) => setOfficerLocation(location)} /><div className="map-info-strip"><div><p>SELECTED SOURCE</p><strong>{selectedCamera?.name ?? "No source selected"}</strong><span>{selectedCamera?.district} · {selectedCamera?.source}</span></div><StatusBadge status={selectedCamera?.status ?? "offline"} /><div><p>CATALOGUE STATE</p><strong>{selectedCamera?.lastHeartbeat ?? "—"}</strong><span>{selectedCamera?.throughput ?? "—"}</span></div></div></article>
      <aside className="command-panel ledger-panel"><SectionTitle eyebrow="PRIORITY / WATCHLIST CORRELATION" title="Alert ledger" action="Case intelligence" onAction={() => navigate("/watchlist")} /><div className="alert-ledger">{visibleAlerts.map((alert) => { const camera = getCamera(alert.cameraId, cameras); const breakdown = getAlertRiskBreakdown(alert, routePoints); const routeCount = getRoute(alert.subject, alert.subjectType, routePoints).length; const stagedAction = alert.verificationStatus !== "pending" ? alert.verificationStatus : undefined; const plateDisplay = getPlateDisplay(alert.subjectType === "vehicle" ? alert.subject : null, alert.confidence); const subjectDisplay = alert.subjectType === "person" ? getPersonDisplay(alert.subject, alert.subjectType) : plateDisplay.label; return <article key={alert.id} className={`alert-entry alert-entry-${alert.priority}`}><div className="alert-entry-icon">{stagedAction === "reject" ? <XCircle size={17} /> : <ShieldCheck size={17} />}</div><div className="alert-entry-main"><div className="alert-entry-title"><strong>{subjectDisplay}</strong><PriorityBadge priority={alert.priority} /></div><p>{alert.subjectType === "person" ? "PERSON EVENT" : alert.category.toUpperCase()} · {camera?.name}</p><span>{alert.summary}</span><div className="alert-risk-breakdown"><div><b>EXPLAINABLE RISK</b><small>{breakdown.reduce((sum, item) => sum + item.points, 0)} weighted points from persisted fields</small></div>{breakdown.map((item) => <span key={item.label} className={item.present ? "risk-reason-present" : "risk-reason-muted"}>+{item.points} {item.label}</span>)}</div><button className="why-flagged-toggle" onClick={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)} aria-expanded={expandedAlert === alert.id}><ChevronDown size={13} />WHY FLAGGED?</button>{expandedAlert === alert.id ? <div className="why-flagged-panel"><span>✓ {alert.category} signal present</span><span>{routeCount > 1 ? "✓ Cross-camera correlation" : "△ Cross-camera evidence limited"}</span><span>{alert.subjectType === "vehicle" && plateDisplay.status !== "readable" ? `△ ${plateDisplay.label.toLowerCase()}` : "✓ Subject field available"}</span></div> : null}<div className="alert-entry-footer"><time>{alert.timestamp} IST · {alert.confidence.toFixed(1)}% confidence</time><div className="alert-action-row">{sharedSession ? <span className="shared-readonly-badge"><ShieldCheck size={13} />READ-ONLY SHARED VIEW</span> : <>{alert.status === "new" ? <button onClick={() => acknowledgeMutation.mutate({ id: alert.id })} disabled={acknowledgeMutation.isPending}><Check size={13} />Acknowledge</button> : <StatusBadge status={alert.status} />}<button onClick={() => verifyAlert(alert, "verify")} disabled={verificationMutation.isPending || stagedAction !== undefined && stagedAction !== "pending"}><Check size={13} />Verify</button><button onClick={() => verifyAlert(alert, "reject")} disabled={verificationMutation.isPending || stagedAction !== undefined && stagedAction !== "pending"}><XCircle size={13} />Reject</button><button onClick={() => verifyAlert(alert, "request_more_evidence")} disabled={verificationMutation.isPending || stagedAction !== undefined && stagedAction !== "pending"}>More evidence</button></>}</div></div></div></article>; })}</div></aside></section>
    <section className="command-panel activity-panel"><SectionTitle eyebrow="STREAM / RECENT EVENT REGISTER" title="Camera health and recent activity" action="View all sources" onAction={() => navigate("/registry")} /><div className="camera-stream-grid">{cameras.slice(0, 4).map((camera) => <button key={camera.id} className="camera-stream-card" onClick={() => setActiveCameraId(camera.id)}><div className="stream-placeholder"><span className={`stream-status ${camera.status}`} /><CircleDotDashed size={24} /><span>REGISTERED SOURCE</span></div><div className="stream-detail"><div><strong>{camera.name}</strong><span>{camera.department}</span></div><StatusBadge status={camera.status} /></div><p>{camera.activity} · <b>{camera.lastHeartbeat}</b></p></button>)}</div></section>
  </div>;
}
