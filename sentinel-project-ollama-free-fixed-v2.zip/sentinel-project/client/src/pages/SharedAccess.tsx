import { useEffect } from "react";
import { useLocation } from "wouter";
import { ArrowRight, CheckCircle2, Clock3, Link2, ShieldCheck, XCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { clearSharedSession, markSharedSession } from "@/lib/share";

export default function SharedAccess({ token }: { token: string }) {
  const [, setLocation] = useLocation();
  const access = trpc.share.inspect.useQuery({ token }, { retry: false });

  useEffect(() => {
    if (access.data?.valid) markSharedSession(token);
  }, [access.data, token]);

  if (access.isLoading) return <main className="entry-gate"><section className="entry-card share-access-card"><div className="entry-brand"><div className="entry-brand-mark"><Link2 size={21} /></div><div><span>SENTINEL GRID / SHARED ACCESS</span><strong>Verifying link</strong></div></div><div className="share-access-status"><Clock3 size={18} /><div><strong>Checking read-only access</strong><span>Validating this app-native link. No Manus account is required.</span></div></div></section></main>;

  if (!access.data?.valid) { clearSharedSession(); return <main className="entry-gate"><section className="entry-card share-access-card"><div className="entry-brand"><div className="entry-brand-mark"><XCircle size={21} /></div><div><span>SENTINEL GRID / SHARED ACCESS</span><strong>Link unavailable</strong></div></div><div className="share-access-status share-access-status-error"><XCircle size={18} /><div><strong>This share link is expired or invalid</strong><span>Ask the workspace owner for a new read-only link. This page will not redirect you to Manus sign-in.</span></div></div><button type="button" className="share-enter-button" onClick={() => setLocation("/")}><ArrowRight size={16} />Return to access choices</button></section></main>; }

  return <main className="entry-gate"><section className="entry-card share-access-card"><div className="entry-brand"><div className="entry-brand-mark"><ShieldCheck size={21} /></div><div><span>SENTINEL GRID / SHARED ACCESS</span><strong>{access.data.label}</strong></div><span className="entry-status"><i />READ-ONLY</span></div><div className="entry-hero"><p className="eyebrow">INDEPENDENT APP ACCESS / VERIFIED LINK</p><h1>Review the<br /><span>command picture.</span></h1><p className="entry-lede">You are entering a scoped, read-only Sentinel workspace. The link is app-native, expires automatically, and does not require a Manus account.</p></div><div className="share-access-proof"><div><CheckCircle2 size={18} /><span>Link verified</span><small>Token validated by Sentinel</small></div><div><ShieldCheck size={18} /><span>Read-only scope</span><small>No case or intake writes</small></div><div><Clock3 size={18} /><span>Expires</span><small>{new Date(access.data.expiresAt).toLocaleString()}</small></div></div><button type="button" className="share-enter-button" onClick={() => setLocation("/operations")}><span>Open shared workspace</span><ArrowRight size={16} /></button><footer className="entry-footer"><span>Shared observers can review evidence and source provenance.</span><b>DETECT → VERIFY → CORRELATE → TRACE</b></footer></section></main>;
}
