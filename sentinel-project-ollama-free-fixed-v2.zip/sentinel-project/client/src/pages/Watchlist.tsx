import { Archive, ArrowRight, BadgeCheck, Check, CircleAlert, Clock3, FileCheck2, Filter, LockKeyhole, ShieldCheck, UserRoundSearch } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { DataState, PageHeading, PriorityBadge, SectionTitle, StatusBadge } from "@/components/CommandPrimitives";
import { useAuth } from "@/_core/hooks/useAuth";
import { getCamera, getPersonDisplay, getPlateDisplay, type AlertRecord, type CameraRecord, type ResolutionEvidenceType, type ResolutionOutcome, type WatchlistCase } from "@/lib/operations";
import { trpc } from "@/lib/trpc";
import { isJudgeDemo } from "@/lib/demo";
import { getSharedToken } from "@/lib/share";

type ResolutionForm = { outcome: ResolutionOutcome; evidenceType: ResolutionEvidenceType; evidenceReference: string; evidenceSummary: string };
type DemoResolution = ResolutionForm & { resolvedBy: string; resolvedAt: string };
type VerificationAction = "verify" | "reject" | "request_more_evidence";

function outcomeLabel(outcome: ResolutionOutcome) {
  return outcome === "vehicle_found" ? "Vehicle found" : outcome === "person_found" ? "Person found" : "Case solved";
}

function evidenceLabel(evidenceType: ResolutionEvidenceType) {
  return evidenceType === "cross_camera" ? "Cross-camera evidence" : evidenceType === "field_confirmation" ? "Field confirmation" : "Official case record";
}

function defaultOutcome(subjectType: WatchlistCase["subjectType"]): ResolutionOutcome {
  return subjectType === "vehicle" ? "vehicle_found" : "person_found";
}

export default function Watchlist() {
  const [tab, setTab] = useState<"active" | "history">("active");
  const [selectedCaseId, setSelectedCaseId] = useState("CASE-48");
  const [resolutionMessage, setResolutionMessage] = useState("");
  const [resolutionForm, setResolutionForm] = useState<ResolutionForm>({ outcome: "vehicle_found", evidenceType: "cross_camera", evidenceReference: "", evidenceSummary: "" });
  const [verificationMessage, setVerificationMessage] = useState("");
  const { user } = useAuth();
  const judgeDemo = isJudgeDemo();
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });
  const sharedToken = getSharedToken();
  const sharedAccess = trpc.share.inspect.useQuery({ token: sharedToken ?? "" }, { enabled: Boolean(sharedToken), retry: false, refetchInterval: 60_000 });
  const sharedReadOnly = Boolean(sharedToken && sharedAccess.data?.valid);
  const utils = trpc.useUtils();
  const acknowledgeMutation = trpc.operations.alerts.acknowledge.useMutation({ onSuccess: () => utils.operations.overview.invalidate() });
  const resolveMutation = trpc.operations.cases.resolve.useMutation({ onSuccess: (result) => { utils.operations.overview.invalidate(); setResolutionMessage(`${outcomeLabel(result.outcome)} recorded for ${result.caseReference}. Evidence has been retained for audit.`); setTab("history"); }, onError: (error) => setResolutionMessage(error.message) });
  const verificationMutation = trpc.operations.cases.verify.useMutation({ onSuccess: () => { utils.operations.overview.invalidate(); setVerificationMessage("Case approval status updated in the server data store and the verification decision was logged with analyst identity, reason, and UTC timestamp."); }, onError: (error) => setVerificationMessage(error.message) });
  useEffect(() => {
    if (!overview.data) return;
    const cases = overview.data.watchlistCases as WatchlistCase[];
    const selected = cases.find((item) => item.id === selectedCaseId) ?? cases[0];
    if (selected) setResolutionForm((current) => ({ ...current, outcome: defaultOutcome(selected.subjectType) }));
  }, [overview.data, selectedCaseId]);
  if (overview.isLoading) return <DataState mode="loading" title="Loading case intelligence" detail="Synchronising the persisted watchlist, alert ledger, and case history." />;
  if (overview.error || !overview.data) return <DataState mode="error" title="Case intelligence is unavailable" detail="Verify the operational data connection and try again." />;
  const allCases = overview.data.watchlistCases as WatchlistCase[];
  const cameras = overview.data.cameras as CameraRecord[];
  const alerts = overview.data.alerts.map((item) => ({ ...item, confidence: item.confidence / 10 })) as AlertRecord[];
  const casesWithDemo = allCases;
  const cases = casesWithDemo.filter((item) => item.status === (tab === "active" ? "active" : "resolved"));
  const selectedCase = casesWithDemo.find((item) => item.id === selectedCaseId) ?? cases[0];
  const caseAlerts = alerts.filter((alert) => alert.caseReference === selectedCase?.caseReference);
  const outcomeIsValid = Boolean(selectedCase) && (resolutionForm.outcome === "case_solved" || resolutionForm.outcome === defaultOutcome(selectedCase!.subjectType));
  const evidenceIsComplete = resolutionForm.evidenceReference.trim().length >= 4 && resolutionForm.evidenceSummary.trim().length >= 20;
  const resolutionReady = outcomeIsValid && evidenceIsComplete && !resolveMutation.isPending;

  async function verifyCase(action: VerificationAction) {
    if (!selectedCase) return;
    const reason = window.prompt(`${action.replaceAll("_", " ")} reason for ${selectedCase.caseReference}:`, "Analyst reviewed linked detections and case context.");
    if (!reason) return;
    if (sharedReadOnly) { setVerificationMessage("This is a read-only shared view. Verification changes are disabled."); return; }
    if (judgeDemo || !user) {
      verificationMutation.mutate({ recordType: "watchlist_case", recordId: selectedCase.id, action, reason, demo: true });
      return;
    }
    verificationMutation.mutate({ recordType: "watchlist_case", recordId: selectedCase.id, action, reason });
  }

  function submitResolution(event: FormEvent) {
    event.preventDefault();
    if (!selectedCase || selectedCase.status !== "active") return;
    if (sharedReadOnly) { setResolutionMessage("This is a read-only shared view. Case changes are disabled."); return; }
    if (!outcomeIsValid) { setResolutionMessage(`Choose an outcome that matches this ${selectedCase.subjectType} case.`); return; }
    if (!evidenceIsComplete) { setResolutionMessage("Add an evidence reference and a detailed evidence summary before resolving."); return; }
    const resolution = { ...resolutionForm };
    if (judgeDemo || !user) {
      resolveMutation.mutate({ id: selectedCase.id, ...resolution, demo: true });
      return;
    }
    if (user.role !== "admin") { setResolutionMessage("Administrator role required for a production case resolution."); return; }
    resolveMutation.mutate({ id: selectedCase.id, ...resolution });
  }

  return <div className="page-stack">
    <PageHeading eyebrow="MATCHING / PRIORITY SOURCE" title={<>Case intelligence,<br /><span>with context.</span></>} description="Review verified watchlist signals, manage acknowledgement state, and retain resolved cases as auditable operational history." actions={<div className={`case-heading-actions ${judgeDemo ? "case-heading-actions-demo" : ""}`}><BadgeCheck size={18} /><div><strong>{judgeDemo ? "HACKATHON DEMO MODE" : "PERSISTED WORKFLOW"}</strong><span>{judgeDemo ? "Server sandbox · writes enabled" : "Evidence-gated analyst review"}</span></div></div>} />
    <section className="case-tabs"><button className={tab === "active" ? "case-tab-active" : ""} onClick={() => { setTab("active"); setResolutionMessage(""); }}><CircleAlert size={15} />Active watchlist <span>{casesWithDemo.filter((item) => item.status === "active").length}</span></button><button className={tab === "history" ? "case-tab-active" : ""} onClick={() => { setTab("history"); setResolutionMessage(""); }}><Archive size={15} />Resolved history <span>{casesWithDemo.filter((item) => item.status === "resolved").length}</span></button></section>
    {resolutionMessage ? <div className={`resolution-feedback ${resolutionMessage.includes("No database") ? "resolution-feedback-demo" : ""}`}><FileCheck2 size={15} /><span>{resolutionMessage}</span></div> : null}
    <section className="case-layout"><article className="command-panel cases-panel"><SectionTitle eyebrow={tab === "active" ? "AUTHORIZED MATCH RECORDS" : "READ-ONLY CASE HISTORY"} title={tab === "active" ? "Watchlist case register" : "Resolved case register"} /><div className="case-register">{cases.map((item) => <button key={item.id} onClick={() => { setSelectedCaseId(item.id); setResolutionMessage(""); }} className={selectedCase?.id === item.id ? "case-row case-row-selected" : "case-row"}><div className={`case-row-icon ${item.subjectType}`}>{item.subjectType === "person" ? <UserRoundSearch size={17} /> : <ShieldCheck size={17} />}</div><div className="case-row-copy"><div><strong>{item.subjectType === "vehicle" ? getPlateDisplay(item.subject, 100).label : getPersonDisplay(item.subject, item.subjectType)}</strong><PriorityBadge priority={item.priority} /></div><p>{item.category} · {item.caseReference}</p><span>{item.notes}</span></div><ArrowRight className="case-row-arrow" size={16} /></button>)}</div>{cases.length === 0 ? <div className="empty-state"><Archive size={25} /><strong>No cases in this view</strong><span>Resolved cases will appear here after an authorised evidence review.</span></div> : null}</article><aside className="command-panel case-detail-panel">{selectedCase ? <><div className="case-detail-title"><div><p className="eyebrow">{selectedCase.caseReference} · {selectedCase.subjectType.toUpperCase()} CASE</p><h2>{selectedCase.subjectType === "vehicle" ? getPlateDisplay(selectedCase.subject, 100).label : getPersonDisplay(selectedCase.subject, selectedCase.subjectType)}</h2><p>{selectedCase.category} · Owned by {selectedCase.owner}</p></div><PriorityBadge priority={selectedCase.priority} /></div><div className="case-detail-status"><div><p>CASE STATE</p>{selectedCase.status === "active" ? <StatusBadge status="acknowledged" /> : <span className="resolution-state-badge"><Check size={12} />{selectedCase.resolutionOutcome ? outcomeLabel(selectedCase.resolutionOutcome) : "Resolved"}</span>}</div><div><p>LAST UPDATE</p><strong>{selectedCase.lastUpdate} IST</strong></div><div><p>REVIEW GATE</p><strong>{selectedCase.status === "active" ? "Evidence required" : "Audit recorded"}</strong></div></div><div className="case-evidence"><p className="eyebrow">RELATED DETECTIONS</p>{caseAlerts.length ? caseAlerts.map((alert) => { const camera = getCamera(alert.cameraId, cameras); return <article key={alert.id}><div className="evidence-icon"><Clock3 size={14} /></div><div><strong>{alert.timestamp} IST · {camera?.name} · {alert.subjectType === "vehicle" ? getPlateDisplay(alert.subject, alert.confidence).label : getPersonDisplay(alert.subject, alert.subjectType)}</strong><p>{alert.summary}</p><span>{alert.confidence.toFixed(1)}% confidence</span></div>{alert.status === "new" ? <button onClick={() => acknowledgeMutation.mutate({ id: alert.id })} disabled={acknowledgeMutation.isPending}><Check size={13} />ACK</button> : <StatusBadge status={alert.status} />}</article>; }) : <p className="evidence-empty">No linked alerts in the selected case history.</p>}</div>{selectedCase.status === "active" ? <><div className="verification-panel"><div><p className="eyebrow">HUMAN VERIFICATION / AUDIT LOG</p><strong>{sharedReadOnly ? "Read-only shared view" : selectedCase.verificationStatus ? `${selectedCase.verificationStatus.replaceAll("_", " ")}` : "Analyst decision required"}</strong><span>{sharedReadOnly ? "Shared observers can review the evidence but cannot change case state." : "AI is decision support only; record the reason before operational action."}</span></div>{sharedReadOnly ? <span className="shared-readonly-badge"><ShieldCheck size={13} />READ-ONLY SHARED VIEW</span> : <div className="alert-action-row"><button onClick={() => verifyCase("verify")} disabled={verificationMutation.isPending || Boolean(selectedCase.verificationStatus)}><Check size={13} />Verify</button><button onClick={() => verifyCase("reject")} disabled={verificationMutation.isPending || Boolean(selectedCase.verificationStatus)}><CircleAlert size={13} />Reject</button><button onClick={() => verifyCase("request_more_evidence")} disabled={verificationMutation.isPending || Boolean(selectedCase.verificationStatus)}>Request more evidence</button></div>}{verificationMessage ? <small>{verificationMessage}</small> : null}</div>{sharedReadOnly ? <div className="resolved-note"><ShieldCheck size={15} /><div><strong>Read-only shared access</strong><span>Case resolution and verification controls are disabled for shared observers.</span></div></div> : <><div className="case-verification-status" style={{ marginBottom: 12, padding: "10px 12px", border: "1px solid rgba(255,255,255,.14)", background: "rgba(255,255,255,.04)" }}>
      <strong>{selectedCase?.verificationStatus === "verified" ? "✓ CASE APPROVED" : selectedCase?.verificationStatus === "rejected" ? "✕ CASE REJECTED" : selectedCase?.verificationStatus === "more_evidence" ? "↻ MORE EVIDENCE REQUIRED" : "○ PENDING APPROVAL"}</strong>
    </div><form className="resolution-form" onSubmit={submitResolution}><div className="resolution-form-heading"><div><p className="eyebrow">EVIDENCE-GATED OUTCOME</p><h3>Found or solved?</h3></div><LockKeyhole size={17} /></div><p className="resolution-form-intro">Choose the outcome that matches the case type, then document the evidence an analyst reviewed. A resolution cannot be recorded from a blank assertion.</p><div className="resolution-form-grid"><label>Outcome<select value={resolutionForm.outcome} onChange={(event) => setResolutionForm((current) => ({ ...current, outcome: event.target.value as ResolutionOutcome }))}><option value={defaultOutcome(selectedCase.subjectType)}>{outcomeLabel(defaultOutcome(selectedCase.subjectType))}</option><option value="case_solved">Case solved</option></select></label><label>Evidence type<select value={resolutionForm.evidenceType} onChange={(event) => setResolutionForm((current) => ({ ...current, evidenceType: event.target.value as ResolutionEvidenceType }))}><option value="cross_camera">Cross-camera evidence</option><option value="field_confirmation">Field confirmation</option><option value="official_case_record">Official case record</option></select></label><label>Evidence / record reference<input value={resolutionForm.evidenceReference} onChange={(event) => setResolutionForm((current) => ({ ...current, evidenceReference: event.target.value }))} placeholder="e.g. PKT-ALT-2041 or field log" /></label><label>Analyst evidence summary<textarea value={resolutionForm.evidenceSummary} onChange={(event) => setResolutionForm((current) => ({ ...current, evidenceSummary: event.target.value }))} placeholder="Describe what was verified and why it supports this outcome." rows={3} /></label></div><button className="resolve-case-button" type="submit" disabled={!resolutionReady}>{resolveMutation.isPending ? "Recording evidence…" : judgeDemo || !user ? "Stage demo resolution" : "Record outcome & resolve"}</button><p className="resolution-form-footnote">{judgeDemo || !user ? "Judge Demo: this writes to the server-side sandbox and is retained for the running session." : user.role === "admin" ? "Administrator action: saved outcome fields and UTC audit time will be retained." : "Read-only account: an administrator must complete production resolution."}</p></form></>}</> : <div className="resolved-note"><Archive size={15} /><div><strong>{selectedCase.resolutionOutcome ? outcomeLabel(selectedCase.resolutionOutcome) : "This case is resolved"}</strong><span>{selectedCase.resolutionEvidenceType ? `${evidenceLabel(selectedCase.resolutionEvidenceType)} · ${selectedCase.resolutionEvidenceReference}` : "Legacy resolution record retained as history."}</span>{selectedCase.resolutionEvidenceSummary ? <p>{selectedCase.resolutionEvidenceSummary}</p> : null}{selectedCase.resolvedBy ? <small>Recorded by {selectedCase.resolvedBy}{selectedCase.resolvedAt ? ` · ${new Date(selectedCase.resolvedAt).toLocaleString()}` : ""}</small> : null}</div></div>}</> : null}</aside></section>
    <section className="command-panel case-process"><div><p className="eyebrow"><Filter size={13} />CASE REVIEW PROTOCOL</p><h2>Verified signals remain separate from field response.</h2><p>The console supports persisted analyst acknowledgement and documented found/solved outcomes; it does not represent dispatch, identity determination, or real-time field action.</p></div><div className="case-process-points"><span>01 VERIFY</span><span>02 ACKNOWLEDGE</span><span>03 DOCUMENT EVIDENCE</span><span>04 RESOLVE</span></div></section>
  </div>;
}
