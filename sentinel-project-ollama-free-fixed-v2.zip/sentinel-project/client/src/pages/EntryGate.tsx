import { ArrowRight, CheckCircle2, PlayCircle, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { enableJudgeDemo } from "@/lib/demo";

export default function EntryGate() {
  const [, setLocation] = useLocation();

  function enterJudgeDemo() {
    enableJudgeDemo();
    // Silently establish a local operator session too, so verification,
    // resolution, intake, and AI-detection commit actions all work right away
    // instead of surfacing a second "sign in" prompt deeper in the app.
    fetch("/api/auth/demo-login", { method: "POST", credentials: "include" })
      .catch(() => {})
      .finally(() => setLocation("/operations?demo=1&judge=1"));
  }

  return <main className="entry-gate"><div className="entry-grid-glow" /><section className="entry-card"><div className="entry-brand"><div className="entry-brand-mark"><ShieldCheck size={21} /></div><div><span>GUJARAT / COMMAND</span><strong>Sentinel Grid</strong></div><span className="entry-status"><i />SIMULATED FEED</span></div><div className="entry-hero"><p className="eyebrow">GUJARAT CCTV INTELLIGENCE / JUDGE ACCESS</p><h1>Evidence-led<br /><span>command begins here.</span></h1><p className="entry-lede">A focused command workspace for camera coverage, verified plate searches, person routes, and accountable evidence review.</p></div><article className="entry-path entry-path-demo entry-path-primary"><div className="entry-path-icon"><PlayCircle size={18} /></div><div><p className="eyebrow">HACKATHON PRESENTATION MODE / PRIMARY</p><h2>Enter as Hackathon Judge</h2><p>Open the complete demonstration instantly. No account, password, Manus login, or external authentication is required.</p></div><button type="button" className="entry-judge-bypass" aria-label="Enter as Hackathon Judge" onClick={enterJudgeDemo}><span>Enter judge demo</span><ArrowRight size={16} /></button><small><CheckCircle2 size={12} />NO LOGIN · read-only demo access · verified location trail</small></article><div className="entry-proof-strip"><span><ShieldCheck size={14} />30 Sentinel sources</span><span><CheckCircle2 size={14} />Verified plate route</span><span><CheckCircle2 size={14} />Judge-ready walkthrough</span></div><footer className="entry-footer"><span>Demo data is labelled and non-operational.</span><b>DETECT → VERIFY → CORRELATE → TRACE → RESPOND</b></footer></section></main>;
}
