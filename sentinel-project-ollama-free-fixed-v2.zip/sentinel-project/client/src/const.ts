export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;

// Local, self-contained operator sign-in.
//
// The original template redirected to Manus's hosted OAuth portal here, which
// only resolves inside Manus's own platform. This app now issues its own
// session cookie from a tiny local endpoint (see server/_core/localAuthRoutes.ts),
// so "sign in" is instant and works anywhere the server itself runs — no
// external identity provider required.
//
// Call this from an event handler (a button's onClick), not during render —
// it performs a network request and then reloads the page so every query
// picks up the new session.
export const startLogin = () => {
  fetch("/api/auth/demo-login", {
    method: "POST",
    credentials: "include",
  })
    .catch(() => {
      // Even if the request fails, reload so the UI reflects the real state
      // (still signed out) rather than hanging on a stale click.
    })
    .finally(() => {
      window.location.reload();
    });
};
