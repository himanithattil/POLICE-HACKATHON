import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import { CommandLayout } from "./components/CommandLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import CameraRegistry from "./pages/CameraRegistry";
import DataIntake from "./pages/DataIntake";
import EntryGate from "./pages/EntryGate";
import HackathonReadiness from "./pages/HackathonReadiness";
import LiveDetection from "./pages/LiveDetection";
import Operations from "./pages/Operations";
import RouteIntelligence from "./pages/RouteIntelligence";
import Watchlist from "./pages/Watchlist";
import SharedAccess from "./pages/SharedAccess";

function CommandRoutes() {
  return <CommandLayout><Switch>
    <Route path={"/operations"} component={Operations} />
    <Route path={"/registry"} component={CameraRegistry} />
    <Route path={"/watchlist"} component={Watchlist} />
    <Route path={"/routes"}>{() => <RouteIntelligence subjectType="vehicle" />}</Route>
    <Route path={"/person-routes"}>{() => <RouteIntelligence subjectType="person" />}</Route>
    <Route path={"/readiness"} component={HackathonReadiness} />
    <Route path={"/detect"} component={LiveDetection} />
    <Route path={"/intake"} component={DataIntake} />
    <Route path={"/404"} component={NotFound} />
    <Route component={NotFound} />
  </Switch></CommandLayout>;
}

function Router() {
  return <Switch><Route path={"/"} component={EntryGate} /><Route path={"/share/:token"}>{(params) => <SharedAccess token={params.token} />}</Route><Route component={CommandRoutes} /></Switch>;
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
