export type CameraStatus = "online" | "degraded" | "maintenance" | "offline";
export type AlertPriority = "high" | "medium" | "low";
export type AlertStatus = "new" | "acknowledged" | "resolved";
export type VerificationStatus = "pending" | "verified" | "rejected" | "more_evidence";
export type SubjectType = "vehicle" | "person";
export type PlateStatus = "readable" | "unreadable" | "not_present" | "ambiguous";
export type LocationConfidence = "verified" | "low" | "unavailable";

export type CameraRecord = { id: string; name: string; district: string; department: string; status: CameraStatus; source: string; x: number; y: number; latitude: number; longitude: number; coordinateSource?: string; coordinateAccuracyMeters?: number; coordinateVerifiedAt?: string | Date | null; lastHeartbeat: string; activity: string; throughput: string };
export type AlertRecord = { id: string; subject: string; subjectType: SubjectType; category: string; priority: AlertPriority; status: AlertStatus; verificationStatus: VerificationStatus; cameraId: string; timestamp: string; confidence: number; caseReference: string; summary: string };
export type RoutePoint = { id: string; subject: string; subjectType: SubjectType; cameraId: string; timestamp: string; confidence: number; event: string; sequence: number };
export type ResolutionOutcome = "vehicle_found" | "person_found" | "case_solved";
export type ResolutionEvidenceType = "cross_camera" | "field_confirmation" | "official_case_record";
export type WatchlistCase = { id: string; subject: string; subjectType: SubjectType; category: string; priority: AlertPriority; status: "active" | "resolved"; verificationStatus: VerificationStatus; caseReference: string; owner: string; lastUpdate: string; notes: string; resolutionOutcome?: ResolutionOutcome | null; resolutionEvidenceType?: ResolutionEvidenceType | null; resolutionEvidenceReference?: string | null; resolutionEvidenceSummary?: string | null; resolvedBy?: string | null; resolvedAt?: string | Date | null };
export type VerificationAction = "verify" | "reject" | "request_more_evidence";
export type VerificationLog = { id: number; recordType: "alert" | "watchlist_case"; recordId: string; action: VerificationAction; analystId: string; reason: string; createdAt: string | Date };

const UNKNOWN_PLATE_VALUES = new Set(["", "unknown", "unidentified", "unreadable", "not readable", "not legible", "no plate", "no license plate", "none", "null", "n/a", "na", "-", "—", "unidentified vehicle", "unidentified subject", "plate unreadable", "plate unconfirmed"]);

export function normalizePlateReading(value: string | null | undefined, confidence: number | null | undefined): { value: string | null; status: PlateStatus } {
  const cleaned = value?.trim().replace(/\s+/g, " ") ?? "";
  const normalized = cleaned.toLowerCase();
  const safeConfidence = confidence != null && confidence > 1 ? confidence / 100 : confidence;
  if (!cleaned || UNKNOWN_PLATE_VALUES.has(normalized)) return { value: null, status: "not_present" };
  const compact = normalized.replace(/[^a-z0-9]/g, "");
  if (compact.length < 3) return { value: null, status: "unreadable" };
  if (safeConfidence == null || safeConfidence < 0.65) return { value: null, status: "ambiguous" };
  return { value: compact.toUpperCase(), status: "readable" };
}

export function getPlateDisplay(value: string | null | undefined, confidence: number | null | undefined) {
  const plate = normalizePlateReading(value, confidence);
  if (plate.status === "readable") return { ...plate, label: plate.value! };
  return { ...plate, label: plate.status === "not_present" ? "NO PLATE VISIBLE" : plate.status === "ambiguous" ? "PLATE UNCONFIRMED" : "PLATE UNREADABLE" };
}

export function isPersonObject(type: string) { return /person|pedestrian|human|face/i.test(type); }
export function isVehicleObject(type: string) { return /vehicle|car|sedan|suv|truck|bus|motorcycle|motorbike|bike|van|auto|plate/i.test(type); }

export function getDetectionSubjectType(objects: { type: string }[], plateValue: string | null | undefined, plateConfidence: number | null | undefined): SubjectType {
  const hasPerson = objects.some((object) => isPersonObject(object.type));
  const hasVehicle = objects.some((object) => isVehicleObject(object.type));
  const plate = normalizePlateReading(plateValue, plateConfidence);
  if (hasPerson && !hasVehicle) return "person";
  if (hasVehicle || plate.status === "readable") return "vehicle";
  return hasPerson ? "person" : "vehicle";
}

export function getCameraLocationState(camera?: Pick<CameraRecord, "latitude" | "longitude" | "coordinateAccuracyMeters" | "coordinateVerifiedAt">): { confidence: LocationConfidence; label: string; detail: string } {
  if (!camera || !camera.latitude || !camera.longitude) return { confidence: "unavailable", label: "Location unavailable", detail: "Source GPS is not verified for this camera." };
  const accuracy = camera.coordinateAccuracyMeters ?? 0;
  if (!camera.coordinateVerifiedAt && !accuracy) return { confidence: "low", label: "Location low confidence", detail: "Coordinates exist but source verification is pending." };
  return { confidence: accuracy > 150 ? "low" : "verified", label: accuracy > 150 ? "Location low confidence" : "GPS verified", detail: accuracy ? `Source GPS · ±${accuracy} m accuracy` : "Source GPS verified" };
}

export function getEventLocationLabel(camera?: CameraRecord) {
  const state = getCameraLocationState(camera);
  if (state.confidence === "unavailable") return state.label;
  return `${camera?.name ?? "Camera source"} · ${state.label}`;
}

export function getMapLocationDisplay(camera: CameraRecord | undefined, approximateCameraIds: string[] = []) {
  if (!camera) return "Location unavailable";
  if (approximateCameraIds.includes(camera.id)) return `${camera.name} · Approximate map reference`;
  return getEventLocationLabel(camera);
}

export function getPersonDisplay(subject: string, subjectType: SubjectType) {
  return subjectType === "person" ? (subject.trim() && !/^(plate|gj\d|unknown|unidentified)/i.test(subject.trim()) ? subject : "Person detected") : subject;
}

export function getAlertRiskBreakdown(alert: AlertRecord, routePoints: RoutePoint[]) {
  const watchlistCorrelation = alert.caseReference !== "PENDING-REVIEW" ? 20 : 0;
  const detectionConfidence = Math.round(Math.min(18, Math.max(0, alert.confidence * 0.18)));
  const crossCameraConfirmation = Math.min(15, getRoute(alert.subject, alert.subjectType, routePoints).length * 5);
  return [
    { label: "Watchlist correlation", points: watchlistCorrelation, present: watchlistCorrelation > 0 },
    { label: "Detection confidence", points: detectionConfidence, present: detectionConfidence >= 10 },
    { label: "Cross-camera confirmation", points: crossCameraConfirmation, present: crossCameraConfirmation > 0 },
  ];
}

export function getCameraTelemetry(camera: Pick<CameraRecord, "activity" | "throughput" | "lastHeartbeat">) {
  const fps = camera.activity.match(/([0-9]+(?:\.[0-9]+)?)\s*fps/i)?.[1] ?? "—";
  const latency = camera.throughput.match(/([0-9]+)\s*ms/i)?.[1] ?? "—";
  return { fps: fps === "—" ? fps : `${fps} fps`, latency: latency === "—" ? latency : `${latency} ms`, heartbeat: camera.lastHeartbeat };
}

export function getDashboardMetrics(cameraRecords: CameraRecord[], alertRecords: AlertRecord[]) {
  const online = cameraRecords.filter((camera) => camera.status === "online").length;
  const openAlerts = alertRecords.filter((alert) => alert.status === "new").length;
  return { totalCameras: cameraRecords.length, onlineCameras: online, sourceHealth: cameraRecords.length ? Math.round((online / cameraRecords.length) * 100) : 0, openAlerts, verifiedEvents: 16 };
}

export function getCamera(cameraId: string, records: CameraRecord[]) { return records.find((camera) => camera.id === cameraId); }

export function buildLocationSearchQuery(camera: Pick<CameraRecord, "name" | "district">) {
  const cleanedLabel = camera.district.replace(/^\d+\s+/, "").replace(/-/g, " ").replace(/\s+/g, " ").trim();
  const candidate = cleanedLabel || camera.name;
  return `${candidate}, Gujarat, India`;
}

export function getCameraLocationLabel(camera?: CameraRecord) {
  if (!camera) return "Location unavailable";
  const state = getCameraLocationState(camera);
  return state.confidence === "unavailable" ? state.label : `${camera.name} · ${state.label}`;
}

export function formatRouteDistance(meters: number) { return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.round(meters)} m`; }
export function formatRouteDuration(seconds: number) { return `${Math.max(1, Math.round(seconds / 60))} min`; }
export function getRouteHypothesisLabel(index: number) { return index === 0 ? "Recommended road option" : `Alternative road option ${index + 1}`; }

export type RoadLegSummary = { distanceMeters: number; durationSeconds: number; roadSummary: string };
export type ThroughCameraRoutePlan = { index: number; label: string; distanceMeters: number; durationSeconds: number; roadSummary: string; legIndexes: number[]; confidence?: number };

export function createThroughCameraRoutePlans(legOptions: RoadLegSummary[][], maxOptions = 3): ThroughCameraRoutePlan[] {
  if (!legOptions.length || legOptions.some((options) => !options.length)) return [];
  const candidateIndexes = [legOptions.map(() => 0)];
  for (let legIndex = 0; legIndex < legOptions.length && candidateIndexes.length < maxOptions; legIndex += 1) {
    for (let alternativeIndex = 1; alternativeIndex < legOptions[legIndex].length && candidateIndexes.length < maxOptions; alternativeIndex += 1) {
      const next = legOptions.map(() => 0);
      next[legIndex] = alternativeIndex;
      candidateIndexes.push(next);
    }
  }
  return candidateIndexes.map((indexes, index) => {
    const selectedLegs = indexes.map((routeIndex, legIndex) => legOptions[legIndex][routeIndex]);
    return { index, label: getRouteHypothesisLabel(index), distanceMeters: selectedLegs.reduce((total, leg) => total + leg.distanceMeters, 0), durationSeconds: selectedLegs.reduce((total, leg) => total + leg.durationSeconds, 0), roadSummary: `Via ${legOptions.length} sequential camera ${legOptions.length === 1 ? "leg" : "legs"} · ${selectedLegs.map((leg) => leg.roadSummary).filter(Boolean).join(" → ")}`, legIndexes: indexes };
  });
}

export type ReadinessProfile = { sourceCount: number; sourceProfiles: { label: string; count: number }[]; metadataReviewCount: number; priorityReviewCount: number; qualityChecks: { label: string; detail: string; status: "ready" | "review" }[] };

export function getJudgingMetrics(cameraRecords: CameraRecord[], alertRecords: AlertRecord[], cases: WatchlistCase[], routePoints: RoutePoint[]) {
  const verifiedCoordinateCount = cameraRecords.filter((camera) => Boolean(camera.coordinateVerifiedAt) || Boolean(camera.coordinateAccuracyMeters)).length;
  const highConfidenceSightings = routePoints.filter((point) => point.confidence >= 90).length;
  const evidenceBackedResolutions = cases.filter((item) => item.status === "resolved" && Boolean(item.resolutionEvidenceReference && item.resolutionEvidenceSummary)).length;
  return { sourceCount: cameraRecords.length, sourceProfileCount: new Set(cameraRecords.map((camera) => camera.source)).size, highConfidenceSightings, evidenceBackedResolutions, verifiedCoordinateCount, approximateCoordinateCount: cameraRecords.length - verifiedCoordinateCount, priorityAlertCount: alertRecords.filter((alert) => alert.priority === "high").length };
}

export function getReadinessProfile(cameraRecords: CameraRecord[], alertRecords: AlertRecord[]): ReadinessProfile {
  const sourceProfiles = Array.from(new Set(cameraRecords.map((camera) => camera.source))).map((label) => ({ label, count: cameraRecords.filter((camera) => camera.source === label).length }));
  const metadataReviewCount = cameraRecords.filter((camera) => camera.activity.includes("metadata pending")).length;
  const priorityReviewCount = alertRecords.filter((alert) => alert.priority === "high" && alert.status !== "resolved").length;
  return { sourceCount: cameraRecords.length, sourceProfiles, metadataReviewCount, priorityReviewCount, qualityChecks: [{ label: "Low-light & weather review", detail: "Sandbox scenario gate", status: "ready" }, { label: "Blur and occlusion review", detail: "Analyst validation gate", status: "ready" }, { label: "Location coordinate provenance", detail: `${cameraRecords.length} source labels require verification`, status: "review" }, { label: "Feed metadata completeness", detail: `${metadataReviewCount} records await enriched metadata`, status: metadataReviewCount ? "review" : "ready" }] };
}

export function getEvidencePacketSummary(alert: AlertRecord, routePoints: RoutePoint[]) {
  const sightings = routePoints.filter((point) => point.subject === alert.subject && point.subjectType === alert.subjectType).length;
  return { packetId: `PKT-${alert.id}`, sightings, reviewedAt: "Analyst handoff required" };
}

export function getRoute(subject: string, subjectType: SubjectType, records: RoutePoint[]) {
  return records.filter((point) => point.subject === subject && point.subjectType === subjectType).sort((a, b) => a.sequence - b.sequence);
}

export function routeStats(points: RoutePoint[]) {
  const confidence = points.length ? points.reduce((total, point) => total + point.confidence, 0) / points.length : 0;
  return { sightingCount: points.length, confidence: Math.round(confidence * 10) / 10 };
}
