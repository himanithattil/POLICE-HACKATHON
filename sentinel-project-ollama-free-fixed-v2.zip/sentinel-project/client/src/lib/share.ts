const SHARED_SESSION_KEY = "sentinel-shared-session";

export function markSharedSession(token: string) {
  window.sessionStorage.setItem(SHARED_SESSION_KEY, token);
}

export function clearSharedSession() {
  window.sessionStorage.removeItem(SHARED_SESSION_KEY);
}

export function getSharedToken() {
  return window.sessionStorage.getItem(SHARED_SESSION_KEY);
}
