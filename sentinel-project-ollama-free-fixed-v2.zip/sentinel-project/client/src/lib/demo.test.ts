import { describe, expect, it } from "vitest";
import { shouldUseJudgeDemo } from "./demo";

describe("judge demo session boundary", () => {
  it("enables demo mode from the explicit entry query or session flag", () => {
    expect(shouldUseJudgeDemo("?demo=1&judge=1", null)).toBe(true);
    expect(shouldUseJudgeDemo("", "1")).toBe(true);
    expect(shouldUseJudgeDemo("?demo=0", null)).toBe(false);
    expect(shouldUseJudgeDemo("", null)).toBe(false);
  });
});
