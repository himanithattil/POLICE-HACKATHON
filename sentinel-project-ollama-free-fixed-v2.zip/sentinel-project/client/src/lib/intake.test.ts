import { describe, expect, it } from "vitest";
import { parseCameraCsv, parseWatchlistCsv } from "./intake";

describe("Data Intake CSV preview", () => {
  it("accepts a documented GPS camera record and preserves its provenance fields", () => {
    const preview = parseCameraCsv("camera_id,name,district,department,source,status,latitude,longitude,coordinate_source,accuracy_m\nCITY-CAM-1,Riverfront Gate,Ahmedabad,Traffic Police,ONVIF,online,23.031,72.58,Municipal GIS export,5");
    expect(preview.errors).toEqual([]);
    expect(preview.records[0]).toMatchObject({ id: "CITY-CAM-1", latitude: 23.031, longitude: 72.58, coordinateAccuracyMeters: 5 });
  });

  it("flags invalid coordinate pairings and duplicate case references before import", () => {
    expect(parseCameraCsv("camera_id,name,district,department,source,status,latitude\nCITY-CAM-2,West Gate,Ahmedabad,Traffic Police,ONVIF,online,23.031").errors[0]).toContain("latitude and longitude together");
    const watchlist = parseWatchlistCsv("subject,subject_type,category,priority,case_reference,authority_reference,notes\nGJ01AB1234,vehicle,Stolen vehicle,high,GJ-CASE-100,FIR-100,Authorised analyst review\nGJ02AB1234,vehicle,Stolen vehicle,high,GJ-CASE-100,FIR-101,Second review");
    expect(watchlist.errors[0]).toContain("duplicate case_reference");
  });
});
