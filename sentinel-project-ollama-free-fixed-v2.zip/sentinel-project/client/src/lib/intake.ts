export type IntakeKind = "camera" | "watchlist";
export type CsvPreview<T> = { records: T[]; errors: string[]; totalRows: number };

export type CameraIntakeDraft = { id: string; name: string; district: string; department: string; source: string; status: "online" | "degraded" | "maintenance" | "offline"; latitude?: number; longitude?: number; coordinateSource?: string; coordinateAccuracyMeters?: number };
export type WatchlistIntakeDraft = { subject: string; subjectType: "vehicle" | "person"; category: string; priority: "high" | "medium" | "low"; caseReference: string; authorityReference: string; notes: string };

function splitCsvLine(line: string) {
  const cells: string[] = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"' && line[index + 1] === '"') { cell += '"'; index += 1; }
    else if (character === '"') quoted = !quoted;
    else if (character === "," && !quoted) { cells.push(cell.trim()); cell = ""; }
    else cell += character;
  }
  cells.push(cell.trim());
  return cells;
}

function csvRows(text: string) {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
  if (!lines.length) return { headers: [] as string[], rows: [] as string[][] };
  return { headers: splitCsvLine(lines[0]).map((header) => header.trim().toLowerCase().replace(/[ -]/g, "_")), rows: lines.slice(1).map(splitCsvLine) };
}

function field(headers: string[], row: string[], names: string[]) {
  const index = headers.findIndex((header) => names.includes(header));
  return index >= 0 ? row[index]?.trim() ?? "" : "";
}

function numberOrUndefined(value: string) {
  if (!value) return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : Number.NaN;
}

export function parseCameraCsv(text: string): CsvPreview<CameraIntakeDraft> {
  const { headers, rows } = csvRows(text);
  const errors: string[] = [];
  const records: CameraIntakeDraft[] = [];
  const required = ["camera_id", "name", "district", "department", "source", "status"];
  const missing = required.filter((name) => !headers.includes(name) && !(name === "camera_id" && headers.includes("id")));
  if (missing.length) return { records, errors: [`Missing required column(s): ${missing.join(", ")}.`], totalRows: rows.length };
  const ids = new Set<string>();
  rows.forEach((row, index) => {
    const rowNumber = index + 2;
    const id = field(headers, row, ["camera_id", "id"]).toUpperCase();
    const latitude = numberOrUndefined(field(headers, row, ["latitude", "lat"]));
    const longitude = numberOrUndefined(field(headers, row, ["longitude", "lng", "lon"]));
    const accuracy = numberOrUndefined(field(headers, row, ["accuracy_m", "coordinate_accuracy_meters", "accuracy"]));
    const coordinateSource = field(headers, row, ["coordinate_source", "gps_source"]);
    if (!id || !/^[A-Z0-9][A-Z0-9_-]{2,31}$/.test(id)) errors.push(`Row ${rowNumber}: camera_id must be a 3–32 character identifier.`);
    if (ids.has(id)) errors.push(`Row ${rowNumber}: duplicate camera_id ${id}.`);
    ids.add(id);
    if (Boolean(latitude !== undefined) !== Boolean(longitude !== undefined) || Number.isNaN(latitude) || Number.isNaN(longitude)) errors.push(`Row ${rowNumber}: provide valid latitude and longitude together, or leave both blank.`);
    if (latitude !== undefined && longitude !== undefined && (latitude < 20 || latitude > 24.9 || longitude < 68 || longitude > 74.9)) errors.push(`Row ${rowNumber}: coordinates are outside the Gujarat review boundary.`);
    if (latitude !== undefined && (!coordinateSource || !accuracy || Number.isNaN(accuracy))) errors.push(`Row ${rowNumber}: verified coordinates require coordinate_source and accuracy_m.`);
    const status = field(headers, row, ["status"]).toLowerCase();
    if (!["online", "degraded", "maintenance", "offline"].includes(status)) errors.push(`Row ${rowNumber}: status must be online, degraded, maintenance, or offline.`);
    records.push({ id, name: field(headers, row, ["name"]), district: field(headers, row, ["district"]), department: field(headers, row, ["department"]), source: field(headers, row, ["source"]), status: (status || "offline") as CameraIntakeDraft["status"], latitude, longitude, coordinateSource: coordinateSource || undefined, coordinateAccuracyMeters: accuracy });
  });
  return { records, errors, totalRows: rows.length };
}

export function parseWatchlistCsv(text: string): CsvPreview<WatchlistIntakeDraft> {
  const { headers, rows } = csvRows(text);
  const errors: string[] = [];
  const records: WatchlistIntakeDraft[] = [];
  const required = ["subject", "subject_type", "category", "priority", "case_reference", "authority_reference", "notes"];
  const missing = required.filter((name) => !headers.includes(name));
  if (missing.length) return { records, errors: [`Missing required column(s): ${missing.join(", ")}.`], totalRows: rows.length };
  const references = new Set<string>();
  rows.forEach((row, index) => {
    const rowNumber = index + 2;
    const subjectType = field(headers, row, ["subject_type"]).toLowerCase();
    const priority = field(headers, row, ["priority"]).toLowerCase();
    const caseReference = field(headers, row, ["case_reference"]).toUpperCase();
    if (!field(headers, row, ["subject"]) || !field(headers, row, ["category"]) || !field(headers, row, ["authority_reference"]) || !field(headers, row, ["notes"])) errors.push(`Row ${rowNumber}: subject, category, authority_reference, and notes are required.`);
    if (!["vehicle", "person"].includes(subjectType)) errors.push(`Row ${rowNumber}: subject_type must be vehicle or person.`);
    if (!["high", "medium", "low"].includes(priority)) errors.push(`Row ${rowNumber}: priority must be high, medium, or low.`);
    if (references.has(caseReference)) errors.push(`Row ${rowNumber}: duplicate case_reference ${caseReference}.`);
    references.add(caseReference);
    records.push({ subject: field(headers, row, ["subject"]), subjectType: (subjectType || "vehicle") as WatchlistIntakeDraft["subjectType"], category: field(headers, row, ["category"]), priority: (priority || "low") as WatchlistIntakeDraft["priority"], caseReference, authorityReference: field(headers, row, ["authority_reference"]), notes: field(headers, row, ["notes"]) });
  });
  return { records, errors, totalRows: rows.length };
}
