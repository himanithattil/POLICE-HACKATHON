import { describe, expect, it } from "vitest";
import { buildLocationSearchQuery, createThroughCameraRoutePlans, formatRouteDistance, formatRouteDuration, getCameraLocationLabel, getCameraLocationState, getDashboardMetrics, getDetectionSubjectType, getEvidencePacketSummary, getJudgingMetrics, getMapLocationDisplay, getPersonDisplay, getPlateDisplay, getReadinessProfile, getRoute, getRouteHypothesisLabel, routeStats, type AlertRecord, type CameraRecord, type RoutePoint, type WatchlistCase } from "./operations";

const cameras: CameraRecord[] = [
  { id: "A", name: "A", district: "A", department: "A", status: "online", source: "ANPR", x: 1, y: 1, latitude: 23.01, longitude: 72.5, lastHeartbeat: "08:00", activity: "ok", throughput: "99%" },
  { id: "B", name: "B", district: "B", department: "B", status: "offline", source: "Fixed", x: 2, y: 2, latitude: 23.02, longitude: 72.6, lastHeartbeat: "07:00", activity: "down", throughput: "0%" },
];
const alerts: AlertRecord[] = [{ id: "1", subject: "GJ01", subjectType: "vehicle", category: "wanted", priority: "high", status: "new", cameraId: "A", timestamp: "08:00", confidence: 98.7, caseReference: "CASE", summary: "match" }];
const sightings: RoutePoint[] = [{ id: "2", subject: "GJ01", subjectType: "vehicle", cameraId: "A", timestamp: "08:10", confidence: 97.1, event: "First", sequence: 2 }, { id: "1", subject: "GJ01", subjectType: "vehicle", cameraId: "B", timestamp: "08:00", confidence: 98.9, event: "Second", sequence: 1 }];

describe("command center operational data", () => {
  it("derives network health and open alerts from queried records", () => {
    expect(getDashboardMetrics(cameras, alerts)).toMatchObject({ totalCameras: 2, onlineCameras: 1, sourceHealth: 50, openAlerts: 1 });
  });

  it("orders queried route evidence and calculates aggregate confidence", () => {
    const trail = getRoute("GJ01", "vehicle", sightings);
    expect(trail.map((point) => point.id)).toEqual(["1", "2"]);
    expect(routeStats(trail)).toEqual({ sightingCount: 2, confidence: 98 });
  });

  it("builds a display-only Gujarat location query from an uploaded source label", () => {
    expect(buildLocationSearchQuery({ name: "Timbavadi gate-Junagadh", district: "06 Timbavadi gate-Junagadh" })).toBe("Timbavadi gate Junagadh, Gujarat, India");
    expect(getCameraLocationLabel({ id: "A", name: "Timbavadi gate-Junagadh", district: "06 Timbavadi gate-Junagadh", department: "A", status: "online", source: "ANPR", x: 1, y: 1, latitude: 23.01, longitude: 72.5, coordinateVerifiedAt: "2026-08-28T00:00:00Z", coordinateAccuracyMeters: 20, lastHeartbeat: "08:00", activity: "ok", throughput: "99%" })).toBe("Timbavadi gate-Junagadh · GPS verified");
    expect(getCameraLocationLabel()).toBe("Location unavailable");
  });

  it("keeps unreadable plates out of match display and preserves person-route semantics", () => {
    expect(getPlateDisplay("unknown", 99).label).toBe("NO PLATE VISIBLE");
    expect(getPlateDisplay("Unidentified vehicle", 99).label).toBe("NO PLATE VISIBLE");
    expect(getPlateDisplay("GJ01", 42).label).toBe("PLATE UNCONFIRMED");
    expect(getDetectionSubjectType([{ type: "person" }], "GJ01AB1234", 0.99)).toBe("person");
    expect(getPersonDisplay("GJ01AB1234", "person")).toBe("Person detected");
  });

  it("exposes location confidence instead of silently geocoding an unverified camera label", () => {
    expect(getCameraLocationState({ latitude: 0, longitude: 0, coordinateAccuracyMeters: 0, coordinateVerifiedAt: null })).toMatchObject({ confidence: "unavailable", label: "Location unavailable" });
    expect(getCameraLocationState({ latitude: 23.01, longitude: 72.5, coordinateAccuracyMeters: 30, coordinateVerifiedAt: "2026-08-28T00:00:00Z" })).toMatchObject({ confidence: "verified", label: "GPS verified" });
  });

  it("labels a plate route camera as an approximate map reference when source GPS is absent", () => {
    const camera = { ...cameras[0], id: "SENTINEL-15", name: "Suvidha park", latitude: 0, longitude: 0 };
    expect(getMapLocationDisplay(camera, ["SENTINEL-15"])).toBe("Suvidha park · Approximate map reference");
    expect(getMapLocationDisplay(camera)).toBe("Location unavailable");
  });

  it("formats route hypotheses for operator review without presenting them as confirmed travel", () => {
    expect(formatRouteDistance(11240)).toBe("11.2 km");
    expect(formatRouteDuration(1920)).toBe("32 min");
    expect(getRouteHypothesisLabel(0)).toBe("Recommended road option");
    expect(getRouteHypothesisLabel(2)).toBe("Alternative road option 3");
  });

  it("summarises cross-source readiness and evidence packet inputs from training records", () => {
    const profile = getReadinessProfile(cameras, alerts);
    expect(profile.sourceCount).toBe(2);
    expect(profile.sourceProfiles).toEqual([{ label: "ANPR", count: 1 }, { label: "Fixed", count: 1 }]);
    expect(profile.priorityReviewCount).toBe(1);
    expect(getEvidencePacketSummary(alerts[0], sightings)).toEqual({ packetId: "PKT-1", sightings: 2, reviewedAt: "Analyst handoff required" });
  });

  it("derives honest judging metrics from the current records", () => {
    const cases: WatchlistCase[] = [{ id: "CASE-1", subject: "GJ01", subjectType: "vehicle", category: "Stolen vehicle", priority: "high", status: "resolved", caseReference: "CASE-1", owner: "Recovery Desk", lastUpdate: "08:00", notes: "reviewed", resolutionOutcome: "vehicle_found", resolutionEvidenceReference: "PKT-1", resolutionEvidenceSummary: "Field confirmation reconciled with two camera sightings." }];
    const metrics = getJudgingMetrics([{ ...cameras[0], coordinateVerifiedAt: "2026-08-28T00:00:00Z" }, cameras[1]], alerts, cases, [{ ...sightings[0], confidence: 94 }]);
    expect(metrics).toMatchObject({ sourceCount: 2, sourceProfileCount: 2, highConfidenceSightings: 1, evidenceBackedResolutions: 1, verifiedCoordinateCount: 1, approximateCoordinateCount: 1, priorityAlertCount: 1 });
  });

  it("builds every driving hypothesis from ordered legs through each correlated camera", () => {
    const plans = createThroughCameraRoutePlans([
      [{ distanceMeters: 1000, durationSeconds: 120, roadSummary: "Camera 1 → Camera 2" }, { distanceMeters: 1200, durationSeconds: 150, roadSummary: "Alt 1 → 2" }],
      [{ distanceMeters: 800, durationSeconds: 90, roadSummary: "Camera 2 → Camera 3" }, { distanceMeters: 950, durationSeconds: 110, roadSummary: "Alt 2 → 3" }],
    ]);
    expect(plans).toHaveLength(3);
    expect(plans[0]).toMatchObject({ distanceMeters: 1800, durationSeconds: 210, legIndexes: [0, 0] });
    expect(plans[1]).toMatchObject({ legIndexes: [1, 0] });
    expect(plans[2]).toMatchObject({ legIndexes: [0, 1] });
    expect(plans.every((plan) => plan.roadSummary.includes("2 sequential camera legs"))).toBe(true);
  });
});
