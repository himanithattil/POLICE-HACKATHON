export const JUDGE_DEMO_STORAGE_KEY = "sentinel-judge-demo";

export function shouldUseJudgeDemo(search: string, storedValue: string | null) {
  return new URLSearchParams(search).get("demo") === "1" || storedValue === "1";
}

export function isJudgeDemo() {
  if (typeof window === "undefined") return false;
  try {
    const enabled = shouldUseJudgeDemo(window.location.search, window.sessionStorage.getItem(JUDGE_DEMO_STORAGE_KEY));
    if (enabled) window.sessionStorage.setItem(JUDGE_DEMO_STORAGE_KEY, "1");
    return enabled;
  } catch {
    return new URLSearchParams(window.location.search).get("demo") === "1";
  }
}

export function enableJudgeDemo() {
  try { window.sessionStorage.setItem(JUDGE_DEMO_STORAGE_KEY, "1"); } catch {}
}

export function disableJudgeDemo() {
  try { window.sessionStorage.removeItem(JUDGE_DEMO_STORAGE_KEY); } catch {}
}
