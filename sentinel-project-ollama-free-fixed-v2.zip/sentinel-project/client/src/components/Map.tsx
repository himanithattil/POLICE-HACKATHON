/// <reference types="@types/google.maps" />

import { useEffect, useRef, useState, type ReactNode } from "react";
import { usePersistFn } from "@/hooks/usePersistFn";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    google?: typeof google;
  }
}

/**
 * Maps JS provider resolution.
 *
 * The original template only knew how to load the Google Maps JS SDK through
 * Manus's hosted "Forge" relay (VITE_FRONTEND_FORGE_API_KEY /
 * forge.butterfly-effect.dev), which only resolves inside Manus's own
 * platform. Outside Manus that domain isn't reachable, so the script's
 * "error" handler fires immediately and every map/Street View falls back to
 * the static overlay. This resolves to whichever key is actually available:
 *   1. VITE_GOOGLE_MAPS_API_KEY → loaded straight from Google
 *      (maps.googleapis.com), using your own key. This is the path to use
 *      outside Manus.
 *   2. VITE_FRONTEND_FORGE_API_KEY → kept for anyone still running inside
 *      Manus.
 */
const GOOGLE_MAPS_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
const FORGE_API_KEY = import.meta.env.VITE_FRONTEND_FORGE_API_KEY as string | undefined;
const FORGE_BASE_URL = import.meta.env.VITE_FRONTEND_FORGE_API_URL || "https://forge.butterfly-effect.dev";
const MAPS_PROXY_URL = `${FORGE_BASE_URL}/v1/maps/proxy`;
const MAP_SCRIPT_ID = "gujarat-cctv-google-maps";

function resolveMapsScriptSrc(): string | null {
  if (GOOGLE_MAPS_KEY) {
    return `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_KEY}&v=weekly&libraries=marker,places,geocoding,geometry`;
  }
  if (FORGE_API_KEY) {
    return `${MAPS_PROXY_URL}/maps/api/js?key=${FORGE_API_KEY}&v=weekly&libraries=marker,places,geocoding,geometry`;
  }
  return null;
}

let mapsScriptPromise: Promise<void> | null = null;
let mapProviderUnavailable = false;

function loadMapScript(): Promise<void> {
  if (window.google?.maps) return Promise.resolve();
  if (mapProviderUnavailable) return Promise.reject(new Error("Google Maps provider unavailable"));
  if (mapsScriptPromise) return mapsScriptPromise;

  const scriptSrc = resolveMapsScriptSrc();
  if (!scriptSrc) {
    mapProviderUnavailable = true;
    return Promise.reject(
      new Error("No Google Maps key is configured. Set VITE_GOOGLE_MAPS_API_KEY in your .env file.")
    );
  }

  mapsScriptPromise = new Promise<void>((resolve, reject) => {
    const existingScript = document.getElementById(MAP_SCRIPT_ID) as HTMLScriptElement | null;
    const script = existingScript ?? document.createElement("script");

    const completeLoad = () => {
      if (window.google?.maps) resolve();
      else reject(new Error("Google Maps loaded without its runtime."));
    };

    script.addEventListener("load", completeLoad, { once: true });
    script.addEventListener("error", () => {
      mapProviderUnavailable = true;
      reject(new Error("Google Maps could not be loaded."));
    }, { once: true });

    if (!existingScript) {
      script.id = MAP_SCRIPT_ID;
      script.src = scriptSrc;
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);
    }
  }).catch((error) => {
    mapsScriptPromise = null;
    throw error;
  });

  return mapsScriptPromise!;
}

interface MapViewProps {
  className?: string;
  initialCenter?: google.maps.LatLngLiteral;
  initialZoom?: number;
  onMapReady?: (map: google.maps.Map) => void;
  fallback?: ReactNode;
}

export function MapView({ className, initialCenter = { lat: 37.7749, lng: -122.4194 }, initialZoom = 12, onMapReady, fallback }: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const [loadError, setLoadError] = useState(false);

  const init = usePersistFn(async () => {
    try {
      await loadMapScript();
      if (!mapContainer.current || map.current || !window.google?.maps) return;
      map.current = new window.google.maps.Map(mapContainer.current, {
        zoom: initialZoom,
        center: initialCenter,
        mapTypeId: "roadmap",
        mapTypeControl: true,
        fullscreenControl: true,
        zoomControl: true,
        streetViewControl: true,
        mapId: "DEMO_MAP_ID",
        styles: [
          { featureType: "all", elementType: "labels.text.fill", stylers: [{ color: "#17324d" }] },
          { featureType: "all", elementType: "labels.text.stroke", stylers: [{ color: "#f5fbff" }, { weight: 2 }] },
          { featureType: "landscape", elementType: "geometry.fill", stylers: [{ color: "#dcecf0" }] },
          { featureType: "water", elementType: "geometry.fill", stylers: [{ color: "#9bd5e4" }] },
          { featureType: "road", elementType: "geometry.fill", stylers: [{ color: "#ffffff" }] },
          { featureType: "road.arterial", elementType: "geometry.fill", stylers: [{ color: "#f2c27e" }] },
          { featureType: "road.highway", elementType: "geometry.fill", stylers: [{ color: "#e7a85f" }] },
          { featureType: "poi", elementType: "geometry.fill", stylers: [{ color: "#bdd8b6" }] },
        ],
      });
      onMapReady?.(map.current);
    } catch {
      // The live provider is optional. The command console remains usable through
      // its verified static coordinate overlay when the provider is unavailable.
      setLoadError(true);
    }
  });

  function retryMapLoad() {
    document.getElementById(MAP_SCRIPT_ID)?.remove();
    mapsScriptPromise = null;
    mapProviderUnavailable = false;
    setLoadError(false);
    void init();
  }

  useEffect(() => {
    init();
  }, [init]);

  if (loadError) return <div className={cn("w-full h-[500px] relative", className)} role="status">{fallback}<button type="button" onClick={retryMapLoad} className="absolute bottom-3 right-3 z-20 border border-cyan-100 bg-cyan-100 px-3 py-2 text-xs font-bold text-[#082d4d] transition active:scale-[.97]">Retry live map</button></div>;
  return <div ref={mapContainer} className={cn("w-full h-[500px]", className)} />;
}
