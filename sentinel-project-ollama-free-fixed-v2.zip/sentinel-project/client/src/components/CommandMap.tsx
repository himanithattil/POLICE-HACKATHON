import { Crosshair, MapPin, Navigation, RotateCcw } from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useMemo, useRef, useState, type DragEvent } from "react";
import type { AlertRecord, CameraRecord, RoutePoint } from "@/lib/operations";
import { buildLocationSearchQuery, getCamera } from "@/lib/operations";
import { cn } from "@/lib/utils";

export type OfficerRouteGuidance = { distanceMeters: number; durationSeconds: number; targetLabel: string };
export type RoadRouteHypothesis = { index: number; label: string; distanceMeters: number; durationSeconds: number; roadSummary: string; legIndexes: number[] };

type CommandMapProps = {
  cameras: CameraRecord[];
  alerts?: AlertRecord[];
  route?: RoutePoint[];
  activeCameraId?: string;
  onCameraSelect?: (cameraId: string) => void;
  officerLocation?: { lat: number; lng: number } | null;
  onOfficerRouteChange?: (guidance: OfficerRouteGuidance | null) => void;
  onOfficerLocationChange?: (location: { lat: number; lng: number }) => void;
  onRoadRouteHypothesesChange?: (hypotheses: RoadRouteHypothesis[]) => void;
  onApproximateLocationsChange?: (cameraIds: string[]) => void;
  selectedRoadRouteIndex?: number;
  className?: string;
  compact?: boolean;
};

type LatLng = { lat: number; lng: number };

type CachedGeo = { lat: number; lng: number; source: "nominatim" | "fallback"; label: string };

const DEFAULT_CENTER: LatLng = { lat: 22.53, lng: 72.72 };
const GEO_CACHE_KEY = "sentinel-camera-geocodes-v2";
const FALLBACKS: Array<[RegExp, LatLng]> = [
  [/ahmedabad|paldi|visat|ongc|janpath|chiman/i, { lat: 23.0225, lng: 72.5714 }],
  [/junagadh|timbavadi|majewadi|dolatpara|bypass|char chowk|hero showroom/i, { lat: 21.5222, lng: 70.4579 }],
  [/rajkot|bus port/i, { lat: 22.3039, lng: 70.8022 }],
  [/navsari|khaparia|gandevi|bilimora/i, { lat: 20.9467, lng: 72.9520 }],
  [/patan|dethali/i, { lat: 23.8493, lng: 72.1266 }],
  [/gandhinagar|adalaj/i, { lat: 23.2156, lng: 72.6369 }],
  [/dehgam/i, { lat: 23.1683, lng: 72.5594 }],
  [/gandhidham|rambaugh/i, { lat: 23.0753, lng: 70.1337 }],
  [/gir somnath/i, { lat: 20.9000, lng: 70.4000 }],
  [/anand/i, { lat: 22.5645, lng: 72.9289 }],
  [/tankal/i, { lat: 21.3000, lng: 73.0000 }],
];

function fallbackLocation(camera: CameraRecord): LatLng {
  const query = `${camera.name} ${camera.district}`;
  const match = FALLBACKS.find(([pattern]) => pattern.test(query));
  return match?.[1] ?? DEFAULT_CENTER;
}

function readGeoCache(): Record<string, CachedGeo> {
  try { return JSON.parse(localStorage.getItem(GEO_CACHE_KEY) || "{}"); } catch { return {}; }
}
function writeGeoCache(cache: Record<string, CachedGeo>) {
  try { localStorage.setItem(GEO_CACHE_KEY, JSON.stringify(cache)); } catch { /* private browsing */ }
}

function cameraIcon(camera: CameraRecord, alert: AlertRecord | undefined, selected: boolean, routeIndex: number, approximate: boolean) {
  const tone = alert?.priority === "high" ? "critical" : camera.status;
  const colors: Record<string, string> = { online: "#22c55e", degraded: "#f59e0b", maintenance: "#38bdf8", offline: "#64748b", critical: "#ef4444" };
  const color = colors[tone] ?? colors.offline;
  const label = routeIndex >= 0 ? String(routeIndex + 1) : "";
  return L.divIcon({
    className: "sentinel-camera-icon",
    iconSize: [42, 42],
    iconAnchor: [21, 21],
    html: `<div style="width:34px;height:34px;border-radius:50%;background:${color};border:3px solid #fff;box-shadow:0 3px 12px rgba(0,0,0,.35),${selected ? `0 0 0 4px ${color}` : "none"};display:flex;align-items:center;justify-content:center;color:#071522;font:800 12px system-ui;">${label || "●"}</div>${approximate ? '<span style="position:absolute;right:-2px;top:-2px;background:#111827;color:#facc15;border:1px solid #facc15;border-radius:8px;padding:0 3px;font:800 9px system-ui">≈</span>' : ''}`,
  });
}

// Small yellow Street View-style person. It is intentionally a standalone map control,
// not an overlay on camera labels, and remains draggable on every map instance.
function pegmanIcon() {
  return L.divIcon({ className: "sentinel-pegman-icon", iconSize: [42, 52], iconAnchor: [21, 47], html: `<div style="width:38px;height:48px;display:flex;align-items:flex-end;justify-content:center;filter:drop-shadow(0 2px 3px rgba(0,0,0,.45))"><svg width="34" height="46" viewBox="0 0 34 46" xmlns="http://www.w3.org/2000/svg"><circle cx="17" cy="8" r="6" fill="#FFD23F" stroke="#fff" stroke-width="2"/><path d="M11 16c0-2 1.8-3.5 4-3.5h4c2.2 0 4 1.5 4 3.5v11l-3 0v14h-6V27h-3V16Z" fill="#FFD23F" stroke="#fff" stroke-width="2" stroke-linejoin="round"/><path d="M11 20 5 31M23 20l6 11" stroke="#FFD23F" stroke-width="4" stroke-linecap="round"/><path d="M12 41 9 45M22 41l3 4" stroke="#FFD23F" stroke-width="4" stroke-linecap="round"/></svg></div>` });
}

async function geocodeCamera(camera: CameraRecord): Promise<CachedGeo> {
  if (camera.latitude !== 0 && camera.longitude !== 0) return { lat: camera.latitude, lng: camera.longitude, source: "nominatim", label: "verified GPS" };
  const cache = readGeoCache();
  const cached = cache[camera.id];
  if (cached) return cached;
  const query = encodeURIComponent(buildLocationSearchQuery(camera));
  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=in&q=${query}`, { headers: { Accept: "application/json" } });
    if (response.ok) {
      const rows = await response.json() as Array<{ lat: string; lon: string; display_name: string }>;
      if (rows[0]) {
        const value: CachedGeo = { lat: Number(rows[0].lat), lng: Number(rows[0].lon), source: "nominatim", label: rows[0].display_name };
        cache[camera.id] = value; writeGeoCache(cache); return value;
      }
    }
  } catch { /* fall back to locality centroid so the source is still visible */ }
  const point = fallbackLocation(camera);
  const value: CachedGeo = { ...point, source: "fallback", label: `${camera.name} · locality reference` };
  cache[camera.id] = value; writeGeoCache(cache); return value;
}

async function routeBetween(points: LatLng[]): Promise<{ coordinates: LatLng[]; distance: number; duration: number } | null> {
  if (points.length < 2) return null;
  try {
    const coords = points.map((p) => `${p.lng},${p.lat}`).join(";");
    const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson&alternatives=true&steps=false`);
    if (!response.ok) return null;
    const data = await response.json() as { routes?: Array<{ distance: number; duration: number; geometry?: { coordinates: number[][] } }> };
    const route = data.routes?.[0];
    if (!route?.geometry?.coordinates?.length) return null;
    return { coordinates: route.geometry.coordinates.map(([lng, lat]) => ({ lat, lng })), distance: route.distance, duration: route.duration };
  } catch { return null; }
}

export function CommandMap({ cameras, alerts = [], route = [], activeCameraId, onCameraSelect, officerLocation = null, onOfficerRouteChange, onOfficerLocationChange, onRoadRouteHypothesesChange, onApproximateLocationsChange, selectedRoadRouteIndex = 0, className, compact = false }: CommandMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const cameraMarkers = useRef<Map<string, L.Marker>>(new Map());
  const officerMarker = useRef<L.Marker | null>(null);
  const routeLine = useRef<L.Polyline | null>(null);
  const officerRouteLine = useRef<L.Polyline | null>(null);
  const initialViewportFitted = useRef(false);
  const [locations, setLocations] = useState<Record<string, CachedGeo>>({});
  const [pegmanDragging, setPegmanDragging] = useState(false);
  const [streetViewPoint, setStreetViewPoint] = useState<LatLng | null>(null);
  const [streetViewLoaded, setStreetViewLoaded] = useState(false);
  const [status, setStatus] = useState("Loading camera locations…");


  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, { center: [DEFAULT_CENTER.lat, DEFAULT_CENTER.lng], zoom: 7, zoomControl: true, preferCanvas: true });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    mapRef.current = map;
    if (onOfficerLocationChange) map.on("click", (e: L.LeafletMouseEvent) => onOfficerLocationChange({ lat: e.latlng.lat, lng: e.latlng.lng }));
    return () => { map.remove(); mapRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadAll = async () => {
      const next: Record<string, CachedGeo> = {};
      let approximateIds: string[] = [];
      // Every source is processed. Existing GPS is instant; label-only sources are geocoded sequentially to respect Nominatim rate limits.
      for (const camera of cameras) {
        if (cancelled) return;
        const value = await geocodeCamera(camera);
        next[camera.id] = value;
        if (value.source === "fallback") approximateIds.push(camera.id);
        setLocations((current) => ({ ...current, [camera.id]: value }));
      }
      if (!cancelled) {
        setStatus(`${cameras.length} camera sources mapped · ${approximateIds.length} locality references`);
        onApproximateLocationsChange?.(approximateIds);
      }
    };
    void loadAll();
    return () => { cancelled = true; };
  }, [cameras.map((c) => `${c.id}:${c.latitude}:${c.longitude}:${c.name}:${c.district}`).join("|")]);

  useEffect(() => {
    const map = mapRef.current; if (!map) return;
    const seen = new Set<string>();
    cameras.forEach((camera) => {
      const location = locations[camera.id]; if (!location) return;
      seen.add(camera.id);
      const relatedAlert = alerts.find((a) => a.cameraId === camera.id && a.status !== "resolved");
      const routeIndex = route.findIndex((p) => p.cameraId === camera.id);
      const marker = cameraMarkers.current.get(camera.id);
      const icon = cameraIcon(camera, relatedAlert, activeCameraId === camera.id, routeIndex, location.source === "fallback");
      if (!marker) {
        const created = L.marker([location.lat, location.lng], { icon, title: `${camera.name} · ${location.source === "fallback" ? "approximate" : "mapped"}` }).addTo(map);
        created.on("click", () => onCameraSelect?.(camera.id));
        cameraMarkers.current.set(camera.id, created);
      } else { marker.setLatLng([location.lat, location.lng]); marker.setIcon(icon); }
      cameraMarkers.current.get(camera.id)?.bindTooltip(`<strong>${camera.name}</strong><br>${camera.id}<br>${location.source === "fallback" ? "Approximate locality reference" : "Mapped location"}`, { direction: "top" });
    });
    cameraMarkers.current.forEach((marker, id) => { if (!seen.has(id)) { marker.remove(); cameraMarkers.current.delete(id); } });
    // IMPORTANT: never fit the viewport on every marker/location update.
    // Geocoding happens incrementally, so doing this here makes the map repeatedly
    // zoom out as each camera arrives. Fit once after the first useful batch, then
    // leave the user's pan/zoom completely alone.
    if (!initialViewportFitted.current) {
      const points = Object.values(locations).map((p) => [p.lat, p.lng] as [number, number]);
      if (points.length > 1) {
        map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: compact ? 10 : 12, animate: false });
        initialViewportFitted.current = true;
      }
    }
  }, [cameras, locations, alerts, activeCameraId, route, onCameraSelect, compact]);

  useEffect(() => {
    const map = mapRef.current; if (!map) return;
    routeLine.current?.remove(); routeLine.current = null;
    const points = route.map((p) => locations[p.cameraId]).filter(Boolean);
    if (points.length < 2) { onRoadRouteHypothesesChange?.([]); return; }
    let cancelled = false;
    void routeBetween(points.map((p) => ({ lat: p.lat, lng: p.lng }))).then((result) => {
      if (cancelled || !result || !mapRef.current) return;
      routeLine.current = L.polyline(result.coordinates.map((p) => [p.lat, p.lng] as [number, number]), { color: "#06b6d4", weight: 5, dashArray: "8 7", opacity: .95 }).addTo(mapRef.current);
      onRoadRouteHypothesesChange?.([{ index: 0, label: "Recommended road option", distanceMeters: result.distance, durationSeconds: result.duration, roadSummary: `Road route through ${points.length} mapped cameras`, legIndexes: points.map(() => 0) }]);
    });
    return () => { cancelled = true; };
  }, [route, locations]);

  useEffect(() => {
    const map = mapRef.current; if (!map || !onOfficerLocationChange) return;
    if (!officerMarker.current) {
      officerMarker.current = L.marker([officerLocation?.lat ?? DEFAULT_CENTER.lat, officerLocation?.lng ?? DEFAULT_CENTER.lng], { draggable: true, icon: pegmanIcon(), title: "Drag person marker to place" }).addTo(map);
      officerMarker.current.on("dragend", () => { const p = officerMarker.current?.getLatLng(); if (p) onOfficerLocationChange({ lat: p.lat, lng: p.lng }); });
    } else if (officerLocation) officerMarker.current.setLatLng([officerLocation.lat, officerLocation.lng]);
    return () => { /* marker lives for the map lifetime */ };
  }, [Boolean(onOfficerLocationChange)]);

  useEffect(() => {
    if (!mapRef.current || !officerLocation) return;
    officerMarker.current?.setLatLng([officerLocation.lat, officerLocation.lng]);
    const targetCamera = route.length ? getCamera(route.at(-1)!.cameraId, cameras) : cameras.find((c) => c.id === activeCameraId);
    const target = targetCamera ? locations[targetCamera.id] : undefined;
    if (!target) { onOfficerRouteChange?.(null); return; }

    // Do not remove the existing route while a new route is being calculated.
    // Removing/re-adding the polyline on every drag frame caused a visible blink.
    // Debounce the routing request and swap the line only after the new geometry
    // has arrived, so the old route stays continuously rendered during movement.
    let cancelled = false;
    const timer = window.setTimeout(() => {
      void routeBetween([officerLocation, target]).then((result) => {
        if (cancelled || !result || !mapRef.current) return;
        const nextLine = L.polyline(
          result.coordinates.map((p) => [p.lat, p.lng] as [number, number]),
          { color: "#22c55e", weight: 6, opacity: .9 }
        ).addTo(mapRef.current);
        const previousLine = officerRouteLine.current;
        officerRouteLine.current = nextLine;
        previousLine?.remove();
        onOfficerRouteChange?.({
          distanceMeters: result.distance,
          durationSeconds: result.duration,
          targetLabel: targetCamera?.name ?? "Selected camera",
        });
      });
    }, 120);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [officerLocation, locations, route, cameras, activeCameraId]);

  function placePegman(point: LatLng) {
    // Keep Street View inside Sentinel. Google may refuse iframe embedding for a
    // particular location/browser; the panel therefore also exposes a deliberate
    // external fallback instead of silently opening a new tab.
    setStreetViewLoaded(false);
    setStreetViewPoint(point);
  }

  const streetViewEmbedUrl = streetViewPoint
    ? `https://maps.google.com/maps?q=&layer=c&cbll=${streetViewPoint.lat},${streetViewPoint.lng}&cbp=11,0,0,0,0&output=svembed`
    : "";
  const streetViewExternalUrl = streetViewPoint
    ? `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${streetViewPoint.lat},${streetViewPoint.lng}`
    : "";


  const handlePegmanDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setPegmanDragging(false);
    const map = mapRef.current;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!map || !rect) return;
    const point = map.containerPointToLatLng(L.point(event.clientX - rect.left, event.clientY - rect.top));
    placePegman({ lat: point.lat, lng: point.lng });
  };

  const recenter = () => { const map = mapRef.current; const points = Object.values(locations).map((p) => [p.lat, p.lng] as [number, number]); if (map && points.length) map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: compact ? 10 : 12 }); };
  const focusSelected = () => { const camera = cameras.find((c) => c.id === activeCameraId); const p = camera ? locations[camera.id] : undefined; if (p) { mapRef.current?.setView([p.lat, p.lng], 15); } };

  return <div className={cn("command-map command-map-leaflet", compact && "command-map-compact", className)} onDragOver={(event) => { if (pegmanDragging) event.preventDefault(); }} onDrop={handlePegmanDrop}>
    <div ref={containerRef} className="command-leaflet-surface" />
    {streetViewPoint ? (
      <div className="street-view-panel" role="dialog" aria-label="Street View preview">
        <div className="street-view-panel-head">
          <div>
            <strong>STREET VIEW / INTERNAL PREVIEW</strong>
            <small>{streetViewPoint.lat.toFixed(6)}, {streetViewPoint.lng.toFixed(6)}</small>
          </div>
          <button type="button" onClick={() => setStreetViewPoint(null)}>CLOSE</button>
        </div>
        <div className="street-view-canvas">
          <iframe
            title="Google Street View"
            src={streetViewEmbedUrl}
            style={{ width: "100%", height: "100%", border: 0 }}
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
            onLoad={() => setStreetViewLoaded(true)}
          />
          {!streetViewLoaded ? (
            <div className="street-view-status">
              <strong>Loading Street View…</strong>
              <span>If Google blocks embedded Street View for this location, use the explicit fallback below.</span>
              <a href={streetViewExternalUrl} target="_blank" rel="noreferrer">OPEN STREET VIEW EXTERNALLY</a>
            </div>
          ) : null}
          {streetViewLoaded ? (
            <div className="street-view-fallback-bar">
              <span>Embedded preview · {streetViewPoint.lat.toFixed(5)}, {streetViewPoint.lng.toFixed(5)}</span>
              <a href={streetViewExternalUrl} target="_blank" rel="noreferrer">OPEN IN GOOGLE MAPS</a>
            </div>
          ) : null}
        </div>
      </div>
    ) : null}
    <div className="live-map-overlay live-map-overlay-top"><span className="live-map-overlay-dot" />{status}{streetViewPoint ? ` · Street View point ${streetViewPoint.lat.toFixed(4)}, ${streetViewPoint.lng.toFixed(4)}` : ""}</div>
    <div className="pegman-control" aria-label="Street View Pegman"><span className="pegman-handle" draggable onDragStart={() => setPegmanDragging(true)} onDragEnd={() => setPegmanDragging(false)} title="Drag the yellow person onto the map"><span className="pegman-icon"><i /></span></span><strong>STREET VIEW</strong><small>Drag yellow person onto map</small></div>
    {pegmanDragging ? <div className="pegman-drag-ghost"><span className="pegman-icon"><i /></span></div> : null}
    {onOfficerLocationChange ? <div className="person-placement-hint"><span className="person-placement-icon">●</span><span><strong>PERSON MARKER</strong><small>Drag the yellow person pin or click the map</small></span></div> : null}
    <div className="map-legend live-map-legend"><span><i className="legend-dot online" />Online</span><span><i className="legend-dot degraded" />Degraded</span><span><i className="legend-dot offline" />Offline</span><span><i className="legend-line officer-route-line" />Route</span></div>
    <div className="map-scale"><Navigation size={12} /> {cameras.length} REGISTERED SOURCES · GPS + AUTOMATIC LOCALITY GEOCODING</div>
    <div className="map-controls"><button onClick={recenter} aria-label="Center operational map"><RotateCcw size={15} /></button><button onClick={focusSelected} disabled={!activeCameraId || !locations[activeCameraId]} aria-label="Focus selected camera"><Crosshair size={15} /></button><button onClick={() => placePegman(mapRef.current?.getCenter() ? { lat: mapRef.current.getCenter()!.lat, lng: mapRef.current.getCenter()!.lng } : DEFAULT_CENTER)} aria-label="Open Street View at map center"><MapPin size={15} /></button></div>
  </div>;
}
