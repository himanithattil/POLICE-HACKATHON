import { ArrowLeft, BellRing, ChevronLeft, CircleUserRound, DatabaseZap, FlaskConical, LayoutDashboard, Menu, RadioTower, Route, ScanEye, ShieldCheck, UsersRound, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { clearSharedSession, getSharedToken } from "@/lib/share";
import { trpc } from "@/lib/trpc";

const navigation = [
  { label: "Operations", path: "/operations", icon: LayoutDashboard, hint: "Overview" },
  { label: "Camera Registry", path: "/registry", icon: RadioTower, hint: "Sources" },
  { label: "Case Intelligence", path: "/watchlist", icon: ShieldCheck, hint: "Alerts" },
  { label: "Vehicle Routes", path: "/routes", icon: Route, hint: "Trace" },
  { label: "Person Routes", path: "/person-routes", icon: UsersRound, hint: "Trace" },
  { label: "Live Detection", path: "/detect", icon: ScanEye, hint: "AI" },
  { label: "Readiness Lab", path: "/readiness", icon: FlaskConical, hint: "Demo" },
  { label: "Data Intake", path: "/intake", icon: DatabaseZap, hint: "Admin" },
];

export function CommandLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);  const sharedToken = getSharedToken();
  const sharedAccess = trpc.share.inspect.useQuery({ token: sharedToken ?? "" }, { enabled: Boolean(sharedToken), retry: false, refetchInterval: 60_000 });
  const sharedSession = Boolean(sharedToken && sharedAccess.data?.valid);
  const visibleNavigation = sharedSession ? navigation.filter((item) => !["/intake", "/detect"].includes(item.path)) : navigation;
  const isHome = location === "/operations";

  function goBack() {
    // Prefer real browser history (keeps scroll position / prior filters),
    // but never leave the button as a dead end — e.g. right after a hard
    // refresh there may be no in-app history to go back to yet.
    if (window.history.length > 1) window.history.back();
    else setLocation("/operations");
  }

  useEffect(() => {
    if (sharedToken && sharedAccess.data && !sharedAccess.data.valid) {
      clearSharedSession();
      setLocation("/");
    }
  }, [sharedAccess.data, sharedToken, setLocation]);

  const closeMobile = () => setMobileOpen(false);

  if (sharedToken && sharedAccess.isLoading) return <main className="entry-gate"><section className="entry-card share-access-card"><div className="entry-brand"><div className="entry-brand-mark"><ShieldCheck size={21} /></div><div><span>SENTINEL GRID / SHARED ACCESS</span><strong>Verifying workspace</strong></div></div><div className="share-access-status"><ShieldCheck size={18} /><div><strong>Rechecking read-only access</strong><span>This shared link is validated before the command workspace is shown.</span></div></div></section></main>;
  if (sharedToken && sharedAccess.data && !sharedAccess.data.valid) return null;

  return (
    <div className="command-shell">
      {mobileOpen ? <button className="mobile-scrim" onClick={closeMobile} aria-label="Close navigation" /> : null}
      <aside className={cn("command-sidebar", collapsed && "command-sidebar-collapsed", mobileOpen && "command-sidebar-mobile-open")}>
        <div className="sidebar-brand">
          <Link href="/operations" className="brand-mark brand-mark-police" title="Go to Operations home" aria-label="Go to Operations home"><ShieldCheck size={20} /><span>GP</span></Link>
          <div className="brand-copy"><span className="eyebrow">GUJARAT / COMMAND</span><strong>Sentinel Grid</strong></div>
          <button className="sidebar-collapse" onClick={() => setCollapsed((value) => !value)} aria-label="Toggle sidebar"><ChevronLeft size={16} /></button>
          <button className="mobile-close" onClick={closeMobile} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="sidebar-status"><span className="signal-dot" /><span>SIMULATED FEED</span><i>08:42 IST</i></div>
        <nav className="command-navigation" aria-label="Command center navigation">
          <p className="nav-heading">CONTROL PLANES</p>
          {visibleNavigation.map((item) => {
            const Icon = item.icon;
            const active = location === item.path || location.startsWith(`${item.path}/`);
            return <Link key={item.path} href={item.path} onClick={closeMobile} className={cn("command-nav-link", active && "command-nav-link-active")}><Icon size={18} /><span className="nav-label">{item.label}</span><em>{item.hint}</em></Link>;
          })}
          {sharedSession ? <div className="command-nav-link command-nav-link-shared"><ShieldCheck size={18} /><span className="nav-label">Shared access</span><em>Read-only</em></div> : <div className="command-nav-link command-nav-link-shared"><ShieldCheck size={18} /><span className="nav-label">Judge bypass</span><em>Demo</em></div>}
        </nav>
        <div className="sidebar-footer"><div className="operator-avatar"><CircleUserRound size={18} /></div><div className="operator-copy"><span>{sharedSession ? "Shared observer" : "Judge observer"}</span><strong>{sharedSession ? "Read-only workspace" : "No login required"}</strong></div><BellRing size={16} className="footer-bell" /></div>
      </aside>
      <main className={cn("command-main", collapsed && "command-main-expanded")}>
        <header className="command-topbar"><button className="mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={19} /></button>{!isHome ? <button className="topbar-back" onClick={goBack} aria-label="Go back"><ArrowLeft size={16} /><span>Back</span></button> : null}<div className="topbar-breadcrumb"><span>GUJARAT CCTV INTELLIGENCE</span><i>/</i><strong>{navigation.find((item) => location === item.path || location.startsWith(`${item.path}/`))?.label ?? "Command"}</strong></div><div className="topbar-meta">{sharedSession ? <span className="shared-topbar-badge"><ShieldCheck size={12} />SHARED · READ-ONLY</span> : null}<span className="system-health"><i />SYSTEM NOMINAL</span><span className="clock">08:42:16 IST</span></div></header>
        <div className="command-content">{children}</div>
      </main>
    </div>
  );
}
