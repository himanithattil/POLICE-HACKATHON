import type { ElementType, ReactNode } from "react";
import { AlertTriangle, ArrowUpRight, Check, CircleAlert, Clock3, LoaderCircle } from "lucide-react";
import type { AlertPriority, AlertStatus, CameraStatus } from "@/lib/operations";
import { cn } from "@/lib/utils";

export function PageHeading({ eyebrow, title, description, actions }: { eyebrow: string; title: ReactNode; description: string; actions?: ReactNode }) {
  return <section className="page-heading command-panel"><div className="page-heading-grid" /><div className="page-heading-content"><div><p className="eyebrow"><span className="signal-dot" />{eyebrow}</p><h1>{title}</h1><p>{description}</p></div>{actions ? <div className="page-heading-actions">{actions}</div> : null}</div></section>;
}

export function MetricCard({ label, value, detail, icon: Icon, tone = "blue" }: { label: string; value: string | number; detail: string; icon: ElementType; tone?: "blue" | "green" | "amber" | "red" }) {
  return <article className={cn("metric-card", `metric-card-${tone}`)}><div className="metric-top"><span>{label}</span><Icon size={17} /></div><strong>{typeof value === "number" ? value.toString().padStart(2, "0") : value}</strong><p>{detail}</p></article>;
}

export function SectionTitle({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) {
  return <div className="section-title"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action ? <button className="technical-link" onClick={onAction}>{action}<ArrowUpRight size={14} /></button> : null}</div>;
}

export function StatusBadge({ status }: { status: CameraStatus | AlertStatus }) {
  const icon = status === "online" || status === "acknowledged" ? <Check size={11} /> : status === "new" ? <CircleAlert size={11} /> : <Clock3 size={11} />;
  return <span className={cn("status-badge", `status-badge-${status}`)}>{icon}{status}</span>;
}

export function PriorityBadge({ priority }: { priority: AlertPriority }) {
  return <span className={cn("priority-badge", `priority-badge-${priority}`)}>{priority} priority</span>;
}

export function DataState({ mode, title, detail }: { mode: "loading" | "error"; title: string; detail: string }) {
  return <section className="command-panel data-state">{mode === "loading" ? <LoaderCircle size={27} className="data-state-spinner" /> : <AlertTriangle size={27} />}<strong>{title}</strong><p>{detail}</p></section>;
}
