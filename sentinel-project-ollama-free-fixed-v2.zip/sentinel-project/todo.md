# Sentinel Command Console Bug Tracker

- [x] Inspect the attached source and map the current event, route, location, and sharing flows.
- [x] Add explicit unknown/unidentified license-plate normalization so unreadable plates cannot appear as valid matches.
- [x] Correct person-route filtering and labels so person events never render a license-plate value.
- [x] Fix event-location mapping to use the source event camera/GPS location, with unavailable and low-confidence states.
- [x] Replace Manus-dependent sharing with app-native independent access for shared users.
- [x] Apply an elegant, polished monitoring-console visual treatment without sacrificing clarity or accessibility.
- [x] Add focused Vitest coverage for detection normalization, person-route filtering, location provenance, and share access.
- [x] Run type checks, tests, and visual verification; `pnpm check` passes, 10 Vitest files / 27 tests pass, and browser verification confirms independent share access plus person-route/location states.
- [x] Save the final project checkpoint and deliver the updated project.
- [x] Fix plate search so a matched vehicle route centers and displays a clearly labeled approximate source location when verified coordinates are unavailable, while preserving verified-GPS routing safeguards.
- [x] Add explicit plate-search/map verification coverage and record the result; `getMapLocationDisplay` now has direct unit coverage, `pnpm check` passes, 10 Vitest files / 28 tests pass, and browser verification shows `0/3 VERIFIED GPS · 3 APPROXIMATE` with the searched plate centered on source-label map context.
