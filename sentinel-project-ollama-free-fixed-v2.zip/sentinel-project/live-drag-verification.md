# Live Drag Verification

After adding the live Google Maps draggable marker path, a browser pointer drag was simulated on the fallback marker at `/routes`: pointer down on the officer marker, pointer move to a different map position, and pointer up.

The resulting browser state confirmed `found: true`, `officerMarkerVisible: true`, `routeGuidanceReady: true`, and `clearLocationVisible: true`. This proves the drag interaction updates the officer location and activates route guidance state. The same marker callback is wired to the main Operations dashboard map and the Vehicle Routes map.
